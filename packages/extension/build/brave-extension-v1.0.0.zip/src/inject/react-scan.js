var __defProp=Object.defineProperty;var __name=(target,value)=>__defProp(target,"name",{value,configurable:!0});(function(){"use strict";/**
 * @license bippy
 *
 * Copyright (c) Aiden Bai.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var _a,_b;var version="0.0.25",BIPPY_INSTRUMENTATION_STRING=`bippy-${version}`,ClassComponentTag=1,FunctionComponentTag=0,ContextConsumerTag=9,SuspenseComponentTag=13,ForwardRefTag=11,MemoComponentTag=14,SimpleMemoComponentTag=15,HostComponentTag=5,HostHoistableTag=26,HostSingletonTag=27,DehydratedSuspenseComponent=18,HostText=6,Fragment=7,LegacyHiddenComponent=23,OffscreenComponent=22,HostRoot=3,CONCURRENT_MODE_NUMBER=60111,CONCURRENT_MODE_SYMBOL_STRING="Symbol(react.concurrent_mode)",DEPRECATED_ASYNC_MODE_SYMBOL_STRING="Symbol(react.async_mode)",PerformedWork=1,Placement=2,Update=4,ChildDeletion=16,isValidElement=__name(element=>typeof element=="object"&&element!=null&&"$$typeof"in element&&["Symbol(react.element)","Symbol(react.transitional.element)"].includes(String(element.$$typeof)),"isValidElement"),isHostFiber=__name(fiber=>fiber.tag===HostComponentTag||fiber.tag===HostHoistableTag||fiber.tag===HostSingletonTag,"isHostFiber"),isCompositeFiber=__name(fiber=>fiber.tag===FunctionComponentTag||fiber.tag===ClassComponentTag||fiber.tag===SimpleMemoComponentTag||fiber.tag===MemoComponentTag||fiber.tag===ForwardRefTag,"isCompositeFiber"),traverseContexts=__name((fiber,selector)=>{var _a2;try{const nextDependencies=fiber.dependencies,prevDependencies=(_a2=fiber.alternate)==null?void 0:_a2.dependencies;if(!nextDependencies||!prevDependencies||typeof nextDependencies!="object"||!("firstContext"in nextDependencies)||typeof prevDependencies!="object"||!("firstContext"in prevDependencies))return!1;let nextContext=nextDependencies.firstContext,prevContext=prevDependencies.firstContext;for(;nextContext&&typeof nextContext=="object"&&"memoizedValue"in nextContext&&prevContext&&typeof prevContext=="object"&&"memoizedValue"in prevContext;){if(selector(nextContext,prevContext)===!0)return!0;nextContext=nextContext.next,prevContext=prevContext.next}}catch{}return!1},"traverseContexts"),traverseState=__name((fiber,selector)=>{var _a2;try{let prevState=fiber.memoizedState,nextState=(_a2=fiber.alternate)==null?void 0:_a2.memoizedState;for(;prevState&&nextState;){if(selector(prevState,nextState)===!0)return!0;prevState=prevState.next,nextState=nextState.next}}catch{}return!1},"traverseState"),traverseProps=__name((fiber,selector)=>{var _a2;try{const nextProps=fiber.memoizedProps,prevProps=((_a2=fiber.alternate)==null?void 0:_a2.memoizedProps)||{},allKeys=new Set([...Object.keys(prevProps),...Object.keys(nextProps)]);for(const propName of allKeys){const prevValue=prevProps==null?void 0:prevProps[propName],nextValue=nextProps==null?void 0:nextProps[propName];if(selector(propName,nextValue,prevValue)===!0)return!0}}catch{}return!1},"traverseProps"),didFiberRender=__name(fiber=>{var _a2;const nextProps=fiber.memoizedProps,prevProps=((_a2=fiber.alternate)==null?void 0:_a2.memoizedProps)||{},flags=fiber.flags??fiber.effectTag??0;switch(fiber.tag){case ClassComponentTag:case FunctionComponentTag:case ContextConsumerTag:case ForwardRefTag:case MemoComponentTag:case SimpleMemoComponentTag:return(flags&PerformedWork)===PerformedWork;default:return fiber.alternate?prevProps!==nextProps||fiber.alternate.memoizedState!==fiber.memoizedState||fiber.alternate.ref!==fiber.ref:!0}},"didFiberRender"),didFiberCommit=__name(fiber=>!!(fiber.flags&(Update|Placement|ChildDeletion)||fiber.subtreeFlags&(Update|Placement|ChildDeletion)),"didFiberCommit"),getMutatedHostFibers=__name(fiber=>{const mutations=[],stack=[fiber];for(;stack.length;){const node=stack.pop();node&&(isHostFiber(node)&&didFiberCommit(node)&&didFiberRender(node)&&mutations.push(node),node.child&&stack.push(node.child),node.sibling&&stack.push(node.sibling))}return mutations},"getMutatedHostFibers"),shouldFilterFiber=__name(fiber=>{switch(fiber.tag){case DehydratedSuspenseComponent:return!0;case HostText:case Fragment:case LegacyHiddenComponent:case OffscreenComponent:return!0;case HostRoot:return!1;default:{const symbolOrNumber=typeof fiber.type=="object"&&fiber.type!==null?fiber.type.$$typeof:fiber.type;switch(typeof symbolOrNumber=="symbol"?symbolOrNumber.toString():symbolOrNumber){case CONCURRENT_MODE_NUMBER:case CONCURRENT_MODE_SYMBOL_STRING:case DEPRECATED_ASYNC_MODE_SYMBOL_STRING:return!0;default:return!1}}}},"shouldFilterFiber"),getNearestHostFiber=__name(fiber=>{let hostFiber=traverseFiber(fiber,isHostFiber);return hostFiber||(hostFiber=traverseFiber(fiber,isHostFiber,!0)),hostFiber},"getNearestHostFiber"),traverseFiber=__name((fiber,selector,ascending=!1)=>{if(!fiber)return null;if(selector(fiber)===!0)return fiber;let child=ascending?fiber.return:fiber.child;for(;child;){const match=traverseFiber(child,selector,ascending);if(match)return match;child=ascending?null:child.sibling}return null},"traverseFiber"),getTimings=__name(fiber=>{const totalTime=(fiber==null?void 0:fiber.actualDuration)??0;let selfTime=totalTime,child=(fiber==null?void 0:fiber.child)??null;for(;totalTime>0&&child!=null;)selfTime-=child.actualDuration??0,child=child.sibling;return{selfTime,totalTime}},"getTimings"),hasMemoCache=__name(fiber=>{var _a2;return!!((_a2=fiber.updateQueue)!=null&&_a2.memoCache)},"hasMemoCache"),getType=__name(type=>typeof type=="function"?type:typeof type=="object"&&type?getType(type.type||type.render):null,"getType"),getDisplayName=__name(type=>{if(typeof type!="function"&&!(typeof type=="object"&&type))return null;const name=type.displayName||type.name||null;return name||(type=getType(type),type&&(type.displayName||type.name)||null)},"getDisplayName"),isUsingRDT=__name(()=>globalThis.__REACT_DEVTOOLS_BACKEND_MANAGER_INJECTED__!=null,"isUsingRDT"),detectReactBuildType=__name(renderer=>{try{if(typeof renderer.version=="string"&&renderer.bundleType>0)return"development"}catch{}return"production"},"detectReactBuildType"),checkDCE=__name(fn2=>{try{Function.prototype.toString.call(fn2).indexOf("^_^")>-1&&setTimeout(()=>{throw new Error("React is running in production mode, but dead code elimination has not been applied. Read how to correctly configure React for production: https://reactjs.org/link/perf-use-production-build")})}catch{}},"checkDCE"),NO_OP=__name(()=>{},"NO_OP"),installRDTHook=__name(onActive=>{const renderers=new Map;let i2=0;const rdtHook2={checkDCE,supportsFiber:!0,supportsFlight:!0,renderers,onCommitFiberRoot:NO_OP,onCommitFiberUnmount:NO_OP,onPostCommitFiberRoot:NO_OP,inject(renderer){const nextID=++i2;return renderers.set(nextID,renderer),rdtHook2._instrumentationIsActive||(rdtHook2._instrumentationIsActive=!0,onActive==null||onActive()),nextID},_instrumentationSource:BIPPY_INSTRUMENTATION_STRING,_instrumentationIsActive:!1};try{Object.defineProperty(globalThis,"__REACT_DEVTOOLS_GLOBAL_HOOK__",{configurable:!0,value:rdtHook2})}catch{}return rdtHook2},"installRDTHook"),getRDTHook=__name(onActive=>{let rdtHook2=globalThis.__REACT_DEVTOOLS_GLOBAL_HOOK__;return rdtHook2&&(onActive==null||onActive()),window.hasOwnProperty("__REACT_DEVTOOLS_GLOBAL_HOOK__")||(rdtHook2=installRDTHook(onActive)),rdtHook2},"getRDTHook"),isInstrumentationActive=__name(()=>!!getRDTHook()._instrumentationIsActive||isUsingRDT(),"isInstrumentationActive"),mountFiberRecursively=__name((onRender2,firstChild,traverseSiblings)=>{let fiber=firstChild;for(;fiber!=null;){if(!shouldFilterFiber(fiber)&&didFiberRender(fiber)&&onRender2(fiber,"mount"),fiber.tag===SuspenseComponentTag)if(fiber.memoizedState!==null){const primaryChildFragment=fiber.child,fallbackChildFragment=primaryChildFragment?primaryChildFragment.sibling:null;if(fallbackChildFragment){const fallbackChild=fallbackChildFragment.child;fallbackChild!==null&&mountFiberRecursively(onRender2,fallbackChild,!1)}}else{let primaryChild=null;fiber.child!==null&&(primaryChild=fiber.child.child),primaryChild!==null&&mountFiberRecursively(onRender2,primaryChild,!1)}else fiber.child!=null&&mountFiberRecursively(onRender2,fiber.child,!0);fiber=traverseSiblings?fiber.sibling:null}},"mountFiberRecursively"),updateFiberRecursively=__name((onRender2,nextFiber,prevFiber,parentFiber)=>{var _a2,_b2,_c;if(!prevFiber)return;const isSuspense=nextFiber.tag===SuspenseComponentTag;!shouldFilterFiber(nextFiber)&&didFiberRender(nextFiber)&&onRender2(nextFiber,"update");const prevDidTimeout=isSuspense&&prevFiber.memoizedState!==null,nextDidTimeOut=isSuspense&&nextFiber.memoizedState!==null;if(prevDidTimeout&&nextDidTimeOut){const nextFallbackChildSet=((_a2=nextFiber.child)==null?void 0:_a2.sibling)??null,prevFallbackChildSet=((_b2=prevFiber.child)==null?void 0:_b2.sibling)??null;nextFallbackChildSet!==null&&prevFallbackChildSet!==null&&updateFiberRecursively(onRender2,nextFallbackChildSet,prevFallbackChildSet)}else if(prevDidTimeout&&!nextDidTimeOut){const nextPrimaryChildSet=nextFiber.child;nextPrimaryChildSet!==null&&mountFiberRecursively(onRender2,nextPrimaryChildSet,!0)}else if(!prevDidTimeout&&nextDidTimeOut){unmountFiberChildrenRecursively(onRender2,prevFiber);const nextFallbackChildSet=((_c=nextFiber.child)==null?void 0:_c.sibling)??null;nextFallbackChildSet!==null&&mountFiberRecursively(onRender2,nextFallbackChildSet,!0)}else if(nextFiber.child!==prevFiber.child){let nextChild=nextFiber.child;for(;nextChild;){if(nextChild.alternate){const prevChild=nextChild.alternate;updateFiberRecursively(onRender2,nextChild,prevChild)}else mountFiberRecursively(onRender2,nextChild,!1);nextChild=nextChild.sibling}}},"updateFiberRecursively"),unmountFiber=__name((onRender2,fiber)=>{(fiber.tag===HostRoot||!shouldFilterFiber(fiber))&&onRender2(fiber,"unmount")},"unmountFiber"),unmountFiberChildrenRecursively=__name((onRender2,fiber)=>{const isTimedOutSuspense=fiber.tag===SuspenseComponentTag&&fiber.memoizedState!==null;let child=fiber.child;if(isTimedOutSuspense){const primaryChildFragment=fiber.child,fallbackChildFragment=(primaryChildFragment==null?void 0:primaryChildFragment.sibling)??null;child=(fallbackChildFragment==null?void 0:fallbackChildFragment.child)??null}for(;child!==null;)child.return!==null&&(unmountFiber(onRender2,child),unmountFiberChildrenRecursively(onRender2,child)),child=child.sibling},"unmountFiberChildrenRecursively"),commitId=0,rootInstanceMap=new WeakMap,createFiberVisitor=__name(({onRender:onRenderWithoutState,onError})=>(_rendererID,root,state)=>{const rootFiber=root.current,onRender2=__name((fiber,phase)=>onRenderWithoutState(fiber,phase,state),"onRender");let rootInstance=rootInstanceMap.get(root);rootInstance||(rootInstance={prevFiber:null,id:commitId++},rootInstanceMap.set(root,rootInstance));const{prevFiber}=rootInstance;try{if(!rootFiber)unmountFiber(onRender2,root);else if(prevFiber!==null){const wasMounted=prevFiber&&prevFiber.memoizedState!=null&&prevFiber.memoizedState.element!=null&&prevFiber.memoizedState.isDehydrated!==!0,isMounted=rootFiber.memoizedState!=null&&rootFiber.memoizedState.element!=null&&rootFiber.memoizedState.isDehydrated!==!0;!wasMounted&&isMounted?mountFiberRecursively(onRender2,rootFiber,!1):wasMounted&&isMounted?updateFiberRecursively(onRender2,rootFiber,rootFiber.alternate,null):wasMounted&&!isMounted&&unmountFiber(onRender2,rootFiber)}else mountFiberRecursively(onRender2,rootFiber,!1)}catch(err){if(onError)onError(err);else throw err}rootInstance.prevFiber=rootFiber},"createFiberVisitor"),instrument=__name(({onCommitFiberRoot,onCommitFiberUnmount,onPostCommitFiberRoot,onActive,name})=>{const devtoolsHook=getRDTHook(onActive);devtoolsHook._instrumentationSource=name??BIPPY_INSTRUMENTATION_STRING;const prevOnCommitFiberRoot=devtoolsHook.onCommitFiberRoot;onCommitFiberRoot&&(devtoolsHook.onCommitFiberRoot=(rendererID,root,priority)=>{prevOnCommitFiberRoot&&prevOnCommitFiberRoot(rendererID,root,priority),onCommitFiberRoot(rendererID,root,priority)});const prevOnCommitFiberUnmount=devtoolsHook.onCommitFiberUnmount;onCommitFiberUnmount&&(devtoolsHook.onCommitFiberUnmount=(rendererID,root)=>{prevOnCommitFiberUnmount&&prevOnCommitFiberUnmount(rendererID,root),onCommitFiberUnmount(rendererID,root)});const prevOnPostCommitFiberRoot=devtoolsHook.onPostCommitFiberRoot;return onPostCommitFiberRoot&&(devtoolsHook.onPostCommitFiberRoot=(rendererID,root)=>{prevOnPostCommitFiberRoot&&prevOnPostCommitFiberRoot(rendererID,root)}),devtoolsHook},"instrument"),isBrowser=typeof document<"u"&&typeof document.createElement=="function",isNode=typeof process<"u"&&process.versions!=null&&process.versions.node!=null;(isBrowser||!isNode)&&installRDTHook();var n,l$3,u$3,t$2,i$2,r$2,o$2,e$2,f$3,c$2,s$3,a$2,p$3={},v$2=[],y$2=/acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i,d$3=Array.isArray;function w$2(n2,l2){for(var u2 in l2)n2[u2]=l2[u2];return n2}__name(w$2,"w$2");function _$2(n2){n2&&n2.parentNode&&n2.parentNode.removeChild(n2)}__name(_$2,"_$2");function g$2(l2,u2,t2){var i2,r2,o2,e2={};for(o2 in u2)o2=="key"?i2=u2[o2]:o2=="ref"?r2=u2[o2]:e2[o2]=u2[o2];if(arguments.length>2&&(e2.children=arguments.length>3?n.call(arguments,2):t2),typeof l2=="function"&&l2.defaultProps!=null)for(o2 in l2.defaultProps)e2[o2]===void 0&&(e2[o2]=l2.defaultProps[o2]);return m$1(l2,e2,i2,r2,null)}__name(g$2,"g$2");function m$1(n2,t2,i2,r2,o2){var e2={type:n2,props:t2,key:i2,ref:r2,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:o2??++u$3,__i:-1,__u:0};return o2==null&&l$3.vnode!=null&&l$3.vnode(e2),e2}__name(m$1,"m$1");function k$1(n2){return n2.children}__name(k$1,"k$1");function x(n2,l2){this.props=n2,this.context=l2}__name(x,"x");function C$1(n2,l2){if(l2==null)return n2.__?C$1(n2.__,n2.__i+1):null;for(var u2;l2<n2.__k.length;l2++)if((u2=n2.__k[l2])!=null&&u2.__e!=null)return u2.__e;return typeof n2.type=="function"?C$1(n2):null}__name(C$1,"C$1");function S(n2){var l2,u2;if((n2=n2.__)!=null&&n2.__c!=null){for(n2.__e=n2.__c.base=null,l2=0;l2<n2.__k.length;l2++)if((u2=n2.__k[l2])!=null&&u2.__e!=null){n2.__e=n2.__c.base=u2.__e;break}return S(n2)}}__name(S,"S");function M$1(n2){(!n2.__d&&(n2.__d=!0)&&i$2.push(n2)&&!P$1.__r++||r$2!==l$3.debounceRendering)&&((r$2=l$3.debounceRendering)||o$2)(P$1)}__name(M$1,"M$1");function P$1(){var n2,u2,t2,r2,o2,f2,c2,s2;for(i$2.sort(e$2);n2=i$2.shift();)n2.__d&&(u2=i$2.length,r2=void 0,f2=(o2=(t2=n2).__v).__e,c2=[],s2=[],t2.__P&&((r2=w$2({},o2)).__v=o2.__v+1,l$3.vnode&&l$3.vnode(r2),j$1(t2.__P,r2,o2,t2.__n,t2.__P.namespaceURI,32&o2.__u?[f2]:null,c2,f2??C$1(o2),!!(32&o2.__u),s2),r2.__v=o2.__v,r2.__.__k[r2.__i]=r2,z$2(c2,r2,s2),r2.__e!=f2&&S(r2)),i$2.length>u2&&i$2.sort(e$2));P$1.__r=0}__name(P$1,"P$1");function $$1(n2,l2,u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,y2,d2,w2,_2,g2=t2&&t2.__k||v$2,m2=l2.length;for(f2=I$1(u2,l2,g2,f2),a2=0;a2<m2;a2++)(y2=u2.__k[a2])!=null&&(h2=y2.__i===-1?p$3:g2[y2.__i]||p$3,y2.__i=a2,_2=j$1(n2,y2,h2,i2,r2,o2,e2,f2,c2,s2),d2=y2.__e,y2.ref&&h2.ref!=y2.ref&&(h2.ref&&V$1(h2.ref,null,y2),s2.push(y2.ref,y2.__c||d2,y2)),w2==null&&d2!=null&&(w2=d2),4&y2.__u||h2.__k===y2.__k?f2=H(y2,f2,n2):typeof y2.type=="function"&&_2!==void 0?f2=_2:d2&&(f2=d2.nextSibling),y2.__u&=-7);return u2.__e=w2,f2}__name($$1,"$$1");function I$1(n2,l2,u2,t2){var i2,r2,o2,e2,f2,c2=l2.length,s2=u2.length,a2=s2,h2=0;for(n2.__k=[],i2=0;i2<c2;i2++)(r2=l2[i2])!=null&&typeof r2!="boolean"&&typeof r2!="function"?(e2=i2+h2,(r2=n2.__k[i2]=typeof r2=="string"||typeof r2=="number"||typeof r2=="bigint"||r2.constructor==String?m$1(null,r2,null,null,null):d$3(r2)?m$1(k$1,{children:r2},null,null,null):r2.constructor===void 0&&r2.__b>0?m$1(r2.type,r2.props,r2.key,r2.ref?r2.ref:null,r2.__v):r2).__=n2,r2.__b=n2.__b+1,o2=null,(f2=r2.__i=T$2(r2,u2,e2,a2))!==-1&&(a2--,(o2=u2[f2])&&(o2.__u|=2)),o2==null||o2.__v===null?(f2==-1&&h2--,typeof r2.type!="function"&&(r2.__u|=4)):f2!==e2&&(f2==e2-1?h2--:f2==e2+1?h2++:(f2>e2?h2--:h2++,r2.__u|=4))):r2=n2.__k[i2]=null;if(a2)for(i2=0;i2<s2;i2++)(o2=u2[i2])!=null&&!(2&o2.__u)&&(o2.__e==t2&&(t2=C$1(o2)),q$2(o2,o2));return t2}__name(I$1,"I$1");function H(n2,l2,u2){var t2,i2;if(typeof n2.type=="function"){for(t2=n2.__k,i2=0;t2&&i2<t2.length;i2++)t2[i2]&&(t2[i2].__=n2,l2=H(t2[i2],l2,u2));return l2}n2.__e!=l2&&(l2&&n2.type&&!u2.contains(l2)&&(l2=C$1(n2)),u2.insertBefore(n2.__e,l2||null),l2=n2.__e);do l2=l2&&l2.nextSibling;while(l2!=null&&l2.nodeType===8);return l2}__name(H,"H");function L(n2,l2){return l2=l2||[],n2==null||typeof n2=="boolean"||(d$3(n2)?n2.some(function(n3){L(n3,l2)}):l2.push(n2)),l2}__name(L,"L");function T$2(n2,l2,u2,t2){var i2=n2.key,r2=n2.type,o2=u2-1,e2=u2+1,f2=l2[u2];if(f2===null||f2&&i2==f2.key&&r2===f2.type&&!(2&f2.__u))return u2;if((typeof r2!="function"||r2===k$1||i2)&&t2>(f2!=null&&!(2&f2.__u)?1:0))for(;o2>=0||e2<l2.length;){if(o2>=0){if((f2=l2[o2])&&!(2&f2.__u)&&i2==f2.key&&r2===f2.type)return o2;o2--}if(e2<l2.length){if((f2=l2[e2])&&!(2&f2.__u)&&i2==f2.key&&r2===f2.type)return e2;e2++}}return-1}__name(T$2,"T$2");function A$2(n2,l2,u2){l2[0]==="-"?n2.setProperty(l2,u2??""):n2[l2]=u2==null?"":typeof u2!="number"||y$2.test(l2)?u2:u2+"px"}__name(A$2,"A$2");function F$1(n2,l2,u2,t2,i2){var r2;n:if(l2==="style")if(typeof u2=="string")n2.style.cssText=u2;else{if(typeof t2=="string"&&(n2.style.cssText=t2=""),t2)for(l2 in t2)u2&&l2 in u2||A$2(n2.style,l2,"");if(u2)for(l2 in u2)t2&&u2[l2]===t2[l2]||A$2(n2.style,l2,u2[l2])}else if(l2[0]==="o"&&l2[1]==="n")r2=l2!==(l2=l2.replace(f$3,"$1")),l2=l2.toLowerCase()in n2||l2==="onFocusOut"||l2==="onFocusIn"?l2.toLowerCase().slice(2):l2.slice(2),n2.l||(n2.l={}),n2.l[l2+r2]=u2,u2?t2?u2.u=t2.u:(u2.u=c$2,n2.addEventListener(l2,r2?a$2:s$3,r2)):n2.removeEventListener(l2,r2?a$2:s$3,r2);else{if(i2=="http://www.w3.org/2000/svg")l2=l2.replace(/xlink(H|:h)/,"h").replace(/sName$/,"s");else if(l2!="width"&&l2!="height"&&l2!="href"&&l2!="list"&&l2!="form"&&l2!="tabIndex"&&l2!="download"&&l2!="rowSpan"&&l2!="colSpan"&&l2!="role"&&l2!="popover"&&l2 in n2)try{n2[l2]=u2??"";break n}catch{}typeof u2=="function"||(u2==null||u2===!1&&l2[4]!=="-"?n2.removeAttribute(l2):n2.setAttribute(l2,l2=="popover"&&u2==1?"":u2))}}__name(F$1,"F$1");function O$1(n2){return function(u2){if(this.l){var t2=this.l[u2.type+n2];if(u2.t==null)u2.t=c$2++;else if(u2.t<t2.u)return;return t2(l$3.event?l$3.event(u2):u2)}}}__name(O$1,"O$1");function j$1(n2,u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,p2,v2,y2,g2,m2,b2,C2,S2,M2,P2,I2,H2,L2,T2,A2,F2=u2.type;if(u2.constructor!==void 0)return null;128&t2.__u&&(c2=!!(32&t2.__u),o2=[f2=u2.__e=t2.__e]),(a2=l$3.__b)&&a2(u2);n:if(typeof F2=="function")try{if(b2=u2.props,C2="prototype"in F2&&F2.prototype.render,S2=(a2=F2.contextType)&&i2[a2.__c],M2=a2?S2?S2.props.value:a2.__:i2,t2.__c?m2=(h2=u2.__c=t2.__c).__=h2.__E:(C2?u2.__c=h2=new F2(b2,M2):(u2.__c=h2=new x(b2,M2),h2.constructor=F2,h2.render=B$2),S2&&S2.sub(h2),h2.props=b2,h2.state||(h2.state={}),h2.context=M2,h2.__n=i2,p2=h2.__d=!0,h2.__h=[],h2._sb=[]),C2&&h2.__s==null&&(h2.__s=h2.state),C2&&F2.getDerivedStateFromProps!=null&&(h2.__s==h2.state&&(h2.__s=w$2({},h2.__s)),w$2(h2.__s,F2.getDerivedStateFromProps(b2,h2.__s))),v2=h2.props,y2=h2.state,h2.__v=u2,p2)C2&&F2.getDerivedStateFromProps==null&&h2.componentWillMount!=null&&h2.componentWillMount(),C2&&h2.componentDidMount!=null&&h2.__h.push(h2.componentDidMount);else{if(C2&&F2.getDerivedStateFromProps==null&&b2!==v2&&h2.componentWillReceiveProps!=null&&h2.componentWillReceiveProps(b2,M2),!h2.__e&&(h2.shouldComponentUpdate!=null&&h2.shouldComponentUpdate(b2,h2.__s,M2)===!1||u2.__v===t2.__v)){for(u2.__v!==t2.__v&&(h2.props=b2,h2.state=h2.__s,h2.__d=!1),u2.__e=t2.__e,u2.__k=t2.__k,u2.__k.some(function(n3){n3&&(n3.__=u2)}),P2=0;P2<h2._sb.length;P2++)h2.__h.push(h2._sb[P2]);h2._sb=[],h2.__h.length&&e2.push(h2);break n}h2.componentWillUpdate!=null&&h2.componentWillUpdate(b2,h2.__s,M2),C2&&h2.componentDidUpdate!=null&&h2.__h.push(function(){h2.componentDidUpdate(v2,y2,g2)})}if(h2.context=M2,h2.props=b2,h2.__P=n2,h2.__e=!1,I2=l$3.__r,H2=0,C2){for(h2.state=h2.__s,h2.__d=!1,I2&&I2(u2),a2=h2.render(h2.props,h2.state,h2.context),L2=0;L2<h2._sb.length;L2++)h2.__h.push(h2._sb[L2]);h2._sb=[]}else do h2.__d=!1,I2&&I2(u2),a2=h2.render(h2.props,h2.state,h2.context),h2.state=h2.__s;while(h2.__d&&++H2<25);h2.state=h2.__s,h2.getChildContext!=null&&(i2=w$2(w$2({},i2),h2.getChildContext())),C2&&!p2&&h2.getSnapshotBeforeUpdate!=null&&(g2=h2.getSnapshotBeforeUpdate(v2,y2)),f2=$$1(n2,d$3(T2=a2!=null&&a2.type===k$1&&a2.key==null?a2.props.children:a2)?T2:[T2],u2,t2,i2,r2,o2,e2,f2,c2,s2),h2.base=u2.__e,u2.__u&=-161,h2.__h.length&&e2.push(h2),m2&&(h2.__E=h2.__=null)}catch(n3){if(u2.__v=null,c2||o2!=null)if(n3.then){for(u2.__u|=c2?160:128;f2&&f2.nodeType===8&&f2.nextSibling;)f2=f2.nextSibling;o2[o2.indexOf(f2)]=null,u2.__e=f2}else for(A2=o2.length;A2--;)_$2(o2[A2]);else u2.__e=t2.__e,u2.__k=t2.__k;l$3.__e(n3,u2,t2)}else o2==null&&u2.__v===t2.__v?(u2.__k=t2.__k,u2.__e=t2.__e):f2=u2.__e=N(t2.__e,u2,t2,i2,r2,o2,e2,c2,s2);return(a2=l$3.diffed)&&a2(u2),128&u2.__u?void 0:f2}__name(j$1,"j$1");function z$2(n2,u2,t2){for(var i2=0;i2<t2.length;i2++)V$1(t2[i2],t2[++i2],t2[++i2]);l$3.__c&&l$3.__c(u2,n2),n2.some(function(u3){try{n2=u3.__h,u3.__h=[],n2.some(function(n3){n3.call(u3)})}catch(n3){l$3.__e(n3,u3.__v)}})}__name(z$2,"z$2");function N(u2,t2,i2,r2,o2,e2,f2,c2,s2){var a2,h2,v2,y2,w2,g2,m2,b2=i2.props,k2=t2.props,x2=t2.type;if(x2==="svg"?o2="http://www.w3.org/2000/svg":x2==="math"?o2="http://www.w3.org/1998/Math/MathML":o2||(o2="http://www.w3.org/1999/xhtml"),e2!=null){for(a2=0;a2<e2.length;a2++)if((w2=e2[a2])&&"setAttribute"in w2==!!x2&&(x2?w2.localName===x2:w2.nodeType===3)){u2=w2,e2[a2]=null;break}}if(u2==null){if(x2===null)return document.createTextNode(k2);u2=document.createElementNS(o2,x2,k2.is&&k2),c2&&(l$3.__m&&l$3.__m(t2,e2),c2=!1),e2=null}if(x2===null)b2===k2||c2&&u2.data===k2||(u2.data=k2);else{if(e2=e2&&n.call(u2.childNodes),b2=i2.props||p$3,!c2&&e2!=null)for(b2={},a2=0;a2<u2.attributes.length;a2++)b2[(w2=u2.attributes[a2]).name]=w2.value;for(a2 in b2)if(w2=b2[a2],a2!="children"){if(a2=="dangerouslySetInnerHTML")v2=w2;else if(!(a2 in k2)){if(a2=="value"&&"defaultValue"in k2||a2=="checked"&&"defaultChecked"in k2)continue;F$1(u2,a2,null,w2,o2)}}for(a2 in k2)w2=k2[a2],a2=="children"?y2=w2:a2=="dangerouslySetInnerHTML"?h2=w2:a2=="value"?g2=w2:a2=="checked"?m2=w2:c2&&typeof w2!="function"||b2[a2]===w2||F$1(u2,a2,w2,b2[a2],o2);if(h2)c2||v2&&(h2.__html===v2.__html||h2.__html===u2.innerHTML)||(u2.innerHTML=h2.__html),t2.__k=[];else if(v2&&(u2.innerHTML=""),$$1(u2,d$3(y2)?y2:[y2],t2,i2,r2,x2==="foreignObject"?"http://www.w3.org/1999/xhtml":o2,e2,f2,e2?e2[0]:i2.__k&&C$1(i2,0),c2,s2),e2!=null)for(a2=e2.length;a2--;)_$2(e2[a2]);c2||(a2="value",x2==="progress"&&g2==null?u2.removeAttribute("value"):g2!==void 0&&(g2!==u2[a2]||x2==="progress"&&!g2||x2==="option"&&g2!==b2[a2])&&F$1(u2,a2,g2,b2[a2],o2),a2="checked",m2!==void 0&&m2!==u2[a2]&&F$1(u2,a2,m2,b2[a2],o2))}return u2}__name(N,"N");function V$1(n2,u2,t2){try{if(typeof n2=="function"){var i2=typeof n2.__u=="function";i2&&n2.__u(),i2&&u2==null||(n2.__u=n2(u2))}else n2.current=u2}catch(n3){l$3.__e(n3,t2)}}__name(V$1,"V$1");function q$2(n2,u2,t2){var i2,r2;if(l$3.unmount&&l$3.unmount(n2),(i2=n2.ref)&&(i2.current&&i2.current!==n2.__e||V$1(i2,null,u2)),(i2=n2.__c)!=null){if(i2.componentWillUnmount)try{i2.componentWillUnmount()}catch(n3){l$3.__e(n3,u2)}i2.base=i2.__P=null}if(i2=n2.__k)for(r2=0;r2<i2.length;r2++)i2[r2]&&q$2(i2[r2],u2,t2||typeof n2.type!="function");t2||_$2(n2.__e),n2.__c=n2.__=n2.__e=void 0}__name(q$2,"q$2");function B$2(n2,l2,u2){return this.constructor(n2,u2)}__name(B$2,"B$2");function D$1(u2,t2,i2){var r2,o2,e2,f2;t2===document&&(t2=document.documentElement),l$3.__&&l$3.__(u2,t2),o2=(r2=typeof i2=="function")?null:t2.__k,e2=[],f2=[],j$1(t2,u2=(!r2&&i2||t2).__k=g$2(k$1,null,[u2]),o2||p$3,p$3,t2.namespaceURI,!r2&&i2?[i2]:o2?null:t2.firstChild?n.call(t2.childNodes):null,e2,!r2&&i2?i2:o2?o2.__e:t2.firstChild,r2,f2),z$2(e2,u2,f2)}__name(D$1,"D$1"),n=v$2.slice,l$3={__e:__name(function(n2,l2,u2,t2){for(var i2,r2,o2;l2=l2.__;)if((i2=l2.__c)&&!i2.__)try{if((r2=i2.constructor)&&r2.getDerivedStateFromError!=null&&(i2.setState(r2.getDerivedStateFromError(n2)),o2=i2.__d),i2.componentDidCatch!=null&&(i2.componentDidCatch(n2,t2||{}),o2=i2.__d),o2)return i2.__E=i2}catch(l3){n2=l3}throw n2},"__e")},u$3=0,t$2=__name(function(n2){return n2!=null&&n2.constructor==null},"t$2"),x.prototype.setState=function(n2,l2){var u2;u2=this.__s!=null&&this.__s!==this.state?this.__s:this.__s=w$2({},this.state),typeof n2=="function"&&(n2=n2(w$2({},u2),this.props)),n2&&w$2(u2,n2),n2!=null&&this.__v&&(l2&&this._sb.push(l2),M$1(this))},x.prototype.forceUpdate=function(n2){this.__v&&(this.__e=!0,n2&&this.__h.push(n2),M$1(this))},x.prototype.render=k$1,i$2=[],o$2=typeof Promise=="function"?Promise.prototype.then.bind(Promise.resolve()):setTimeout,e$2=__name(function(n2,l2){return n2.__v.__b-l2.__v.__b},"e$2"),P$1.__r=0,f$3=/(PointerCapture)$|Capture$/i,c$2=0,s$3=O$1(!1),a$2=O$1(!0);var t$1,r$1,u$2,i$1,o$1=0,f$2=[],c$1=l$3,e$1=c$1.__b,a$1=c$1.__r,v$1=c$1.diffed,l$2=c$1.__c,m=c$1.unmount,s$2=c$1.__;function d$2(n2,t2){c$1.__h&&c$1.__h(r$1,n2,o$1||t2),o$1=0;var u2=r$1.__H||(r$1.__H={__:[],__h:[]});return n2>=u2.__.length&&u2.__.push({}),u2.__[n2]}__name(d$2,"d$2");function h$1(n2){return o$1=1,p$2(D,n2)}__name(h$1,"h$1");function p$2(n2,u2,i2){var o2=d$2(t$1++,2);if(o2.t=n2,!o2.__c&&(o2.__=[i2?i2(u2):D(void 0,u2),function(n3){var t2=o2.__N?o2.__N[0]:o2.__[0],r2=o2.t(t2,n3);t2!==r2&&(o2.__N=[r2,o2.__[1]],o2.__c.setState({}))}],o2.__c=r$1,!r$1.u)){var f2=__name(function(n3,t2,r2){if(!o2.__c.__H)return!0;var u3=o2.__c.__H.__.filter(function(n4){return!!n4.__c});if(u3.every(function(n4){return!n4.__N}))return!c2||c2.call(this,n3,t2,r2);var i3=o2.__c.props!==n3;return u3.forEach(function(n4){if(n4.__N){var t3=n4.__[0];n4.__=n4.__N,n4.__N=void 0,t3!==n4.__[0]&&(i3=!0)}}),c2&&c2.call(this,n3,t2,r2)||i3},"f");r$1.u=!0;var c2=r$1.shouldComponentUpdate,e2=r$1.componentWillUpdate;r$1.componentWillUpdate=function(n3,t2,r2){if(this.__e){var u3=c2;c2=void 0,f2(n3,t2,r2),c2=u3}e2&&e2.call(this,n3,t2,r2)},r$1.shouldComponentUpdate=f2}return o2.__N||o2.__}__name(p$2,"p$2");function y$1(n2,u2){var i2=d$2(t$1++,3);!c$1.__s&&C(i2.__H,u2)&&(i2.__=n2,i2.i=u2,r$1.__H.__h.push(i2))}__name(y$1,"y$1");function A$1(n2){return o$1=5,T$1(function(){return{current:n2}},[])}__name(A$1,"A$1");function T$1(n2,r2){var u2=d$2(t$1++,7);return C(u2.__H,r2)&&(u2.__=n2(),u2.__H=r2,u2.__h=n2),u2.__}__name(T$1,"T$1");function q$1(n2,t2){return o$1=8,T$1(function(){return n2},t2)}__name(q$1,"q$1");function j(){for(var n2;n2=f$2.shift();)if(n2.__P&&n2.__H)try{n2.__H.__h.forEach(z$1),n2.__H.__h.forEach(B$1),n2.__H.__h=[]}catch(t2){n2.__H.__h=[],c$1.__e(t2,n2.__v)}}__name(j,"j"),c$1.__b=function(n2){r$1=null,e$1&&e$1(n2)},c$1.__=function(n2,t2){n2&&t2.__k&&t2.__k.__m&&(n2.__m=t2.__k.__m),s$2&&s$2(n2,t2)},c$1.__r=function(n2){a$1&&a$1(n2),t$1=0;var i2=(r$1=n2.__c).__H;i2&&(u$2===r$1?(i2.__h=[],r$1.__h=[],i2.__.forEach(function(n3){n3.__N&&(n3.__=n3.__N),n3.i=n3.__N=void 0})):(i2.__h.forEach(z$1),i2.__h.forEach(B$1),i2.__h=[],t$1=0)),u$2=r$1},c$1.diffed=function(n2){v$1&&v$1(n2);var t2=n2.__c;t2&&t2.__H&&(t2.__H.__h.length&&(f$2.push(t2)!==1&&i$1===c$1.requestAnimationFrame||((i$1=c$1.requestAnimationFrame)||w$1)(j)),t2.__H.__.forEach(function(n3){n3.i&&(n3.__H=n3.i),n3.i=void 0})),u$2=r$1=null},c$1.__c=function(n2,t2){t2.some(function(n3){try{n3.__h.forEach(z$1),n3.__h=n3.__h.filter(function(n4){return!n4.__||B$1(n4)})}catch(r2){t2.some(function(n4){n4.__h&&(n4.__h=[])}),t2=[],c$1.__e(r2,n3.__v)}}),l$2&&l$2(n2,t2)},c$1.unmount=function(n2){m&&m(n2);var t2,r2=n2.__c;r2&&r2.__H&&(r2.__H.__.forEach(function(n3){try{z$1(n3)}catch(n4){t2=n4}}),r2.__H=void 0,t2&&c$1.__e(t2,r2.__v))};var k=typeof requestAnimationFrame=="function";function w$1(n2){var t2,r2=__name(function(){clearTimeout(u2),k&&cancelAnimationFrame(t2),setTimeout(n2)},"r"),u2=setTimeout(r2,100);k&&(t2=requestAnimationFrame(r2))}__name(w$1,"w$1");function z$1(n2){var t2=r$1,u2=n2.__c;typeof u2=="function"&&(n2.__c=void 0,u2()),r$1=t2}__name(z$1,"z$1");function B$1(n2){var t2=r$1;n2.__c=n2.__(),r$1=t2}__name(B$1,"B$1");function C(n2,t2){return!n2||n2.length!==t2.length||t2.some(function(t3,r2){return t3!==n2[r2]})}__name(C,"C");function D(n2,t2){return typeof t2=="function"?t2(n2):t2}__name(D,"D");var i=Symbol.for("preact-signals");function t(){if(s$1>1)s$1--;else{for(var i2,t2=!1;h!==void 0;){var r2=h;for(h=void 0,f$1++;r2!==void 0;){var o2=r2.o;if(r2.o=void 0,r2.f&=-3,!(8&r2.f)&&c(r2))try{r2.c()}catch(r3){t2||(i2=r3,t2=!0)}r2=o2}}if(f$1=0,s$1--,t2)throw i2}}__name(t,"t");var o=void 0,h=void 0,s$1=0,f$1=0,v=0;function e(i2){if(o!==void 0){var t2=i2.n;if(t2===void 0||t2.t!==o)return t2={i:0,S:i2,p:o.s,n:void 0,t:o,e:void 0,x:void 0,r:t2},o.s!==void 0&&(o.s.n=t2),o.s=t2,i2.n=t2,32&o.f&&i2.S(t2),t2;if(t2.i===-1)return t2.i=0,t2.n!==void 0&&(t2.n.p=t2.p,t2.p!==void 0&&(t2.p.n=t2.n),t2.p=o.s,t2.n=void 0,o.s.n=t2,o.s=t2),t2}}__name(e,"e");function u$1(i2){this.v=i2,this.i=0,this.n=void 0,this.t=void 0}__name(u$1,"u$1"),u$1.prototype.brand=i,u$1.prototype.h=function(){return!0},u$1.prototype.S=function(i2){this.t!==i2&&i2.e===void 0&&(i2.x=this.t,this.t!==void 0&&(this.t.e=i2),this.t=i2)},u$1.prototype.U=function(i2){if(this.t!==void 0){var t2=i2.e,r2=i2.x;t2!==void 0&&(t2.x=r2,i2.e=void 0),r2!==void 0&&(r2.e=t2,i2.x=void 0),i2===this.t&&(this.t=r2)}},u$1.prototype.subscribe=function(i2){var t2=this;return E(function(){var r2=t2.value,n2=o;o=void 0;try{i2(r2)}finally{o=n2}})},u$1.prototype.valueOf=function(){return this.value},u$1.prototype.toString=function(){return this.value+""},u$1.prototype.toJSON=function(){return this.value},u$1.prototype.peek=function(){var i2=o;o=void 0;try{return this.value}finally{o=i2}},Object.defineProperty(u$1.prototype,"value",{get:__name(function(){var i2=e(this);return i2!==void 0&&(i2.i=this.i),this.v},"get"),set:__name(function(i2){if(i2!==this.v){if(f$1>100)throw new Error("Cycle detected");this.v=i2,this.i++,v++,s$1++;try{for(var r2=this.t;r2!==void 0;r2=r2.x)r2.t.N()}finally{t()}}},"set")});function d$1(i2){return new u$1(i2)}__name(d$1,"d$1");function c(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n)if(t2.S.i!==t2.i||!t2.S.h()||t2.S.i!==t2.i)return!0;return!1}__name(c,"c");function a(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n){var r2=t2.S.n;if(r2!==void 0&&(t2.r=r2),t2.S.n=t2,t2.i=-1,t2.n===void 0){i2.s=t2;break}}}__name(a,"a");function l$1(i2){for(var t2=i2.s,r2=void 0;t2!==void 0;){var o2=t2.p;t2.i===-1?(t2.S.U(t2),o2!==void 0&&(o2.n=t2.n),t2.n!==void 0&&(t2.n.p=o2)):r2=t2,t2.S.n=t2.r,t2.r!==void 0&&(t2.r=void 0),t2=o2}i2.s=r2}__name(l$1,"l$1");function y(i2){u$1.call(this,void 0),this.x=i2,this.s=void 0,this.g=v-1,this.f=4}__name(y,"y"),(y.prototype=new u$1).h=function(){if(this.f&=-3,1&this.f)return!1;if((36&this.f)==32||(this.f&=-5,this.g===v))return!0;if(this.g=v,this.f|=1,this.i>0&&!c(this))return this.f&=-2,!0;var i2=o;try{a(this),o=this;var t2=this.x();(16&this.f||this.v!==t2||this.i===0)&&(this.v=t2,this.f&=-17,this.i++)}catch(i3){this.v=i3,this.f|=16,this.i++}return o=i2,l$1(this),this.f&=-2,!0},y.prototype.S=function(i2){if(this.t===void 0){this.f|=36;for(var t2=this.s;t2!==void 0;t2=t2.n)t2.S.S(t2)}u$1.prototype.S.call(this,i2)},y.prototype.U=function(i2){if(this.t!==void 0&&(u$1.prototype.U.call(this,i2),this.t===void 0)){this.f&=-33;for(var t2=this.s;t2!==void 0;t2=t2.n)t2.S.U(t2)}},y.prototype.N=function(){if(!(2&this.f)){this.f|=6;for(var i2=this.t;i2!==void 0;i2=i2.x)i2.t.N()}},Object.defineProperty(y.prototype,"value",{get:__name(function(){if(1&this.f)throw new Error("Cycle detected");var i2=e(this);if(this.h(),i2!==void 0&&(i2.i=this.i),16&this.f)throw this.v;return this.v},"get")});function w(i2){return new y(i2)}__name(w,"w");function _$1(i2){var r2=i2.u;if(i2.u=void 0,typeof r2=="function"){s$1++;var n2=o;o=void 0;try{r2()}catch(t2){throw i2.f&=-2,i2.f|=8,g$1(i2),t2}finally{o=n2,t()}}}__name(_$1,"_$1");function g$1(i2){for(var t2=i2.s;t2!==void 0;t2=t2.n)t2.S.U(t2);i2.x=void 0,i2.s=void 0,_$1(i2)}__name(g$1,"g$1");function p$1(i2){if(o!==this)throw new Error("Out-of-order effect");l$1(this),o=i2,this.f&=-2,8&this.f&&g$1(this),t()}__name(p$1,"p$1");function b(i2){this.x=i2,this.u=void 0,this.s=void 0,this.o=void 0,this.f=32}__name(b,"b"),b.prototype.c=function(){var i2=this.S();try{if(8&this.f||this.x===void 0)return;var t2=this.x();typeof t2=="function"&&(this.u=t2)}finally{i2()}},b.prototype.S=function(){if(1&this.f)throw new Error("Cycle detected");this.f|=1,this.f&=-9,_$1(this),a(this),s$1++;var i2=o;return o=this,p$1.bind(this,i2)},b.prototype.N=function(){2&this.f||(this.f|=2,this.o=h,h=this)},b.prototype.d=function(){this.f|=8,1&this.f||g$1(this)};function E(i2){var t2=new b(i2);try{t2.c()}catch(i3){throw t2.d(),i3}return t2.d.bind(t2)}__name(E,"E");var s;function l(n2,i2){l$3[n2]=i2.bind(null,l$3[n2]||function(){})}__name(l,"l");function d(n2){s&&s(),s=n2&&n2.S()}__name(d,"d");function p(n2){var r2=this,f2=n2.data,o2=useSignal(f2);o2.value=f2;var e2=T$1(function(){for(var n3=r2.__v;n3=n3.__;)if(n3.__c){n3.__c.__$f|=4;break}return r2.__$u.c=function(){var n4,t2=r2.__$u.S(),f3=e2.value;t2(),t$2(f3)||((n4=r2.base)==null?void 0:n4.nodeType)!==3?(r2.__$f|=1,r2.setState({})):r2.base.data=f3},w(function(){var n4=o2.value.value;return n4===0?0:n4===!0?"":n4||""})},[]);return e2.value}__name(p,"p"),p.displayName="_st",Object.defineProperties(u$1.prototype,{constructor:{configurable:!0,value:void 0},type:{configurable:!0,value:p},props:{configurable:!0,get:__name(function(){return{data:this}},"get")},__b:{configurable:!0,value:1}}),l("__b",function(n2,r2){if(typeof r2.type=="string"){var i2,t2=r2.props;for(var f2 in t2)if(f2!=="children"){var o2=t2[f2];o2 instanceof u$1&&(i2||(r2.__np=i2={}),i2[f2]=o2,t2[f2]=o2.peek())}}n2(r2)}),l("__r",function(n2,r2){d();var i2,t2=r2.__c;t2&&(t2.__$f&=-2,(i2=t2.__$u)===void 0&&(t2.__$u=i2=function(n3){var r3;return E(function(){r3=this}),r3.c=function(){t2.__$f|=1,t2.setState({})},r3}())),d(i2),n2(r2)}),l("__e",function(n2,r2,i2,t2){d(),n2(r2,i2,t2)}),l("diffed",function(n2,r2){d();var i2;if(typeof r2.type=="string"&&(i2=r2.__e)){var t2=r2.__np,f2=r2.props;if(t2){var o2=i2.U;if(o2)for(var e2 in o2){var u2=o2[e2];u2!==void 0&&!(e2 in t2)&&(u2.d(),o2[e2]=void 0)}else i2.U=o2={};for(var a2 in t2){var c2=o2[a2],s2=t2[a2];c2===void 0?(c2=_(i2,a2,s2,f2),o2[a2]=c2):c2.o(s2,f2)}}}n2(r2)});function _(n2,r2,i2,t2){var f2=r2 in n2&&n2.ownerSVGElement===void 0,o2=d$1(i2);return{o:__name(function(n3,r3){o2.value=n3,t2=r3},"o"),d:E(function(){var i3=o2.value.value;t2[r2]!==i3&&(t2[r2]=i3,f2?n2[r2]=i3:i3?n2.setAttribute(r2,i3):n2.removeAttribute(r2))})}}__name(_,"_"),l("unmount",function(n2,r2){if(typeof r2.type=="string"){var i2=r2.__e;if(i2){var t2=i2.U;if(t2){i2.U=void 0;for(var f2 in t2){var o2=t2[f2];o2&&o2.d()}}}}else{var e2=r2.__c;if(e2){var u2=e2.__$u;u2&&(e2.__$u=void 0,u2.d())}}n2(r2)}),l("__h",function(n2,r2,i2,t2){(t2<3||t2===9)&&(r2.__$f|=2),n2(r2,i2,t2)}),x.prototype.shouldComponentUpdate=function(n2,r2){var i2=this.__$u;if(!(i2&&i2.s!==void 0||4&this.__$f)||3&this.__$f)return!0;for(var t2 in r2)return!0;for(var f2 in n2)if(f2!=="__source"&&n2[f2]!==this.props[f2])return!0;for(var o2 in this.props)if(!(o2 in n2))return!0;return!1};function useSignal(n2){return T$1(function(){return d$1(n2)},[])}__name(useSignal,"useSignal");function g(n2,t2){for(var e2 in n2)if(e2!=="__source"&&!(e2 in t2))return!0;for(var r2 in t2)if(r2!=="__source"&&n2[r2]!==t2[r2])return!0;return!1}__name(g,"g");function I(n2,t2){this.props=n2,this.context=t2}__name(I,"I"),(I.prototype=new x).isPureReactComponent=!0,I.prototype.shouldComponentUpdate=function(n2,t2){return g(this.props,n2)||g(this.state,t2)};var M=l$3.__b;l$3.__b=function(n2){n2.type&&n2.type.__f&&n2.ref&&(n2.props.ref=n2.ref,n2.ref=null),M&&M(n2)};var T=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.forward_ref")||3911;function A(n2){function t2(t3){if(!("ref"in t3))return n2(t3,null);var e2=t3.ref;delete t3.ref;var r2=n2(t3,e2);return t3.ref=e2,r2}return __name(t2,"t"),t2.$$typeof=T,t2.render=t2,t2.prototype.isReactComponent=t2.__f=!0,t2.displayName="ForwardRef("+(n2.displayName||n2.name)+")",t2}__name(A,"A");var O=l$3.__e;l$3.__e=function(n2,t2,e2,r2){if(n2.then){for(var u2,o2=t2;o2=o2.__;)if((u2=o2.__c)&&u2.__c)return t2.__e==null&&(t2.__e=e2.__e,t2.__k=e2.__k),u2.__c(n2,t2)}O(n2,t2,e2,r2)};var F=l$3.unmount;function U(n2,t2,e2){return n2&&(n2.__c&&n2.__c.__H&&(n2.__c.__H.__.forEach(function(n3){typeof n3.__c=="function"&&n3.__c()}),n2.__c.__H=null),(n2=function(n3,t3){for(var e3 in t3)n3[e3]=t3[e3];return n3}({},n2)).__c!=null&&(n2.__c.__P===e2&&(n2.__c.__P=t2),n2.__c=null),n2.__k=n2.__k&&n2.__k.map(function(n3){return U(n3,t2,e2)})),n2}__name(U,"U");function V(n2,t2,e2){return n2&&e2&&(n2.__v=null,n2.__k=n2.__k&&n2.__k.map(function(n3){return V(n3,t2,e2)}),n2.__c&&n2.__c.__P===t2&&(n2.__e&&e2.appendChild(n2.__e),n2.__c.__e=!0,n2.__c.__P=e2)),n2}__name(V,"V");function W(){this.__u=0,this.o=null,this.__b=null}__name(W,"W");function P(n2){var t2=n2.__.__c;return t2&&t2.__a&&t2.__a(n2)}__name(P,"P");function z(){this.i=null,this.l=null}__name(z,"z"),l$3.unmount=function(n2){var t2=n2.__c;t2&&t2.__R&&t2.__R(),t2&&32&n2.__u&&(n2.type=null),F&&F(n2)},(W.prototype=new x).__c=function(n2,t2){var e2=t2.__c,r2=this;r2.o==null&&(r2.o=[]),r2.o.push(e2);var u2=P(r2.__v),o2=!1,i2=__name(function(){o2||(o2=!0,e2.__R=null,u2?u2(c2):c2())},"i");e2.__R=i2;var c2=__name(function(){if(!--r2.__u){if(r2.state.__a){var n3=r2.state.__a;r2.__v.__k[0]=V(n3,n3.__c.__P,n3.__c.__O)}var t3;for(r2.setState({__a:r2.__b=null});t3=r2.o.pop();)t3.forceUpdate()}},"c");r2.__u++||32&t2.__u||r2.setState({__a:r2.__b=r2.__v.__k[0]}),n2.then(i2,i2)},W.prototype.componentWillUnmount=function(){this.o=[]},W.prototype.render=function(n2,e2){if(this.__b){if(this.__v.__k){var r2=document.createElement("div"),o2=this.__v.__k[0].__c;this.__v.__k[0]=U(this.__b,r2,o2.__O=o2.__P)}this.__b=null}var i2=e2.__a&&g$2(k$1,null,n2.fallback);return i2&&(i2.__u&=-33),[g$2(k$1,null,e2.__a?null:n2.children),i2]};var B=__name(function(n2,t2,e2){if(++e2[1]===e2[0]&&n2.l.delete(t2),n2.props.revealOrder&&(n2.props.revealOrder[0]!=="t"||!n2.l.size))for(e2=n2.i;e2;){for(;e2.length>3;)e2.pop()();if(e2[1]<e2[0])break;n2.i=e2=e2[2]}},"B");(z.prototype=new x).__a=function(n2){var t2=this,e2=P(t2.__v),r2=t2.l.get(n2);return r2[0]++,function(u2){var o2=__name(function(){t2.props.revealOrder?(r2.push(u2),B(t2,n2,r2)):u2()},"o");e2?e2(o2):o2()}},z.prototype.render=function(n2){this.i=null,this.l=new Map;var t2=L(n2.children);n2.revealOrder&&n2.revealOrder[0]==="b"&&t2.reverse();for(var e2=t2.length;e2--;)this.l.set(t2[e2],this.i=[1,0,this.i]);return n2.children},z.prototype.componentDidUpdate=z.prototype.componentDidMount=function(){var n2=this;this.l.forEach(function(t2,e2){B(n2,e2,t2)})};var $=typeof Symbol<"u"&&Symbol.for&&Symbol.for("react.element")||60103,q=/^(?:accent|alignment|arabic|baseline|cap|clip(?!PathU)|color|dominant|fill|flood|font|glyph(?!R)|horiz|image(!S)|letter|lighting|marker(?!H|W|U)|overline|paint|pointer|shape|stop|strikethrough|stroke|text(?!L)|transform|underline|unicode|units|v|vector|vert|word|writing|x(?!C))[A-Z]/,G=/^on(Ani|Tra|Tou|BeforeInp|Compo)/,J=/[A-Z0-9]/g,K=typeof document<"u",Q=__name(function(n2){return(typeof Symbol<"u"&&typeof Symbol()=="symbol"?/fil|che|rad/:/fil|che|ra/).test(n2)},"Q");x.prototype.isReactComponent={},["componentWillMount","componentWillReceiveProps","componentWillUpdate"].forEach(function(t2){Object.defineProperty(x.prototype,t2,{configurable:!0,get:__name(function(){return this["UNSAFE_"+t2]},"get"),set:__name(function(n2){Object.defineProperty(this,t2,{configurable:!0,writable:!0,value:n2})},"set")})});var tn=l$3.event;function en(){}__name(en,"en");function rn(){return this.cancelBubble}__name(rn,"rn");function un(){return this.defaultPrevented}__name(un,"un"),l$3.event=function(n2){return tn&&(n2=tn(n2)),n2.persist=en,n2.isPropagationStopped=rn,n2.isDefaultPrevented=un,n2.nativeEvent=n2};var cn$1={enumerable:!1,configurable:!0,get:__name(function(){return this.class},"get")},fn=l$3.vnode;l$3.vnode=function(n2){typeof n2.type=="string"&&function(n3){var t2=n3.props,e2=n3.type,u2={},o2=e2.indexOf("-")===-1;for(var i2 in t2){var c2=t2[i2];if(!(i2==="value"&&"defaultValue"in t2&&c2==null||K&&i2==="children"&&e2==="noscript"||i2==="class"||i2==="className")){var f2=i2.toLowerCase();i2==="defaultValue"&&"value"in t2&&t2.value==null?i2="value":i2==="download"&&c2===!0?c2="":f2==="translate"&&c2==="no"?c2=!1:f2[0]==="o"&&f2[1]==="n"?f2==="ondoubleclick"?i2="ondblclick":f2!=="onchange"||e2!=="input"&&e2!=="textarea"||Q(t2.type)?f2==="onfocus"?i2="onfocusin":f2==="onblur"?i2="onfocusout":G.test(i2)&&(i2=f2):f2=i2="oninput":o2&&q.test(i2)?i2=i2.replace(J,"-$&").toLowerCase():c2===null&&(c2=void 0),f2==="oninput"&&u2[i2=f2]&&(i2="oninputCapture"),u2[i2]=c2}}e2=="select"&&u2.multiple&&Array.isArray(u2.value)&&(u2.value=L(t2.children).forEach(function(n4){n4.props.selected=u2.value.indexOf(n4.props.value)!=-1})),e2=="select"&&u2.defaultValue!=null&&(u2.value=L(t2.children).forEach(function(n4){n4.props.selected=u2.multiple?u2.defaultValue.indexOf(n4.props.value)!=-1:u2.defaultValue==n4.props.value})),t2.class&&!t2.className?(u2.class=t2.class,Object.defineProperty(u2,"className",cn$1)):(t2.className&&!t2.class||t2.class&&t2.className)&&(u2.class=u2.className=t2.className),n3.props=u2}(n2),n2.$$typeof=$,fn&&fn(n2)};var ln=l$3.__r;l$3.__r=function(n2){ln&&ln(n2),n2.__c};var an=l$3.diffed;l$3.diffed=function(n2){an&&an(n2);var t2=n2.props,e2=n2.__e;e2!=null&&n2.type==="textarea"&&"value"in t2&&t2.value!==e2.value&&(e2.value=t2.value==null?"":t2.value)};var f=0;function u(e2,t2,n2,o2,i2,u2){t2||(t2={});var a2,c2,l2=t2;"ref"in t2&&(a2=t2.ref,delete t2.ref);var p2={type:e2,props:l2,key:n2,ref:a2,__k:null,__:null,__b:0,__e:null,__c:null,constructor:void 0,__v:--f,__i:-1,__u:0,__source:i2,__self:u2};if(typeof e2=="function"&&(a2=e2.defaultProps))for(c2 in a2)l2[c2]===void 0&&(l2[c2]=a2[c2]);return l$3.vnode&&l$3.vnode(p2),p2}__name(u,"u");function r(e2){var t2,f2,n2="";if(typeof e2=="string"||typeof e2=="number")n2+=e2;else if(typeof e2=="object")if(Array.isArray(e2)){var o2=e2.length;for(t2=0;t2<o2;t2++)e2[t2]&&(f2=r(e2[t2]))&&(n2&&(n2+=" "),n2+=f2)}else for(f2 in e2)e2[f2]&&(n2&&(n2+=" "),n2+=f2);return n2}__name(r,"r");function clsx(){for(var e2,t2,f2=0,n2="",o2=arguments.length;f2<o2;f2++)(e2=arguments[f2])&&(t2=r(e2))&&(n2&&(n2+=" "),n2+=t2);return n2}__name(clsx,"clsx");var CLASS_PART_SEPARATOR="-",createClassGroupUtils=__name(config2=>{const classMap=createClassMap(config2),{conflictingClassGroups,conflictingClassGroupModifiers}=config2;return{getClassGroupId:__name(className=>{const classParts=className.split(CLASS_PART_SEPARATOR);return classParts[0]===""&&classParts.length!==1&&classParts.shift(),getGroupRecursive(classParts,classMap)||getGroupIdForArbitraryProperty(className)},"getClassGroupId"),getConflictingClassGroupIds:__name((classGroupId,hasPostfixModifier)=>{const conflicts=conflictingClassGroups[classGroupId]||[];return hasPostfixModifier&&conflictingClassGroupModifiers[classGroupId]?[...conflicts,...conflictingClassGroupModifiers[classGroupId]]:conflicts},"getConflictingClassGroupIds")}},"createClassGroupUtils"),getGroupRecursive=__name((classParts,classPartObject)=>{var _a2;if(classParts.length===0)return classPartObject.classGroupId;const currentClassPart=classParts[0],nextClassPartObject=classPartObject.nextPart.get(currentClassPart),classGroupFromNextClassPart=nextClassPartObject?getGroupRecursive(classParts.slice(1),nextClassPartObject):void 0;if(classGroupFromNextClassPart)return classGroupFromNextClassPart;if(classPartObject.validators.length===0)return;const classRest=classParts.join(CLASS_PART_SEPARATOR);return(_a2=classPartObject.validators.find(({validator})=>validator(classRest)))==null?void 0:_a2.classGroupId},"getGroupRecursive"),arbitraryPropertyRegex=/^\[(.+)\]$/,getGroupIdForArbitraryProperty=__name(className=>{if(arbitraryPropertyRegex.test(className)){const arbitraryPropertyClassName=arbitraryPropertyRegex.exec(className)[1],property=arbitraryPropertyClassName==null?void 0:arbitraryPropertyClassName.substring(0,arbitraryPropertyClassName.indexOf(":"));if(property)return"arbitrary.."+property}},"getGroupIdForArbitraryProperty"),createClassMap=__name(config2=>{const{theme,prefix}=config2,classMap={nextPart:new Map,validators:[]};return getPrefixedClassGroupEntries(Object.entries(config2.classGroups),prefix).forEach(([classGroupId,classGroup])=>{processClassesRecursively(classGroup,classMap,classGroupId,theme)}),classMap},"createClassMap"),processClassesRecursively=__name((classGroup,classPartObject,classGroupId,theme)=>{classGroup.forEach(classDefinition=>{if(typeof classDefinition=="string"){const classPartObjectToEdit=classDefinition===""?classPartObject:getPart(classPartObject,classDefinition);classPartObjectToEdit.classGroupId=classGroupId;return}if(typeof classDefinition=="function"){if(isThemeGetter(classDefinition)){processClassesRecursively(classDefinition(theme),classPartObject,classGroupId,theme);return}classPartObject.validators.push({validator:classDefinition,classGroupId});return}Object.entries(classDefinition).forEach(([key,classGroup2])=>{processClassesRecursively(classGroup2,getPart(classPartObject,key),classGroupId,theme)})})},"processClassesRecursively"),getPart=__name((classPartObject,path)=>{let currentClassPartObject=classPartObject;return path.split(CLASS_PART_SEPARATOR).forEach(pathPart=>{currentClassPartObject.nextPart.has(pathPart)||currentClassPartObject.nextPart.set(pathPart,{nextPart:new Map,validators:[]}),currentClassPartObject=currentClassPartObject.nextPart.get(pathPart)}),currentClassPartObject},"getPart"),isThemeGetter=__name(func=>func.isThemeGetter,"isThemeGetter"),getPrefixedClassGroupEntries=__name((classGroupEntries,prefix)=>prefix?classGroupEntries.map(([classGroupId,classGroup])=>{const prefixedClassGroup=classGroup.map(classDefinition=>typeof classDefinition=="string"?prefix+classDefinition:typeof classDefinition=="object"?Object.fromEntries(Object.entries(classDefinition).map(([key,value])=>[prefix+key,value])):classDefinition);return[classGroupId,prefixedClassGroup]}):classGroupEntries,"getPrefixedClassGroupEntries"),createLruCache=__name(maxCacheSize=>{if(maxCacheSize<1)return{get:__name(()=>{},"get"),set:__name(()=>{},"set")};let cacheSize=0,cache2=new Map,previousCache=new Map;const update=__name((key,value)=>{cache2.set(key,value),cacheSize++,cacheSize>maxCacheSize&&(cacheSize=0,previousCache=cache2,cache2=new Map)},"update");return{get(key){let value=cache2.get(key);if(value!==void 0)return value;if((value=previousCache.get(key))!==void 0)return update(key,value),value},set(key,value){cache2.has(key)?cache2.set(key,value):update(key,value)}}},"createLruCache"),IMPORTANT_MODIFIER="!",createParseClassName=__name(config2=>{const{separator,experimentalParseClassName}=config2,isSeparatorSingleCharacter=separator.length===1,firstSeparatorCharacter=separator[0],separatorLength=separator.length,parseClassName=__name(className=>{const modifiers=[];let bracketDepth=0,modifierStart=0,postfixModifierPosition;for(let index=0;index<className.length;index++){let currentCharacter=className[index];if(bracketDepth===0){if(currentCharacter===firstSeparatorCharacter&&(isSeparatorSingleCharacter||className.slice(index,index+separatorLength)===separator)){modifiers.push(className.slice(modifierStart,index)),modifierStart=index+separatorLength;continue}if(currentCharacter==="/"){postfixModifierPosition=index;continue}}currentCharacter==="["?bracketDepth++:currentCharacter==="]"&&bracketDepth--}const baseClassNameWithImportantModifier=modifiers.length===0?className:className.substring(modifierStart),hasImportantModifier=baseClassNameWithImportantModifier.startsWith(IMPORTANT_MODIFIER),baseClassName=hasImportantModifier?baseClassNameWithImportantModifier.substring(1):baseClassNameWithImportantModifier,maybePostfixModifierPosition=postfixModifierPosition&&postfixModifierPosition>modifierStart?postfixModifierPosition-modifierStart:void 0;return{modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition}},"parseClassName");return experimentalParseClassName?className=>experimentalParseClassName({className,parseClassName}):parseClassName},"createParseClassName"),sortModifiers=__name(modifiers=>{if(modifiers.length<=1)return modifiers;const sortedModifiers=[];let unsortedModifiers=[];return modifiers.forEach(modifier=>{modifier[0]==="["?(sortedModifiers.push(...unsortedModifiers.sort(),modifier),unsortedModifiers=[]):unsortedModifiers.push(modifier)}),sortedModifiers.push(...unsortedModifiers.sort()),sortedModifiers},"sortModifiers"),createConfigUtils=__name(config2=>({cache:createLruCache(config2.cacheSize),parseClassName:createParseClassName(config2),...createClassGroupUtils(config2)}),"createConfigUtils"),SPLIT_CLASSES_REGEX=/\s+/,mergeClassList=__name((classList,configUtils)=>{const{parseClassName,getClassGroupId,getConflictingClassGroupIds}=configUtils,classGroupsInConflict=[],classNames=classList.trim().split(SPLIT_CLASSES_REGEX);let result="";for(let index=classNames.length-1;index>=0;index-=1){const originalClassName=classNames[index],{modifiers,hasImportantModifier,baseClassName,maybePostfixModifierPosition}=parseClassName(originalClassName);let hasPostfixModifier=!!maybePostfixModifierPosition,classGroupId=getClassGroupId(hasPostfixModifier?baseClassName.substring(0,maybePostfixModifierPosition):baseClassName);if(!classGroupId){if(!hasPostfixModifier){result=originalClassName+(result.length>0?" "+result:result);continue}if(classGroupId=getClassGroupId(baseClassName),!classGroupId){result=originalClassName+(result.length>0?" "+result:result);continue}hasPostfixModifier=!1}const variantModifier=sortModifiers(modifiers).join(":"),modifierId=hasImportantModifier?variantModifier+IMPORTANT_MODIFIER:variantModifier,classId=modifierId+classGroupId;if(classGroupsInConflict.includes(classId))continue;classGroupsInConflict.push(classId);const conflictGroups=getConflictingClassGroupIds(classGroupId,hasPostfixModifier);for(let i2=0;i2<conflictGroups.length;++i2){const group=conflictGroups[i2];classGroupsInConflict.push(modifierId+group)}result=originalClassName+(result.length>0?" "+result:result)}return result},"mergeClassList");function twJoin(){let index=0,argument,resolvedValue,string="";for(;index<arguments.length;)(argument=arguments[index++])&&(resolvedValue=toValue(argument))&&(string&&(string+=" "),string+=resolvedValue);return string}__name(twJoin,"twJoin");var toValue=__name(mix=>{if(typeof mix=="string")return mix;let resolvedValue,string="";for(let k2=0;k2<mix.length;k2++)mix[k2]&&(resolvedValue=toValue(mix[k2]))&&(string&&(string+=" "),string+=resolvedValue);return string},"toValue");function createTailwindMerge(createConfigFirst,...createConfigRest){let configUtils,cacheGet,cacheSet,functionToCall=initTailwindMerge;function initTailwindMerge(classList){const config2=createConfigRest.reduce((previousConfig,createConfigCurrent)=>createConfigCurrent(previousConfig),createConfigFirst());return configUtils=createConfigUtils(config2),cacheGet=configUtils.cache.get,cacheSet=configUtils.cache.set,functionToCall=tailwindMerge,tailwindMerge(classList)}__name(initTailwindMerge,"initTailwindMerge");function tailwindMerge(classList){const cachedResult=cacheGet(classList);if(cachedResult)return cachedResult;const result=mergeClassList(classList,configUtils);return cacheSet(classList,result),result}return __name(tailwindMerge,"tailwindMerge"),__name(function(){return functionToCall(twJoin.apply(null,arguments))},"callTailwindMerge")}__name(createTailwindMerge,"createTailwindMerge");var fromTheme=__name(key=>{const themeGetter=__name(theme=>theme[key]||[],"themeGetter");return themeGetter.isThemeGetter=!0,themeGetter},"fromTheme"),arbitraryValueRegex=/^\[(?:([a-z-]+):)?(.+)\]$/i,fractionRegex=/^\d+\/\d+$/,stringLengths=new Set(["px","full","screen"]),tshirtUnitRegex=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,lengthUnitRegex=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,colorFunctionRegex=/^(rgba?|hsla?|hwb|(ok)?(lab|lch))\(.+\)$/,shadowRegex=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,imageRegex=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,isLength=__name(value=>isNumber(value)||stringLengths.has(value)||fractionRegex.test(value),"isLength"),isArbitraryLength=__name(value=>getIsArbitraryValue(value,"length",isLengthOnly),"isArbitraryLength"),isNumber=__name(value=>!!value&&!Number.isNaN(Number(value)),"isNumber"),isArbitraryNumber=__name(value=>getIsArbitraryValue(value,"number",isNumber),"isArbitraryNumber"),isInteger=__name(value=>!!value&&Number.isInteger(Number(value)),"isInteger"),isPercent=__name(value=>value.endsWith("%")&&isNumber(value.slice(0,-1)),"isPercent"),isArbitraryValue=__name(value=>arbitraryValueRegex.test(value),"isArbitraryValue"),isTshirtSize=__name(value=>tshirtUnitRegex.test(value),"isTshirtSize"),sizeLabels=new Set(["length","size","percentage"]),isArbitrarySize=__name(value=>getIsArbitraryValue(value,sizeLabels,isNever),"isArbitrarySize"),isArbitraryPosition=__name(value=>getIsArbitraryValue(value,"position",isNever),"isArbitraryPosition"),imageLabels=new Set(["image","url"]),isArbitraryImage=__name(value=>getIsArbitraryValue(value,imageLabels,isImage),"isArbitraryImage"),isArbitraryShadow=__name(value=>getIsArbitraryValue(value,"",isShadow),"isArbitraryShadow"),isAny=__name(()=>!0,"isAny"),getIsArbitraryValue=__name((value,label,testValue)=>{const result=arbitraryValueRegex.exec(value);return result?result[1]?typeof label=="string"?result[1]===label:label.has(result[1]):testValue(result[2]):!1},"getIsArbitraryValue"),isLengthOnly=__name(value=>lengthUnitRegex.test(value)&&!colorFunctionRegex.test(value),"isLengthOnly"),isNever=__name(()=>!1,"isNever"),isShadow=__name(value=>shadowRegex.test(value),"isShadow"),isImage=__name(value=>imageRegex.test(value),"isImage"),getDefaultConfig=__name(()=>{const colors=fromTheme("colors"),spacing=fromTheme("spacing"),blur=fromTheme("blur"),brightness=fromTheme("brightness"),borderColor=fromTheme("borderColor"),borderRadius=fromTheme("borderRadius"),borderSpacing=fromTheme("borderSpacing"),borderWidth=fromTheme("borderWidth"),contrast=fromTheme("contrast"),grayscale=fromTheme("grayscale"),hueRotate=fromTheme("hueRotate"),invert=fromTheme("invert"),gap=fromTheme("gap"),gradientColorStops=fromTheme("gradientColorStops"),gradientColorStopPositions=fromTheme("gradientColorStopPositions"),inset=fromTheme("inset"),margin=fromTheme("margin"),opacity=fromTheme("opacity"),padding=fromTheme("padding"),saturate=fromTheme("saturate"),scale=fromTheme("scale"),sepia=fromTheme("sepia"),skew=fromTheme("skew"),space=fromTheme("space"),translate=fromTheme("translate"),getOverscroll=__name(()=>["auto","contain","none"],"getOverscroll"),getOverflow=__name(()=>["auto","hidden","clip","visible","scroll"],"getOverflow"),getSpacingWithAutoAndArbitrary=__name(()=>["auto",isArbitraryValue,spacing],"getSpacingWithAutoAndArbitrary"),getSpacingWithArbitrary=__name(()=>[isArbitraryValue,spacing],"getSpacingWithArbitrary"),getLengthWithEmptyAndArbitrary=__name(()=>["",isLength,isArbitraryLength],"getLengthWithEmptyAndArbitrary"),getNumberWithAutoAndArbitrary=__name(()=>["auto",isNumber,isArbitraryValue],"getNumberWithAutoAndArbitrary"),getPositions=__name(()=>["bottom","center","left","left-bottom","left-top","right","right-bottom","right-top","top"],"getPositions"),getLineStyles=__name(()=>["solid","dashed","dotted","double","none"],"getLineStyles"),getBlendModes=__name(()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],"getBlendModes"),getAlign=__name(()=>["start","end","center","between","around","evenly","stretch"],"getAlign"),getZeroAndEmpty=__name(()=>["","0",isArbitraryValue],"getZeroAndEmpty"),getBreaks=__name(()=>["auto","avoid","all","avoid-page","page","left","right","column"],"getBreaks"),getNumberAndArbitrary=__name(()=>[isNumber,isArbitraryValue],"getNumberAndArbitrary");return{cacheSize:500,separator:":",theme:{colors:[isAny],spacing:[isLength,isArbitraryLength],blur:["none","",isTshirtSize,isArbitraryValue],brightness:getNumberAndArbitrary(),borderColor:[colors],borderRadius:["none","","full",isTshirtSize,isArbitraryValue],borderSpacing:getSpacingWithArbitrary(),borderWidth:getLengthWithEmptyAndArbitrary(),contrast:getNumberAndArbitrary(),grayscale:getZeroAndEmpty(),hueRotate:getNumberAndArbitrary(),invert:getZeroAndEmpty(),gap:getSpacingWithArbitrary(),gradientColorStops:[colors],gradientColorStopPositions:[isPercent,isArbitraryLength],inset:getSpacingWithAutoAndArbitrary(),margin:getSpacingWithAutoAndArbitrary(),opacity:getNumberAndArbitrary(),padding:getSpacingWithArbitrary(),saturate:getNumberAndArbitrary(),scale:getNumberAndArbitrary(),sepia:getZeroAndEmpty(),skew:getNumberAndArbitrary(),space:getSpacingWithArbitrary(),translate:getSpacingWithArbitrary()},classGroups:{aspect:[{aspect:["auto","square","video",isArbitraryValue]}],container:["container"],columns:[{columns:[isTshirtSize]}],"break-after":[{"break-after":getBreaks()}],"break-before":[{"break-before":getBreaks()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:[...getPositions(),isArbitraryValue]}],overflow:[{overflow:getOverflow()}],"overflow-x":[{"overflow-x":getOverflow()}],"overflow-y":[{"overflow-y":getOverflow()}],overscroll:[{overscroll:getOverscroll()}],"overscroll-x":[{"overscroll-x":getOverscroll()}],"overscroll-y":[{"overscroll-y":getOverscroll()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:[inset]}],"inset-x":[{"inset-x":[inset]}],"inset-y":[{"inset-y":[inset]}],start:[{start:[inset]}],end:[{end:[inset]}],top:[{top:[inset]}],right:[{right:[inset]}],bottom:[{bottom:[inset]}],left:[{left:[inset]}],visibility:["visible","invisible","collapse"],z:[{z:["auto",isInteger,isArbitraryValue]}],basis:[{basis:getSpacingWithAutoAndArbitrary()}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["wrap","wrap-reverse","nowrap"]}],flex:[{flex:["1","auto","initial","none",isArbitraryValue]}],grow:[{grow:getZeroAndEmpty()}],shrink:[{shrink:getZeroAndEmpty()}],order:[{order:["first","last","none",isInteger,isArbitraryValue]}],"grid-cols":[{"grid-cols":[isAny]}],"col-start-end":[{col:["auto",{span:["full",isInteger,isArbitraryValue]},isArbitraryValue]}],"col-start":[{"col-start":getNumberWithAutoAndArbitrary()}],"col-end":[{"col-end":getNumberWithAutoAndArbitrary()}],"grid-rows":[{"grid-rows":[isAny]}],"row-start-end":[{row:["auto",{span:[isInteger,isArbitraryValue]},isArbitraryValue]}],"row-start":[{"row-start":getNumberWithAutoAndArbitrary()}],"row-end":[{"row-end":getNumberWithAutoAndArbitrary()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":["auto","min","max","fr",isArbitraryValue]}],"auto-rows":[{"auto-rows":["auto","min","max","fr",isArbitraryValue]}],gap:[{gap:[gap]}],"gap-x":[{"gap-x":[gap]}],"gap-y":[{"gap-y":[gap]}],"justify-content":[{justify:["normal",...getAlign()]}],"justify-items":[{"justify-items":["start","end","center","stretch"]}],"justify-self":[{"justify-self":["auto","start","end","center","stretch"]}],"align-content":[{content:["normal",...getAlign(),"baseline"]}],"align-items":[{items:["start","end","center","baseline","stretch"]}],"align-self":[{self:["auto","start","end","center","stretch","baseline"]}],"place-content":[{"place-content":[...getAlign(),"baseline"]}],"place-items":[{"place-items":["start","end","center","baseline","stretch"]}],"place-self":[{"place-self":["auto","start","end","center","stretch"]}],p:[{p:[padding]}],px:[{px:[padding]}],py:[{py:[padding]}],ps:[{ps:[padding]}],pe:[{pe:[padding]}],pt:[{pt:[padding]}],pr:[{pr:[padding]}],pb:[{pb:[padding]}],pl:[{pl:[padding]}],m:[{m:[margin]}],mx:[{mx:[margin]}],my:[{my:[margin]}],ms:[{ms:[margin]}],me:[{me:[margin]}],mt:[{mt:[margin]}],mr:[{mr:[margin]}],mb:[{mb:[margin]}],ml:[{ml:[margin]}],"space-x":[{"space-x":[space]}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":[space]}],"space-y-reverse":["space-y-reverse"],w:[{w:["auto","min","max","fit","svw","lvw","dvw",isArbitraryValue,spacing]}],"min-w":[{"min-w":[isArbitraryValue,spacing,"min","max","fit"]}],"max-w":[{"max-w":[isArbitraryValue,spacing,"none","full","min","max","fit","prose",{screen:[isTshirtSize]},isTshirtSize]}],h:[{h:[isArbitraryValue,spacing,"auto","min","max","fit","svh","lvh","dvh"]}],"min-h":[{"min-h":[isArbitraryValue,spacing,"min","max","fit","svh","lvh","dvh"]}],"max-h":[{"max-h":[isArbitraryValue,spacing,"min","max","fit","svh","lvh","dvh"]}],size:[{size:[isArbitraryValue,spacing,"auto","min","max","fit"]}],"font-size":[{text:["base",isTshirtSize,isArbitraryLength]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:["thin","extralight","light","normal","medium","semibold","bold","extrabold","black",isArbitraryNumber]}],"font-family":[{font:[isAny]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:["tighter","tight","normal","wide","wider","widest",isArbitraryValue]}],"line-clamp":[{"line-clamp":["none",isNumber,isArbitraryNumber]}],leading:[{leading:["none","tight","snug","normal","relaxed","loose",isLength,isArbitraryValue]}],"list-image":[{"list-image":["none",isArbitraryValue]}],"list-style-type":[{list:["none","disc","decimal",isArbitraryValue]}],"list-style-position":[{list:["inside","outside"]}],"placeholder-color":[{placeholder:[colors]}],"placeholder-opacity":[{"placeholder-opacity":[opacity]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"text-color":[{text:[colors]}],"text-opacity":[{"text-opacity":[opacity]}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...getLineStyles(),"wavy"]}],"text-decoration-thickness":[{decoration:["auto","from-font",isLength,isArbitraryLength]}],"underline-offset":[{"underline-offset":["auto",isLength,isArbitraryValue]}],"text-decoration-color":[{decoration:[colors]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:getSpacingWithArbitrary()}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",isArbitraryValue]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",isArbitraryValue]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-opacity":[{"bg-opacity":[opacity]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:[...getPositions(),isArbitraryPosition]}],"bg-repeat":[{bg:["no-repeat",{repeat:["","x","y","round","space"]}]}],"bg-size":[{bg:["auto","cover","contain",isArbitrarySize]}],"bg-image":[{bg:["none",{"gradient-to":["t","tr","r","br","b","bl","l","tl"]},isArbitraryImage]}],"bg-color":[{bg:[colors]}],"gradient-from-pos":[{from:[gradientColorStopPositions]}],"gradient-via-pos":[{via:[gradientColorStopPositions]}],"gradient-to-pos":[{to:[gradientColorStopPositions]}],"gradient-from":[{from:[gradientColorStops]}],"gradient-via":[{via:[gradientColorStops]}],"gradient-to":[{to:[gradientColorStops]}],rounded:[{rounded:[borderRadius]}],"rounded-s":[{"rounded-s":[borderRadius]}],"rounded-e":[{"rounded-e":[borderRadius]}],"rounded-t":[{"rounded-t":[borderRadius]}],"rounded-r":[{"rounded-r":[borderRadius]}],"rounded-b":[{"rounded-b":[borderRadius]}],"rounded-l":[{"rounded-l":[borderRadius]}],"rounded-ss":[{"rounded-ss":[borderRadius]}],"rounded-se":[{"rounded-se":[borderRadius]}],"rounded-ee":[{"rounded-ee":[borderRadius]}],"rounded-es":[{"rounded-es":[borderRadius]}],"rounded-tl":[{"rounded-tl":[borderRadius]}],"rounded-tr":[{"rounded-tr":[borderRadius]}],"rounded-br":[{"rounded-br":[borderRadius]}],"rounded-bl":[{"rounded-bl":[borderRadius]}],"border-w":[{border:[borderWidth]}],"border-w-x":[{"border-x":[borderWidth]}],"border-w-y":[{"border-y":[borderWidth]}],"border-w-s":[{"border-s":[borderWidth]}],"border-w-e":[{"border-e":[borderWidth]}],"border-w-t":[{"border-t":[borderWidth]}],"border-w-r":[{"border-r":[borderWidth]}],"border-w-b":[{"border-b":[borderWidth]}],"border-w-l":[{"border-l":[borderWidth]}],"border-opacity":[{"border-opacity":[opacity]}],"border-style":[{border:[...getLineStyles(),"hidden"]}],"divide-x":[{"divide-x":[borderWidth]}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":[borderWidth]}],"divide-y-reverse":["divide-y-reverse"],"divide-opacity":[{"divide-opacity":[opacity]}],"divide-style":[{divide:getLineStyles()}],"border-color":[{border:[borderColor]}],"border-color-x":[{"border-x":[borderColor]}],"border-color-y":[{"border-y":[borderColor]}],"border-color-s":[{"border-s":[borderColor]}],"border-color-e":[{"border-e":[borderColor]}],"border-color-t":[{"border-t":[borderColor]}],"border-color-r":[{"border-r":[borderColor]}],"border-color-b":[{"border-b":[borderColor]}],"border-color-l":[{"border-l":[borderColor]}],"divide-color":[{divide:[borderColor]}],"outline-style":[{outline:["",...getLineStyles()]}],"outline-offset":[{"outline-offset":[isLength,isArbitraryValue]}],"outline-w":[{outline:[isLength,isArbitraryLength]}],"outline-color":[{outline:[colors]}],"ring-w":[{ring:getLengthWithEmptyAndArbitrary()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:[colors]}],"ring-opacity":[{"ring-opacity":[opacity]}],"ring-offset-w":[{"ring-offset":[isLength,isArbitraryLength]}],"ring-offset-color":[{"ring-offset":[colors]}],shadow:[{shadow:["","inner","none",isTshirtSize,isArbitraryShadow]}],"shadow-color":[{shadow:[isAny]}],opacity:[{opacity:[opacity]}],"mix-blend":[{"mix-blend":[...getBlendModes(),"plus-lighter","plus-darker"]}],"bg-blend":[{"bg-blend":getBlendModes()}],filter:[{filter:["","none"]}],blur:[{blur:[blur]}],brightness:[{brightness:[brightness]}],contrast:[{contrast:[contrast]}],"drop-shadow":[{"drop-shadow":["","none",isTshirtSize,isArbitraryValue]}],grayscale:[{grayscale:[grayscale]}],"hue-rotate":[{"hue-rotate":[hueRotate]}],invert:[{invert:[invert]}],saturate:[{saturate:[saturate]}],sepia:[{sepia:[sepia]}],"backdrop-filter":[{"backdrop-filter":["","none"]}],"backdrop-blur":[{"backdrop-blur":[blur]}],"backdrop-brightness":[{"backdrop-brightness":[brightness]}],"backdrop-contrast":[{"backdrop-contrast":[contrast]}],"backdrop-grayscale":[{"backdrop-grayscale":[grayscale]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[hueRotate]}],"backdrop-invert":[{"backdrop-invert":[invert]}],"backdrop-opacity":[{"backdrop-opacity":[opacity]}],"backdrop-saturate":[{"backdrop-saturate":[saturate]}],"backdrop-sepia":[{"backdrop-sepia":[sepia]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":[borderSpacing]}],"border-spacing-x":[{"border-spacing-x":[borderSpacing]}],"border-spacing-y":[{"border-spacing-y":[borderSpacing]}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["none","all","","colors","opacity","shadow","transform",isArbitraryValue]}],duration:[{duration:getNumberAndArbitrary()}],ease:[{ease:["linear","in","out","in-out",isArbitraryValue]}],delay:[{delay:getNumberAndArbitrary()}],animate:[{animate:["none","spin","ping","pulse","bounce",isArbitraryValue]}],transform:[{transform:["","gpu","none"]}],scale:[{scale:[scale]}],"scale-x":[{"scale-x":[scale]}],"scale-y":[{"scale-y":[scale]}],rotate:[{rotate:[isInteger,isArbitraryValue]}],"translate-x":[{"translate-x":[translate]}],"translate-y":[{"translate-y":[translate]}],"skew-x":[{"skew-x":[skew]}],"skew-y":[{"skew-y":[skew]}],"transform-origin":[{origin:["center","top","top-right","right","bottom-right","bottom","bottom-left","left","top-left",isArbitraryValue]}],accent:[{accent:["auto",colors]}],appearance:[{appearance:["none","auto"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",isArbitraryValue]}],"caret-color":[{caret:[colors]}],"pointer-events":[{"pointer-events":["none","auto"]}],resize:[{resize:["none","y","x",""]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scroll-m":[{"scroll-m":getSpacingWithArbitrary()}],"scroll-mx":[{"scroll-mx":getSpacingWithArbitrary()}],"scroll-my":[{"scroll-my":getSpacingWithArbitrary()}],"scroll-ms":[{"scroll-ms":getSpacingWithArbitrary()}],"scroll-me":[{"scroll-me":getSpacingWithArbitrary()}],"scroll-mt":[{"scroll-mt":getSpacingWithArbitrary()}],"scroll-mr":[{"scroll-mr":getSpacingWithArbitrary()}],"scroll-mb":[{"scroll-mb":getSpacingWithArbitrary()}],"scroll-ml":[{"scroll-ml":getSpacingWithArbitrary()}],"scroll-p":[{"scroll-p":getSpacingWithArbitrary()}],"scroll-px":[{"scroll-px":getSpacingWithArbitrary()}],"scroll-py":[{"scroll-py":getSpacingWithArbitrary()}],"scroll-ps":[{"scroll-ps":getSpacingWithArbitrary()}],"scroll-pe":[{"scroll-pe":getSpacingWithArbitrary()}],"scroll-pt":[{"scroll-pt":getSpacingWithArbitrary()}],"scroll-pr":[{"scroll-pr":getSpacingWithArbitrary()}],"scroll-pb":[{"scroll-pb":getSpacingWithArbitrary()}],"scroll-pl":[{"scroll-pl":getSpacingWithArbitrary()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",isArbitraryValue]}],fill:[{fill:[colors,"none"]}],"stroke-w":[{stroke:[isLength,isArbitraryLength,isArbitraryNumber]}],stroke:[{stroke:[colors,"none"]}],sr:["sr-only","not-sr-only"],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-s","border-w-e","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-s","border-color-e","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]}}},"getDefaultConfig"),twMerge=createTailwindMerge(getDefaultConfig),cn=__name((...inputs)=>twMerge(clsx(inputs)),"cn"),isFirefox=typeof navigator<"u"&&navigator.userAgent.includes("Firefox"),throttle=__name((callback,delay)=>{let lastCall=0;return(...args)=>{const now=Date.now();if(now-lastCall>=delay)return lastCall=now,callback(...args)}},"throttle"),debounce=__name((fn2,wait,options={})=>{let timeoutId,lastArgs,isLeadingInvoked=!1;const debounced=__name((...args)=>{if(lastArgs=args,options.leading&&!isLeadingInvoked){isLeadingInvoked=!0,fn2(...args);return}timeoutId!==void 0&&clearTimeout(timeoutId),options.trailing!==!1&&(timeoutId=window.setTimeout(()=>{isLeadingInvoked=!1,timeoutId=void 0,fn2(...lastArgs)},wait))},"debounced");return debounced.cancel=()=>{timeoutId!==void 0&&(clearTimeout(timeoutId),timeoutId=void 0,isLeadingInvoked=!1,lastArgs=void 0)},debounced},"debounce"),readLocalStorage=__name(storageKey=>{if(typeof window>"u")return null;try{const stored=localStorage.getItem(storageKey);return stored?JSON.parse(stored):null}catch{return null}},"readLocalStorage"),saveLocalStorage=__name((storageKey,state)=>{if(!(typeof window>"u"))try{window.localStorage.setItem(storageKey,JSON.stringify(state))}catch{}},"saveLocalStorage"),toggleMultipleClasses=__name((element,classes)=>{for(const cls of classes)element.classList.toggle(cls)},"toggleMultipleClasses"),LRUNode=(_a=class{constructor(key,value){this.key=key,this.value=value}},__name(_a,"LRUNode"),_a),LRUMap=(_b=class{constructor(limit){this.limit=limit,this.nodes=new Map}has(key){return this.nodes.has(key)}get(key){const result=this.nodes.get(key);if(result)return this.bubble(result),result.value}set(key,value){if(this.nodes.has(key)){const result=this.nodes.get(key);result&&this.bubble(result);return}const node=new LRUNode(key,value);this.insertHead(node),this.nodes.size===this.limit&&this.tail&&this.delete(this.tail.key),this.nodes.set(key,node)}delete(key){const result=this.nodes.get(key);result&&(this.removeNode(result),this.nodes.delete(key))}insertHead(node){this.head?(node.next=this.head,this.head.prev=node):(this.tail=node,node.next=void 0),node.prev=void 0,this.head=node}removeNode(node){node.prev&&(node.prev.next=node.next),node.next&&(node.next.prev=node.prev),node===this.tail&&(this.tail=node.prev,this.tail&&(this.tail.next=void 0))}insertBefore(node,newNode){newNode.next=node,node.prev?(newNode.prev=node.prev,node.prev.next=newNode):(newNode.prev=void 0,this.head=newNode),node.prev=newNode}bubble(node){node.prev&&(this.removeNode(node),this.insertBefore(node.prev,node))}},__name(_b,"LRUMap"),_b),aggregateChanges=__name((changes,prevAggregatedChange)=>{const newChange={type:(prevAggregatedChange==null?void 0:prevAggregatedChange.type)??new Set,unstable:(prevAggregatedChange==null?void 0:prevAggregatedChange.unstable)??!1};for(const change of changes)newChange.type.add(change.type),newChange.unstable=newChange.unstable||change.unstable;return newChange},"aggregateChanges"),joinAggregations=__name(({from,to})=>{to.changes.type=to.changes.type.union(from.changes.type),to.changes.unstable=to.changes.unstable||from.changes.unstable,to.aggregatedCount+=1,to.didCommit=to.didCommit||from.didCommit,to.forget=to.forget||from.forget,to.fps=to.fps+from.fps,to.phase=to.phase.union(from.phase),to.time=(to.time??0)+(from.time??0),to.unnecessary=to.unnecessary||from.unnecessary},"joinAggregations"),aggregateRender=__name((newRender,prevAggregated)=>{prevAggregated.changes=aggregateChanges(newRender.changes,prevAggregated.changes),prevAggregated.aggregatedCount+=1,prevAggregated.didCommit=prevAggregated.didCommit||newRender.didCommit,prevAggregated.forget=prevAggregated.forget||newRender.forget,prevAggregated.fps=prevAggregated.fps+newRender.fps,prevAggregated.phase.add(newRender.phase),prevAggregated.time=(prevAggregated.time??0)+(newRender.time??0),prevAggregated.unnecessary=prevAggregated.unnecessary||newRender.unnecessary},"aggregateRender"),getLabelText=__name(groupedAggregatedRenders=>{let labelText="";const componentsByCount=new Map;for(const aggregatedRender of groupedAggregatedRenders){const{forget,time,aggregatedCount,name}=aggregatedRender;componentsByCount.has(aggregatedCount)||componentsByCount.set(aggregatedCount,[]),componentsByCount.get(aggregatedCount).push({name,forget,time:time??0})}const sortedCounts=Array.from(componentsByCount.keys()).sort((a2,b2)=>b2-a2),parts=[];let cumulativeTime=0;for(const count of sortedCounts){const componentGroup=componentsByCount.get(count);let text=componentGroup.slice(0,4).map(({name})=>name).join(", ");const totalTime=componentGroup.reduce((sum,{time})=>sum+time,0),hasForget=componentGroup.some(({forget})=>forget);cumulativeTime+=totalTime,componentGroup.length>4&&(text+="..."),count>1&&(text+=` ×${count}`),hasForget&&(text=`✨${text}`),parts.push(text)}return labelText=parts.join(", "),labelText.length?(labelText.length>40&&(labelText=`${labelText.slice(0,40)}…`),cumulativeTime>=.01&&(labelText+=` (${Number(cumulativeTime.toFixed(2))}ms)`),labelText):null},"getLabelText"),updateFiberRenderData=__name((fiber,renders)=>{var _a2,_b2;(_b2=(_a2=ReactScanInternals.options.value).onRender)==null||_b2.call(_a2,fiber,renders);const type=getType(fiber.type)||fiber.type;if(type&&typeof type=="function"&&typeof type=="object"){const renderData=type.renderData||{count:0,time:0,renders:[]},firstRender=renders[0];renderData.count+=firstRender.count,renderData.time+=firstRender.time??0,renderData.renders.push(firstRender),type.renderData=renderData}},"updateFiberRenderData");function isEqual(a2,b2){return a2===b2||a2!==a2&&b2!==b2}__name(isEqual,"isEqual");var DEFAULT_THROTTLE_TIME=32,START_COLOR={r:115,g:97,b:230},END_COLOR={r:185,g:49,b:115},MONO_FONT="Menlo,Consolas,Monaco,Liberation Mono,Lucida Console,monospace";function incrementFrameId(){requestAnimationFrame(incrementFrameId)}__name(incrementFrameId,"incrementFrameId"),typeof window<"u"&&incrementFrameId();var recalcOutlines=throttle(async()=>{const{activeOutlines}=ReactScanInternals,domNodes=[];for(const activeOutline of activeOutlines.values())domNodes.push(activeOutline.domNode);const rectMap=await batchGetBoundingRects(domNodes);for(const activeOutline of activeOutlines.values()){const rect=rectMap.get(activeOutline.domNode);rect&&(activeOutline.target=rect)}},DEFAULT_THROTTLE_TIME),batchGetBoundingRects=__name(elements=>new Promise(resolve=>{const results=new Map,observer=new IntersectionObserver(entries=>{for(const entry of entries){const element=entry.target,bounds=entry.boundingClientRect;results.set(element,bounds)}observer.disconnect(),resolve(results)});for(const element of elements)observer.observe(element)}),"batchGetBoundingRects"),flushOutlines=__name(async ctx=>{var _a2,_b2;if(!ReactScanInternals.scheduledOutlines.size&&!ReactScanInternals.activeOutlines.size)return;const flattenedScheduledOutlines=Array.from(ReactScanInternals.scheduledOutlines.values());await activateOutlines(),recalcOutlines(),ReactScanInternals.scheduledOutlines=new Map;const{options}=ReactScanInternals;(_b2=(_a2=options.value).onPaintStart)==null||_b2.call(_a2,flattenedScheduledOutlines),animationFrameId||(animationFrameId=requestAnimationFrame(()=>fadeOutOutline(ctx)))},"flushOutlines"),animationFrameId=null,shouldSkipInterpolation=__name(rect=>rect.top>=window.innerHeight||rect.bottom<=0||rect.left>=window.innerWidth||rect.right<=0?!0:!ReactScanInternals.options.value.smoothlyAnimateOutlines,"shouldSkipInterpolation"),fadeOutOutline=__name(ctx=>{const dpi=window.devicePixelRatio||1;ctx.clearRect(0,0,ctx.canvas.width/dpi,ctx.canvas.height/dpi);const pendingLabeledOutlines=[];ctx.save();const phases=new Set,activeOutlines=ReactScanInternals.activeOutlines;for(const[key,activeOutline]of activeOutlines){const invariant_activeOutline=activeOutline;let frame;for(const aggregatedRender of invariant_activeOutline.groupedAggregatedRender.values())aggregatedRender.frame+=1,frame=frame?Math.max(aggregatedRender.frame,frame):aggregatedRender.frame;if(!frame){activeOutlines.delete(key);continue}const THRESHOLD_FPS=60,avgFps=invariant_activeOutline.aggregatedRender.fps/invariant_activeOutline.aggregatedRender.aggregatedCount,averageScore=Math.max((THRESHOLD_FPS-Math.min(avgFps,THRESHOLD_FPS))/THRESHOLD_FPS,invariant_activeOutline.aggregatedRender.time??0/invariant_activeOutline.aggregatedRender.aggregatedCount/16),t2=Math.min(averageScore,1),r2=Math.round(START_COLOR.r+t2*(END_COLOR.r-START_COLOR.r)),g2=Math.round(START_COLOR.g+t2*(END_COLOR.g-START_COLOR.g)),b2=Math.round(START_COLOR.b+t2*(END_COLOR.b-START_COLOR.b)),color={r:r2,g:g2,b:b2};let reasons=0;phases.clear();let didCommit=!1,unstable=!1,isUnnecessary=!1;for(const render2 of invariant_activeOutline.groupedAggregatedRender.values())render2.unnecessary&&(isUnnecessary=!0),render2.changes.unstable&&(unstable=!0),render2.didCommit&&(didCommit=!0);didCommit&&(reasons|=1),unstable&&(reasons|=2),isUnnecessary&&(reasons|=4,color.r=128,color.g=128,color.b=128);const alphaScalar=.8;invariant_activeOutline.alpha=alphaScalar*(1-frame/invariant_activeOutline.totalFrames);const alpha=invariant_activeOutline.alpha,fillAlpha=alpha*.1,target=invariant_activeOutline.target;if(shouldSkipInterpolation(target))invariant_activeOutline.current=target,invariant_activeOutline.groupedAggregatedRender.forEach(v2=>{v2.computedCurrent=target});else{invariant_activeOutline.current||(invariant_activeOutline.current=new DOMRect(target.x,target.y,target.width,target.height));const INTERPOLATION_SPEED=.2,current=invariant_activeOutline.current,lerp=__name((start2,end)=>start2+(end-start2)*INTERPOLATION_SPEED,"lerp"),computedCurrent=new DOMRect(lerp(current.x,target.x),lerp(current.y,target.y),lerp(current.width,target.width),lerp(current.height,target.height));invariant_activeOutline.current=computedCurrent,invariant_activeOutline.groupedAggregatedRender.forEach(v2=>{v2.computedCurrent=computedCurrent})}const rgb=`${color.r},${color.g},${color.b}`;ctx.strokeStyle=`rgba(${rgb},${alpha})`,ctx.lineWidth=1,ctx.fillStyle=`rgba(${rgb},${fillAlpha})`,ctx.beginPath(),ctx.rect(invariant_activeOutline.current.x,invariant_activeOutline.current.y,invariant_activeOutline.current.width,invariant_activeOutline.current.height),ctx.stroke(),ctx.fill();const labelText=getLabelText(Array.from(invariant_activeOutline.groupedAggregatedRender.values()));if(reasons>0&&labelText&&!(phases.has("mount")&&phases.size===1)){const measured=measureTextCached(labelText,ctx);pendingLabeledOutlines.push({alpha,color,reasons,labelText,textWidth:measured.width,activeOutline:invariant_activeOutline})}const totalFrames=invariant_activeOutline.totalFrames;for(const[fiber,aggregatedRender]of invariant_activeOutline.groupedAggregatedRender)aggregatedRender.frame>=totalFrames&&invariant_activeOutline.groupedAggregatedRender.delete(fiber);invariant_activeOutline.groupedAggregatedRender.size===0&&activeOutlines.delete(key)}ctx.restore();const mergedLabels=mergeOverlappingLabels(pendingLabeledOutlines);ctx.save(),ctx.font=`11px ${MONO_FONT}`;for(let i2=0,len=mergedLabels.length;i2<len;i2++){const{alpha,color,reasons,groupedAggregatedRender,rect}=mergedLabels[i2],text=getLabelText(groupedAggregatedRender)??"N/A",conditionalText=reasons&4?`${text}⚠️`:text,textWidth=ctx.measureText(conditionalText).width,textHeight=11,labelX=rect.x,labelY=rect.y-textHeight-4;ctx.fillStyle=`rgba(${color.r},${color.g},${color.b},${alpha})`,ctx.fillRect(labelX,labelY,textWidth+4,textHeight+4),ctx.fillStyle=`rgba(255,255,255,${alpha})`,ctx.fillText(conditionalText,labelX+2,labelY+textHeight)}ctx.restore(),activeOutlines.size?animationFrameId=requestAnimationFrame(()=>fadeOutOutline(ctx)):animationFrameId=null},"fadeOutOutline"),areFibersEqual=__name((fiberA,fiberB)=>!!(fiberA===fiberB||fiberA.alternate===fiberB||fiberA===fiberB.alternate||fiberA.alternate&&fiberB.alternate&&fiberA.alternate===fiberB.alternate),"areFibersEqual"),getIsOffscreen=__name(rect=>{const viewportWidth=window.innerWidth,viewportHeight=window.innerHeight;return rect.bottom<0||rect.right<0||rect.top>viewportHeight||rect.left>viewportWidth},"getIsOffscreen"),activateOutlines=__name(async()=>{var _a2,_b2,_c;const domNodes=[],scheduledOutlines=ReactScanInternals.scheduledOutlines,activeOutlines=ReactScanInternals.activeOutlines,activeFibers=new Map;for(const activeOutline of ReactScanInternals.activeOutlines.values())if(activeOutline.groupedAggregatedRender)for(const[fiber,aggregatedRender]of activeOutline.groupedAggregatedRender){if(fiber.alternate&&activeFibers.has(fiber.alternate)){const alternateAggregatedRender=activeFibers.get(fiber.alternate);alternateAggregatedRender&&joinAggregations({from:alternateAggregatedRender,to:aggregatedRender}),(_a2=activeOutline.groupedAggregatedRender)==null||_a2.delete(fiber),activeFibers.delete(fiber.alternate)}activeFibers.set(fiber,aggregatedRender)}for(const[fiber,outline]of scheduledOutlines){const existingAggregatedRender=activeFibers.get(fiber)||fiber.alternate&&activeFibers.get(fiber.alternate);existingAggregatedRender&&(joinAggregations({to:existingAggregatedRender,from:outline.aggregatedRender}),existingAggregatedRender.frame=0),domNodes.push(outline.domNode)}const rects=await batchGetBoundingRects(domNodes),totalFrames=45,alpha=.8;for(const[fiber,outline]of scheduledOutlines){const rect=rects.get(outline.domNode);if(!rect||rect.top===rect.bottom||rect.left===rect.right)continue;const prevAggregatedRender=activeFibers.get(fiber)||fiber.alternate&&activeFibers.get(fiber.alternate);if(getIsOffscreen(rect))continue;const key=`${rect.x}-${rect.y}`;let existingOutline=activeOutlines.get(key);if(existingOutline)prevAggregatedRender?joinAggregations({to:prevAggregatedRender,from:outline.aggregatedRender}):(existingOutline.alpha=outline.alpha,(_c=existingOutline.groupedAggregatedRender)==null||_c.set(fiber,outline.aggregatedRender));else{if(existingOutline=outline,existingOutline.target=rect,existingOutline.totalFrames=totalFrames,existingOutline.groupedAggregatedRender=new Map([[fiber,outline.aggregatedRender]]),existingOutline.aggregatedRender.aggregatedCount=(prevAggregatedRender==null?void 0:prevAggregatedRender.aggregatedCount)??1,existingOutline.alpha=alpha,existingOutline.aggregatedRender.computedKey=key,prevAggregatedRender!=null&&prevAggregatedRender.computedKey){const groupOnKey=activeOutlines.get(prevAggregatedRender.computedKey);(_b2=groupOnKey==null?void 0:groupOnKey.groupedAggregatedRender)==null||_b2.forEach((value,prevStoredFiber)=>{areFibersEqual(prevStoredFiber,fiber)&&(value.frame=45,existingOutline.current=value.computedCurrent)})}activeOutlines.set(key,existingOutline)}existingOutline.alpha=Math.max(existingOutline.alpha,outline.alpha),existingOutline.totalFrames=Math.max(existingOutline.totalFrames,outline.totalFrames)}},"activateOutlines"),mergeOverlappingLabels=__name(labels=>{if(labels.length>1500)return labels.map(label=>toMergedLabel(label));const transformed=labels.map(label=>({original:label,rect:applyLabelTransform(label.activeOutline.current,label.textWidth)}));transformed.sort((a2,b2)=>a2.rect.x-b2.rect.x);const mergedLabels=[],mergedSet=new Set;for(let i2=0;i2<transformed.length;i2++){if(mergedSet.has(i2))continue;let currentMerged=toMergedLabel(transformed[i2].original,transformed[i2].rect),currentRight=currentMerged.rect.x+currentMerged.rect.width;for(let j2=i2+1;j2<transformed.length;j2++){if(mergedSet.has(j2))continue;if(transformed[j2].rect.x>currentRight)break;const nextRect=transformed[j2].rect;if(getOverlapArea(currentMerged.rect,nextRect)>0){const nextLabel=toMergedLabel(transformed[j2].original,nextRect);currentMerged=mergeTwoLabels(currentMerged,nextLabel),mergedSet.add(j2),currentRight=currentMerged.rect.x+currentMerged.rect.width}}mergedLabels.push(currentMerged)}return mergedLabels},"mergeOverlappingLabels");function toMergedLabel(label,rectOverride){const rect=rectOverride??applyLabelTransform(label.activeOutline.current,label.textWidth),groupedArray=Array.from(label.activeOutline.groupedAggregatedRender.values());return{alpha:label.alpha,color:label.color,reasons:label.reasons,groupedAggregatedRender:groupedArray,rect}}__name(toMergedLabel,"toMergedLabel");function mergeTwoLabels(a2,b2){const mergedRect=getBoundingRect(a2.rect,b2.rect),mergedGrouped=a2.groupedAggregatedRender.concat(b2.groupedAggregatedRender),mergedReasons=a2.reasons|b2.reasons;return{alpha:Math.max(a2.alpha,b2.alpha),...pickColorClosestToStartStage(a2,b2),reasons:mergedReasons,groupedAggregatedRender:mergedGrouped,rect:mergedRect}}__name(mergeTwoLabels,"mergeTwoLabels");function getBoundingRect(r1,r2){const x1=Math.min(r1.x,r2.x),y1=Math.min(r1.y,r2.y),x2=Math.max(r1.x+r1.width,r2.x+r2.width),y2=Math.max(r1.y+r1.height,r2.y+r2.height);return new DOMRect(x1,y1,x2-x1,y2-y1)}__name(getBoundingRect,"getBoundingRect");function pickColorClosestToStartStage(a2,b2){return a2.color.r===a2.color.g&&a2.color.g===a2.color.b?{color:a2.color}:b2.color.r===b2.color.g&&b2.color.g===b2.color.b?{color:b2.color}:{color:a2.color.r<=b2.color.r?a2.color:b2.color}}__name(pickColorClosestToStartStage,"pickColorClosestToStartStage");function getOverlapArea(rect1,rect2){if(rect1.right<=rect2.left||rect2.right<=rect1.left||rect1.bottom<=rect2.top||rect2.bottom<=rect1.top)return 0;const xOverlap=Math.min(rect1.right,rect2.right)-Math.max(rect1.left,rect2.left),yOverlap=Math.min(rect1.bottom,rect2.bottom)-Math.max(rect1.top,rect2.top);return xOverlap*yOverlap}__name(getOverlapArea,"getOverlapArea");function applyLabelTransform(rect,estimatedTextWidth){const labelX=rect.x,labelY=rect.y;return new DOMRect(labelX,labelY,estimatedTextWidth+4,15)}__name(applyLabelTransform,"applyLabelTransform");var textMeasurementCache=new LRUMap(100),measureTextCached=__name((text,ctx)=>{if(textMeasurementCache.has(text))return textMeasurementCache.get(text);ctx.font=`11px ${MONO_FONT}`;const metrics=ctx.measureText(text);return textMeasurementCache.set(text,metrics),metrics},"measureTextCached"),log=__name(renders=>{const logMap=new Map;for(let i2=0,len=renders.length;i2<len;i2++){const render2=renders[i2];if(!render2.componentName)continue;const changeLog=logMap.get(render2.componentName)??[],labelText=getLabelText([{aggregatedCount:1,computedKey:null,name:render2.componentName,frame:null,...render2,changes:{type:new Set(render2.changes.map(change=>change.type)),unstable:render2.changes.some(change=>change.unstable)},phase:new Set([render2.phase])}]);if(!labelText)continue;let prevChangedProps=null,nextChangedProps=null;if(render2.changes)for(let i22=0,len2=render2.changes.length;i22<len2;i22++){const{name,prevValue,nextValue,unstable,type}=render2.changes[i22];type==="props"?(prevChangedProps??(prevChangedProps={}),nextChangedProps??(nextChangedProps={}),prevChangedProps[`${unstable?"⚠️":""}${name} (prev)`]=prevValue,nextChangedProps[`${unstable?"⚠️":""}${name} (next)`]=nextValue):changeLog.push({prev:prevValue,next:nextValue,type,unstable})}prevChangedProps&&nextChangedProps&&changeLog.push({prev:prevChangedProps,next:nextChangedProps,type:"props",unstable:!1}),logMap.set(labelText,changeLog)}for(const[name,changeLog]of Array.from(logMap.entries())){console.group(`%c${name}`,"background: hsla(0,0%,70%,.3); border-radius:3px; padding: 0 2px;");for(const{type,prev,next,unstable}of changeLog)console.log(`${type}:`,unstable?"⚠️":"",prev,"!==",next);console.groupEnd()}},"log"),logIntro=__name(()=>{console.log("%c[·] %cReact Scan","font-weight:bold;color:#7a68e8;font-size:20px;","font-weight:bold;font-size:14px;"),console.log("Try React Scan Monitoring to target performance issues in production: https://react-scan.com/monitoring")},"logIntro"),getFiberFromElement=__name(element=>{var _a2,_b2,_c;if("__REACT_DEVTOOLS_GLOBAL_HOOK__"in window){const{renderers}=window.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!renderers)return null;for(const[_2,renderer]of Array.from(renderers))try{const fiber=renderer.findFiberByHostInstance(element);if(fiber)return fiber}catch{}}if("_reactRootContainer"in element)return(_c=(_b2=(_a2=element._reactRootContainer)==null?void 0:_a2._internalRoot)==null?void 0:_b2.current)==null?void 0:_c.child;for(const key in element)if(key.startsWith("__reactInternalInstance$")||key.startsWith("__reactFiber"))return element[key];return null},"getFiberFromElement"),getFirstStateNode=__name(fiber=>{let current=fiber;for(;current;){if(current.stateNode instanceof Element)return current.stateNode;if(!current.child)break;current=current.child}for(;current;){if(current.stateNode instanceof Element)return current.stateNode;if(!current.return)break;current=current.return}return null},"getFirstStateNode"),getNearestFiberFromElement=__name(element=>{if(!element)return null;const originalFiber=getFiberFromElement(element);if(!originalFiber)return null;const res=getParentCompositeFiber(originalFiber);return res?res[0]:null},"getNearestFiberFromElement"),getParentCompositeFiber=__name(fiber=>{let curr=fiber,prevNonHost=null;for(;curr;){if(isCompositeFiber(curr))return[curr,prevNonHost];isHostFiber(curr)&&(prevNonHost=curr),curr=curr.return}},"getParentCompositeFiber"),getChangedProps=__name(fiber=>{var _a2;const changes=new Set,currentProps=fiber.memoizedProps||{},previousProps=((_a2=fiber.alternate)==null?void 0:_a2.memoizedProps)||{};for(const key in currentProps)currentProps[key]!==previousProps[key]&&key!=="children"&&changes.add(key);return changes},"getChangedProps"),getStateFromFiber=__name(fiber=>{if(!fiber)return{};if(fiber.tag===FunctionComponentTag||fiber.tag===ForwardRefTag||fiber.tag===SimpleMemoComponentTag||fiber.tag===MemoComponentTag){let memoizedState=fiber.memoizedState;const state={};let index=0;for(;memoizedState;)memoizedState.queue&&memoizedState.memoizedState!==void 0&&(state[index]=memoizedState.memoizedState),memoizedState=memoizedState.next,index++;return state}else if(fiber.tag===ClassComponentTag)return fiber.memoizedState||{};return{}},"getStateFromFiber"),getChangedState=__name(fiber=>{const changes=new Set,currentState=getStateFromFiber(fiber),previousState=fiber.alternate?getStateFromFiber(fiber.alternate):{};for(const key in currentState)currentState[key]!==previousState[key]&&changes.add(key);return changes},"getChangedState"),isFiberInTree=__name((fiber,root)=>!!traverseFiber(root,searchFiber=>searchFiber===fiber),"isFiberInTree"),isCurrentTree=__name(fiber=>{var _a2;let curr=fiber,rootFiber=null;for(;curr;){if(curr.stateNode&&((_a2=ReactScanInternals.instrumentation)!=null&&_a2.fiberRoots.has(curr.stateNode))){rootFiber=curr;break}curr=curr.return}if(!rootFiber)return!1;const currentRootFiber=rootFiber.stateNode.current;return isFiberInTree(fiber,currentRootFiber)},"isCurrentTree"),getCompositeComponentFromElement=__name(element=>{const associatedFiber=getNearestFiberFromElement(element);if(!associatedFiber)return{};const currentAssociatedFiber=isCurrentTree(associatedFiber)?associatedFiber:associatedFiber.alternate??associatedFiber,stateNode=getFirstStateNode(currentAssociatedFiber);if(!stateNode)return{};const targetRect=stateNode.getBoundingClientRect();if(!targetRect)return{};const anotherRes=getParentCompositeFiber(currentAssociatedFiber);if(!anotherRes)return{};let[parentCompositeFiber]=anotherRes;return parentCompositeFiber=(isCurrentTree(parentCompositeFiber)?parentCompositeFiber:parentCompositeFiber.alternate)??parentCompositeFiber,{parentCompositeFiber,targetRect}},"getCompositeComponentFromElement"),getAllFiberContexts=__name(fiber=>{var _a2,_b2;const contexts=new Map;if(!fiber)return contexts;let currentFiber=fiber;for(;currentFiber;){const dependencies=currentFiber.dependencies;if(dependencies!=null&&dependencies.firstContext){let contextItem=dependencies.firstContext;for(;contextItem;){const contextType=contextItem.context,contextValue=contextType._currentValue;contexts.has(contextType)||contexts.set(contextType,contextValue),contextItem=contextItem.next}}if((_a2=currentFiber.type)!=null&&_a2._context){const providerContext=currentFiber.type._context,providerValue=(_b2=currentFiber.memoizedProps)==null?void 0:_b2.value;contexts.has(providerContext)||contexts.set(providerContext,providerValue)}currentFiber=currentFiber.return}return contexts},"getAllFiberContexts"),getOverrideMethods=__name(()=>{let overrideProps=null,overrideHookState=null;if("__REACT_DEVTOOLS_GLOBAL_HOOK__"in window){const{renderers}=window.__REACT_DEVTOOLS_GLOBAL_HOOK__;if(renderers)for(const[_2,renderer]of Array.from(renderers))try{if(overrideProps){const prevOverrideProps=overrideProps;overrideProps=__name((fiber,key,value)=>{prevOverrideProps(fiber,key,value),renderer.overrideProps(fiber,key,value)},"overrideProps")}else overrideProps=renderer.overrideProps;if(overrideHookState){const prevOverrideHookState=overrideHookState;overrideHookState=__name((fiber,key,value)=>{prevOverrideHookState(fiber,key,value),renderer.overrideHookState(fiber,key,value)},"overrideHookState")}else overrideHookState=renderer.overrideHookState}catch{}}return{overrideProps,overrideHookState}},"getOverrideMethods"),currentRect=null,currentLockIconRect=null,OVERLAY_DPR=typeof window<"u"&&window.devicePixelRatio||1,animationFrameId2=null,linearInterpolation=__name((start2,end,t2)=>start2*(1-t2)+end*t2,"linearInterpolation"),drawHoverOverlay=__name((overlayElement,canvas,ctx,kind)=>{if(!overlayElement||!canvas||!ctx)return;const{parentCompositeFiber,targetRect}=getCompositeComponentFromElement(overlayElement);if(!parentCompositeFiber||!targetRect)return;const reportDataFiber=Store.reportData.get(parentCompositeFiber)??(parentCompositeFiber.alternate?Store.reportData.get(parentCompositeFiber.alternate):null),stats={count:(reportDataFiber==null?void 0:reportDataFiber.count)??0,time:(reportDataFiber==null?void 0:reportDataFiber.time)??0};if(ctx.save(),!currentRect)drawRect(targetRect,canvas,ctx,kind,stats,parentCompositeFiber),currentRect=targetRect;else{animationFrameId2!==null&&cancelAnimationFrame(animationFrameId2);const animate=__name(()=>{const t2=ReactScanInternals.options.value.animationSpeed==="fast"?.51:ReactScanInternals.options.value.animationSpeed==="slow"?.1:0;currentRect={left:linearInterpolation(currentRect.left,targetRect.left,t2),top:linearInterpolation(currentRect.top,targetRect.top,t2),width:linearInterpolation(currentRect.width,targetRect.width,t2),height:linearInterpolation(currentRect.height,targetRect.height,t2)},drawRect(currentRect,canvas,ctx,kind,stats,parentCompositeFiber),Math.abs(currentRect.left-targetRect.left)>.1||Math.abs(currentRect.top-targetRect.top)>.1||Math.abs(currentRect.width-targetRect.width)>.1||Math.abs(currentRect.height-targetRect.height)>.1?animationFrameId2=requestAnimationFrame(animate):(currentRect=targetRect,animationFrameId2=null)},"animate");animationFrameId2=requestAnimationFrame(animate)}ctx.restore()},"drawHoverOverlay"),updateCanvasSize=__name((canvas,ctx)=>{canvas&&(canvas.width=Math.floor(window.innerWidth*OVERLAY_DPR),canvas.height=Math.floor(window.innerHeight*OVERLAY_DPR),ctx&&(ctx.setTransform(1,0,0,1,0,0),ctx.scale(OVERLAY_DPR,OVERLAY_DPR)))},"updateCanvasSize"),drawLockIcon=__name((ctx,x2,y2,size)=>{ctx.save(),ctx.strokeStyle="white",ctx.fillStyle="white",ctx.lineWidth=1.5;const shackleWidth=size*.6,shackleHeight=size*.5,shackleX=x2+(size-shackleWidth)/2,shackleY=y2;ctx.beginPath(),ctx.arc(shackleX+shackleWidth/2,shackleY+shackleHeight/2,shackleWidth/2,Math.PI,0,!1),ctx.stroke();const bodyWidth=size*.8,bodyHeight=size*.5,bodyX=x2+(size-bodyWidth)/2,bodyY=y2+shackleHeight/2;ctx.fillRect(bodyX,bodyY,bodyWidth,bodyHeight),ctx.restore()},"drawLockIcon"),drawStatsPill=__name((ctx,rect,stats,kind,fiber)=>{let text=getDisplayName(fiber==null?void 0:fiber.type)??"Unknown";stats.count&&(text+=` • ×${stats.count}`,stats.time&&(text+=` (${stats.time.toFixed(1)}ms)`)),ctx.save(),ctx.font="12px system-ui, -apple-system, sans-serif";const textWidth=ctx.measureText(text).width,lockIconSize=kind==="locked"?14:0,lockIconPadding=kind==="locked"?6:0,pillWidth=textWidth+8*2+lockIconSize+lockIconPadding,pillX=rect.left,pillY=rect.top-24-4;if(ctx.fillStyle="rgb(37, 37, 38, .75)",ctx.beginPath(),ctx.roundRect(pillX,pillY,pillWidth,24,3),ctx.fill(),kind==="locked"){const lockX=pillX+8,lockY=pillY+(24-lockIconSize)/2+2;drawLockIcon(ctx,lockX,lockY,lockIconSize),currentLockIconRect={x:lockX,y:lockY,width:lockIconSize,height:lockIconSize}}else currentLockIconRect=null;ctx.fillStyle="white",ctx.textBaseline="middle";const textX=pillX+8+(kind==="locked"?lockIconSize+lockIconPadding:0);ctx.fillText(text,textX,pillY+24/2),ctx.restore()},"drawStatsPill"),drawRect=__name((rect,canvas,ctx,kind,stats,fiber)=>{ctx.clearRect(0,0,canvas.width,canvas.height),kind==="locked"?(ctx.strokeStyle="rgba(142, 97, 227, 0.5)",ctx.fillStyle="rgba(173, 97, 230, 0.10)",ctx.setLineDash([])):(ctx.strokeStyle="rgba(142, 97, 227, 0.5)",ctx.fillStyle="rgba(173, 97, 230, 0.10)",ctx.setLineDash([4])),ctx.lineWidth=1,ctx.fillRect(rect.left,rect.top,rect.width,rect.height),ctx.strokeRect(rect.left,rect.top,rect.width,rect.height),drawStatsPill(ctx,rect,stats,kind,fiber)},"drawRect");function template(){if(!this.node){const t2=document.createElement("template");t2.innerHTML=this.html,this.node=this.isSVG?t2.content.firstChild.firstChild:t2.content.firstChild}return this.node.cloneNode(!0)}__name(template,"template");function createHTMLTemplate(html,isSVG){return template.bind({node:void 0,html,isSVG})}__name(createHTMLTemplate,"createHTMLTemplate");var fps=0,lastTime=performance.now(),frameCount=0,initedFps=!1,updateFPS=__name(()=>{frameCount++;const now=performance.now();now-lastTime>=1e3&&(fps=frameCount,frameCount=0,lastTime=now),requestAnimationFrame(updateFPS)},"updateFPS"),getFPS=__name(()=>(initedFps||(initedFps=!0,updateFPS(),fps=60),fps),"getFPS"),isValueUnstable=__name((prevValue,nextValue)=>{const prevValueString=fastSerialize(prevValue),nextValueString=fastSerialize(nextValue);return prevValueString===nextValueString&&unstableTypes.includes(typeof prevValue)&&unstableTypes.includes(typeof nextValue)},"isValueUnstable"),unstableTypes=["function","object"],cache=new WeakMap;function fastSerialize(value,depth=0){if(depth<0)return"…";switch(typeof value){case"function":return value.toString();case"string":return value;case"number":case"boolean":case"undefined":return String(value);case"object":break;default:return String(value)}if(value===null)return"null";if(cache.has(value))return cache.get(value);if(Array.isArray(value)){const str2=value.length?`[${value.length}]`:"[]";return cache.set(value,str2),str2}if(isValidElement(value)){const type=getDisplayName(value.type)??"",propCount=value.props?Object.keys(value.props).length:0,str2=`<${type} ${propCount}>`;return cache.set(value,str2),str2}if(Object.getPrototypeOf(value)===Object.prototype){const keys=Object.keys(value),str2=keys.length?`{${keys.length}}`:"{}";return cache.set(value,str2),str2}const ctor=value.constructor;if(ctor&&typeof ctor=="function"&&ctor.name){const str2=`${ctor.name}{…}`;return cache.set(value,str2),str2}const str=`${Object.prototype.toString.call(value).slice(8,-1)}{…}`;return cache.set(value,str),str}__name(fastSerialize,"fastSerialize");var getPropsChanges=__name(fiber=>{var _a2;const changes=[],prevProps=((_a2=fiber.alternate)==null?void 0:_a2.memoizedProps)||{},nextProps=fiber.memoizedProps||{},allKeys=new Set([...Object.keys(prevProps),...Object.keys(nextProps)]);for(const propName in allKeys){const prevValue=prevProps==null?void 0:prevProps[propName],nextValue=nextProps==null?void 0:nextProps[propName];if(isEqual(prevValue,nextValue)||isValidElement(prevValue)||isValidElement(nextValue))continue;const change={type:"props",name:propName,prevValue,nextValue,unstable:!1};changes.push(change),isValueUnstable(prevValue,nextValue)&&(change.unstable=!0)}return changes},"getPropsChanges");function getStateChangesTraversal(prevState,nextState){if(isEqual(prevState.memoizedState,nextState.memoizedState))return;const change={type:"state",name:"",prevValue:prevState.memoizedState,nextValue:nextState.memoizedState,unstable:!1};this.push(change)}__name(getStateChangesTraversal,"getStateChangesTraversal");var getStateChanges=__name(fiber=>{const changes=[];return traverseState(fiber,getStateChangesTraversal.bind(changes)),changes},"getStateChanges");function getContextChangesTraversal(prevContext,nextContext){const prevValue=prevContext.memoizedValue,nextValue=nextContext.memoizedValue,change={type:"context",name:"",prevValue,nextValue,unstable:!1};this.push(change);const prevValueString=fastSerialize(prevValue),nextValueString=fastSerialize(nextValue);unstableTypes.includes(typeof prevValue)&&unstableTypes.includes(typeof nextValue)&&prevValueString===nextValueString&&(change.unstable=!0)}__name(getContextChangesTraversal,"getContextChangesTraversal");var getContextChanges=__name(fiber=>{const changes=[];return traverseContexts(fiber,getContextChangesTraversal.bind(changes)),changes},"getContextChanges"),instrumentationInstances=new Map,inited=!1,getAllInstances=__name(()=>Array.from(instrumentationInstances.values()),"getAllInstances");function isRenderUnnecessaryTraversal(prevValue,nextValue){!isEqual(prevValue,nextValue)&&!isValueUnstable(prevValue,nextValue)&&(this.isRequiredChange=!0)}__name(isRenderUnnecessaryTraversal,"isRenderUnnecessaryTraversal");var isRenderUnnecessary=__name(fiber=>{if(!didFiberCommit(fiber))return!0;const mutatedHostFibers=getMutatedHostFibers(fiber);for(const mutatedHostFiber of mutatedHostFibers){const state={isRequiredChange:!1};if(traverseProps(mutatedHostFiber,isRenderUnnecessaryTraversal.bind(state)),state.isRequiredChange)return!1}return!0},"isRenderUnnecessary"),shouldTrackUnnecessaryRenders=__name(()=>{if(!ReactScanInternals.options.value.trackUnnecessaryRenders)return!1;const isProd=getIsProduction();return isProd&&Store.monitor.value&&ReactScanInternals.options.value.dangerouslyForceRunInProduction&&ReactScanInternals.options.value.trackUnnecessaryRenders?!0:isProd&&Store.monitor.value?!1:ReactScanInternals.options.value.trackUnnecessaryRenders},"shouldTrackUnnecessaryRenders"),createInstrumentation=__name((instanceKey,config2)=>{const instrumentation={isPaused:d$1(!ReactScanInternals.options.value.enabled),fiberRoots:new Set};if(instrumentationInstances.set(instanceKey,{key:instanceKey,config:config2,instrumentation}),!inited){inited=!0;const visitor=createFiberVisitor({onRender(fiber,phase){const type=getType(fiber.type);if(!type)return null;const allInstances=getAllInstances(),validInstancesIndicies=[];for(let i2=0,len=allInstances.length;i2<len;i2++)allInstances[i2].config.isValidFiber(fiber)&&validInstancesIndicies.push(i2);if(!validInstancesIndicies.length)return null;const changes=[];if(config2.trackChanges){const propsChanges=getPropsChanges(fiber),stateChanges=getStateChanges(fiber),contextChanges=getContextChanges(fiber);for(let i2=0,len=propsChanges.length;i2<len;i2++){const change=propsChanges[i2];changes.push(change)}for(let i2=0,len=stateChanges.length;i2<len;i2++){const change=stateChanges[i2];changes.push(change)}for(let i2=0,len=contextChanges.length;i2<len;i2++){const change=contextChanges[i2];changes.push(change)}}const{selfTime}=getTimings(fiber),fps2=getFPS(),render2={phase,componentName:getDisplayName(type),count:1,changes,time:selfTime,forget:hasMemoCache(fiber),unnecessary:shouldTrackUnnecessaryRenders()?isRenderUnnecessary(fiber):null,didCommit:didFiberCommit(fiber),fps:fps2};for(let i2=0,len=validInstancesIndicies.length;i2<len;i2++){const index=validInstancesIndicies[i2];allInstances[index].config.onRender(fiber,[render2])}},onError(error){const allInstances=getAllInstances();for(const instance of allInstances)instance.config.onError(error)}});instrument({name:"react-scan",onActive:config2.onActive,onCommitFiberRoot(rendererID,root){var _a2;if((_a2=ReactScanInternals.instrumentation)!=null&&_a2.isPaused.value&&(Store.inspectState.value.kind==="inspect-off"||Store.inspectState.value.kind==="uninitialized")&&!config2.forceAlwaysTrackRenders)return;const allInstances=getAllInstances();for(const instance of allInstances)instance.config.onCommitStart();visitor(rendererID,root);for(const instance of allInstances)instance.config.onCommitFinish()}})}return instrumentation},"createInstrumentation"),EXPANDED_PATHS=new Set,fadeOutTimers=new WeakMap,cumulativeChanges={props:new Map,state:new Map,context:new Map},createWhatsChangedSection=createHTMLTemplate('<details class=react-scan-what-changed style="background-color:#b8860b;color:#ffff00;padding:5px"><summary class=font-bold>What changed?',!1),createPropsHeader=createHTMLTemplate("<div>Props:",!1),createChangeList=createHTMLTemplate('<ul style="list-style-type:disc;padding-left:20px">',!1),createStateHeader=createHTMLTemplate("<div>State:",!1),createContextHeader=createHTMLTemplate("<div>State:",!1),renderPropsAndState=__name((didRender,fiber)=>{var _a2,_b2;const propContainer=Store.inspectState.value.propContainer;if(!propContainer)return;const fiberContext=tryOrElse(()=>Array.from(getAllFiberContexts(fiber).entries()).map(x2=>x2[1]),[]),componentName=((_a2=fiber.type)==null?void 0:_a2.displayName)||((_b2=fiber.type)==null?void 0:_b2.name)||"Unknown",props=fiber.memoizedProps||{},state=getStateFromFiber(fiber)||{},changedProps=new Set(getChangedProps(fiber)),changedState=new Set(getChangedState(fiber)),changedContext=new Set;for(const key of changedProps)cumulativeChanges.props.set(key,(cumulativeChanges.props.get(key)??0)+1);for(const key of changedState)cumulativeChanges.state.set(key,(cumulativeChanges.state.get(key)??0)+1);for(const key of changedContext)cumulativeChanges.context.set(key,(cumulativeChanges.context.get(key)??0)+1);if(propContainer.innerHTML="",cumulativeChanges.props.size>0)for(const[key,count]of cumulativeChanges.props);if(cumulativeChanges.state.size>0)for(const[key,count]of cumulativeChanges.state);if(cumulativeChanges.context.size>0)for(const[key,count]of cumulativeChanges.context);const whatChangedSection=createWhatsChangedSection();if(whatChangedSection.open=Store.wasDetailsOpen.value,cumulativeChanges.props.size>0){const propsHeader=createPropsHeader(),propsList=createChangeList();for(const[key,count]of cumulativeChanges.props){const li=document.createElement("li");li.textContent=`${key} ×${count}`,propsList.appendChild(li)}whatChangedSection.appendChild(propsHeader),whatChangedSection.appendChild(propsList)}if(cumulativeChanges.state.size>0){const stateHeader=createStateHeader(),stateList=createChangeList();for(const[key,count]of cumulativeChanges.state){const li=document.createElement("li");li.textContent=`${key} ×${count}`,stateList.appendChild(li)}whatChangedSection.appendChild(stateHeader),whatChangedSection.appendChild(stateList)}if(cumulativeChanges.context.size>0){const contextHeader=createContextHeader(),contextList=createChangeList();for(const[key,count]of cumulativeChanges.context){const li=document.createElement("li");li.textContent=`${key} ×${count}`,contextList.appendChild(li)}whatChangedSection.appendChild(contextHeader),whatChangedSection.appendChild(contextList)}whatChangedSection.addEventListener("toggle",()=>{Store.wasDetailsOpen.value=whatChangedSection.open}),propContainer.appendChild(whatChangedSection);const inspector=document.createElement("div");inspector.className="react-scan-inspector";const content=document.createElement("div");content.className="react-scan-content";const sections=[];Object.values(props).length&&tryOrElse(()=>{sections.push({element:renderSection(componentName,didRender,fiber,propContainer,"Props",props,changedProps),hasChanges:changedProps.size>0})},null),fiberContext.length&&tryOrElse(()=>{const changedKeys=new Set,contextObj=Object.fromEntries(fiberContext.map((val,idx)=>[idx.toString(),val]));for(const[key,value]of Object.entries(contextObj)){const path=`${componentName}.context.${key}`,lastValue=lastRendered.get(path),isChanged=lastValue!==void 0&&lastValue!==contextObj[key],isBadRender=isChanged&&["object","function"].includes(typeof lastValue)&&fastSerialize(lastValue)===fastSerialize(contextObj[key]);if(isChanged&&(changedKeys.add(key),changedAt.set(path,Date.now())),isBadRender){delete contextObj[key];const newKey=`⚠️ ${key}`;contextObj[newKey]=value,changedAt.set(`${componentName}.context.${key}`,Date.now())}lastRendered.set(path,value)}sections.push({element:renderSection(componentName,didRender,fiber,propContainer,"Context",contextObj,changedKeys),hasChanges:changedKeys.size>0})},null),Object.values(state).length&&tryOrElse(()=>{const stateObj=Array.isArray(state)?Object.fromEntries(state.map((val,idx)=>[idx.toString(),val])):state;for(const[key,value]of Object.entries(stateObj)){const path=`${componentName}.state.${key}`,lastValue=lastRendered.get(path);lastValue!==void 0&&lastValue!==value&&changedAt.set(path,Date.now()),lastRendered.set(path,value)}sections.push({element:renderSection(componentName,didRender,fiber,propContainer,"State",stateObj,changedState),hasChanges:changedState.size>0})},null);for(const section of sections)content.appendChild(section.element);inspector.appendChild(content),propContainer.appendChild(inspector)},"renderPropsAndState"),renderSection=__name((componentName,didRender,fiber,propsContainer,title,data,changedKeys=new Set)=>{const section=document.createElement("div");section.className="react-scan-section",section.dataset.section=title;for(const key in data){const value=data[key],el=createPropertyElement(componentName,didRender,propsContainer,fiber,key,value,title.toLowerCase(),0,changedKeys,"",new WeakMap);el&&section.appendChild(el)}return section},"renderSection"),getPath=__name((componentName,section,parentPath,key)=>parentPath?`${componentName}.${parentPath}.${key}`:`${componentName}.${section}.${key}`,"getPath"),changedAt=new Map,changedAtInterval,lastRendered=new Map,tryOrElse=__name((cb,val)=>{try{return cb()}catch{return val}},"tryOrElse"),isPromise=__name(value=>value&&(value instanceof Promise||typeof value=="object"&&"then"in value),"isPromise"),createScanPropertyContainer=createHTMLTemplate("<div class=react-scan-property>",!1),createScanArrow=createHTMLTemplate("<span class=react-scan-arrow>",!1),createScanPropertyContent=createHTMLTemplate("<div class=react-scan-property-content>",!1),createScanPreviewLine=createHTMLTemplate("<div class=react-scan-preview-line>",!1),createScanInput=createHTMLTemplate("<input type=text class=react-scan-input>",!1),createScanFlashOverlay=createHTMLTemplate("<div class=react-scan-flash-overlay>",!1),createPropertyElement=__name((componentName,didRender,propsContainer,fiber,key,value,section="",level=0,changedKeys=new Set,parentPath="",objectPathMap=new WeakMap)=>{try{changedAtInterval||(changedAtInterval=setInterval(()=>{for(const[key2,value2]of changedAt)Date.now()-value2>450&&changedAt.delete(key2)},200));const container=createScanPropertyContainer(),isExpandable=!isPromise(value)&&(Array.isArray(value)&&value.length>0||typeof value=="object"&&value!==null&&Object.keys(value).length>0),currentPath=getPath(componentName,section,parentPath,key),prevValue=lastRendered.get(currentPath),isChanged=prevValue!==void 0&&prevValue!==value,isBadRender=value&&["object","function"].includes(typeof value)&&fastSerialize(value)===fastSerialize(prevValue)&&isChanged;if(lastRendered.set(currentPath,value),isExpandable){const isExpanded=EXPANDED_PATHS.has(currentPath);if(typeof value=="object"&&value!==null){let paths=objectPathMap.get(value);if(paths||(paths=new Set,objectPathMap.set(value,paths)),paths.has(currentPath))return createCircularReferenceElement(key);paths.add(currentPath)}container.classList.add("react-scan-expandable"),isExpanded&&container.classList.add("react-scan-expanded");const arrow=createScanArrow(),contentWrapper=createScanPropertyContent(),preview=createScanPreviewLine();preview.dataset.key=key,preview.dataset.section=section,preview.innerHTML=`
        ${isBadRender?'<span class="react-scan-warning">⚠️</span>':""}
        <span class="react-scan-key">${key}:&nbsp;</span><span class="${getValueClassName(value)} react-scan-value truncate">${getValuePreview(value)}</span>
      `;const content=document.createElement("div");if(content.className=isExpanded?"react-scan-nested-object":"react-scan-nested-object react-scan-hidden",contentWrapper.appendChild(preview),contentWrapper.appendChild(content),container.appendChild(contentWrapper),isExpanded)if(Array.isArray(value))for(let i2=0,len=value.length;i2<len;i2++){const el=createPropertyElement(componentName,didRender,propsContainer,fiber,`${i2}`,value[i2],section,level+1,changedKeys,currentPath,objectPathMap);el&&content.appendChild(el)}else for(const k2 in value){const v2=value[key],el=createPropertyElement(componentName,didRender,propsContainer,fiber,k2,v2,section,level+1,changedKeys,currentPath,objectPathMap);el&&content.appendChild(el)}arrow.addEventListener("click",e2=>{if(e2.stopPropagation(),!container.classList.contains("react-scan-expanded")){if(EXPANDED_PATHS.add(currentPath),container.classList.add("react-scan-expanded"),content.classList.remove("react-scan-hidden"),!content.hasChildNodes())if(Array.isArray(value))for(let i2=0,len=value.length;i2<len;i2++){const el=createPropertyElement(componentName,didRender,propsContainer,fiber,`${i2}`,value[i2],section,level+1,changedKeys,currentPath,new WeakMap);el&&content.appendChild(el)}else for(const k2 in value){const v2=value[k2],el=createPropertyElement(componentName,didRender,propsContainer,fiber,k2,v2,section,level+1,changedKeys,currentPath,new WeakMap);el&&content.appendChild(el)}}else EXPANDED_PATHS.delete(currentPath),container.classList.remove("react-scan-expanded"),content.classList.add("react-scan-hidden")})}else{const preview=createScanPreviewLine();if(preview.dataset.key=key,preview.dataset.section=section,preview.innerHTML=`
        ${isBadRender?'<span class="react-scan-warning">⚠️</span>':""}
        <span class="react-scan-key">${key}:&nbsp;</span><span class="${getValueClassName(value)} react-scan-value truncate">${getValuePreview(value)}</span>
      `,container.appendChild(preview),section==="props"||section==="state"){const valueElement=preview.querySelector(".react-scan-value"),{overrideProps,overrideHookState}=getOverrideMethods();valueElement&&(section==="props"?!!overrideProps:!!overrideHookState)&&(typeof value=="string"||typeof value=="number"||typeof value=="boolean")&&(valueElement.classList.add("react-scan-editable"),valueElement.addEventListener("click",e2=>{e2.stopPropagation();const input=createScanInput();input.value=value.toString();const updateValue=__name(()=>{const newValue=input.value;value=typeof value=="number"?Number(newValue):newValue,valueElement.dataset.text=getValuePreview(value),tryOrElse(()=>{input.replaceWith(valueElement)},null),tryOrElse(()=>{const{overrideProps:overrideProps2,overrideHookState:overrideHookState2}=getOverrideMethods();overrideProps2&&section==="props"&&overrideProps2(fiber,[key],value),overrideHookState2&&section==="state"&&overrideHookState2(fiber,key,[],value)},null)},"updateValue");input.addEventListener("blur",updateValue),input.addEventListener("keydown",event=>{event.key==="Enter"&&updateValue()}),valueElement.replaceWith(input),input.focus()}))}}if(changedKeys.has(key)&&changedAt.set(currentPath,Date.now()),changedAt.has(currentPath)){const flashOverlay=createScanFlashOverlay();container.appendChild(flashOverlay),flashOverlay.style.opacity=".9";const existingTimer=fadeOutTimers.get(flashOverlay);existingTimer!==void 0&&clearTimeout(existingTimer);const timerId=setTimeout(()=>{flashOverlay.style.transition="opacity 400ms ease-out",flashOverlay.style.opacity="0",fadeOutTimers.delete(flashOverlay)},300);fadeOutTimers.set(flashOverlay,timerId)}return container}catch{return null}},"createPropertyElement"),createCircularReferenceElement=__name(key=>{const container=createScanPropertyContainer(),preview=createScanPreviewLine();return preview.innerHTML=`
    <span class="react-scan-key">${key}:&nbsp;</span><span class="react-scan-circular">[Circular Reference]</span>
  `,container.appendChild(preview),container},"createCircularReferenceElement"),getValueClassName=__name(value=>{if(Array.isArray(value))return"react-scan-array";if(value==null)return"react-scan-null";switch(typeof value){case"string":return"react-scan-string";case"number":return"react-scan-number";case"boolean":return"react-scan-boolean";case"object":return"react-scan-object-key";default:return""}},"getValueClassName"),getValuePreview=__name(value=>{if(Array.isArray(value))return`Array(${value.length})`;if(value===null)return"null";if(value===void 0)return"undefined";switch(typeof value){case"string":return`&quot;${value}&quot;`;case"number":return value.toString();case"boolean":return value.toString();case"object":{if(value instanceof Promise)return"Promise";const keys=Object.keys(value);return keys.length<=3?`{${keys.join(", ")}}`:`{${keys.slice(0,8).join(", ")}, ...}`}default:return typeof value}},"getValuePreview"),INSPECT_OVERLAY_CANVAS_ID="react-scan-inspect-canvas",lastHoveredElement,animationId,createInspectElementStateMachine=__name(shadow=>{if(typeof window>"u")return;let canvas=document.getElementById(INSPECT_OVERLAY_CANVAS_ID);if(!canvas){canvas=document.createElement("canvas"),canvas.id=INSPECT_OVERLAY_CANVAS_ID,canvas.style.cssText=`
    position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 100vh;
    pointer-events: none;
    z-index: 214748367;
  `,shadow.appendChild(canvas);const ctx2=canvas.getContext("2d",{alpha:!0});if(!ctx2)return;updateCanvasSize(canvas,ctx2),window.addEventListener("resize",()=>{updateCanvasSize(canvas,ctx2)},{capture:!0})}const ctx=canvas.getContext("2d",{alpha:!0});if(!ctx)return;const clearCanvas=__name(()=>{cancelAnimationFrame(animationId),ctx.save(),ctx.setTransform(1,0,0,1,0,0),ctx.clearRect(0,0,canvas.width,canvas.height),ctx.restore()},"clearCanvas"),unsubscribeFns={focused:void 0,"inspect-off":void 0,inspecting:void 0,uninitialized:void 0},unsubscribeAll=__name(()=>{var _a2;for(const key in unsubscribeFns)(_a2=unsubscribeFns[key])==null||_a2.call(unsubscribeFns)},"unsubscribeAll"),recursiveRaf=__name(cb=>{const helper=__name(()=>{animationId&&cancelAnimationFrame(animationId),animationId=requestAnimationFrame(()=>{cb(),helper()})},"helper");helper()},"recursiveRaf");window.addEventListener("mousemove",()=>{Store.inspectState.value.kind==="inspect-off"&&(clearCanvas(),updateCanvasSize(canvas,ctx))},{capture:!0});let previousState;const repaint=throttle(()=>{const unSub=(()=>{const inspectState=Store.inspectState.value;switch(inspectState.kind){case"uninitialized":return;case"inspect-off":{previousState!=="inspect-off"&&setTimeout(()=>{cancelAnimationFrame(animationId),unsubscribeAll(),clearCanvas()},100),clearCanvas();return}case"inspecting":{unsubscribeAll(),recursiveRaf(()=>{inspectState.hoveredDomElement&&drawHoverOverlay(inspectState.hoveredDomElement,canvas,ctx,"inspecting")});const eventCatcher=document.createElement("div");eventCatcher.style.cssText=`
              position: fixed;
              left: 0;
              top: 0;
              width: 100vw;
              height: 100vh;
              z-index: ${parseInt(canvas.style.zIndex)-1};
              pointer-events: auto;
            `,canvas.parentNode.insertBefore(eventCatcher,canvas);let currentHoveredElement=null;const mouseMove=throttle(e2=>{if(Store.inspectState.value.kind!=="inspecting")return;eventCatcher.style.pointerEvents="none";const el=document.elementFromPoint(e2.clientX,e2.clientY);eventCatcher.style.pointerEvents="auto",el&&(lastHoveredElement=el,currentHoveredElement=el,inspectState.hoveredDomElement=el,drawHoverOverlay(el,canvas,ctx,"inspecting"))},16);window.addEventListener("mousemove",mouseMove,{capture:!0});const pointerdown=__name(e2=>{e2.stopPropagation(),eventCatcher.style.pointerEvents="none";const el=currentHoveredElement??document.elementFromPoint(e2.clientX,e2.clientY)??lastHoveredElement;eventCatcher.style.pointerEvents="auto",el&&(drawHoverOverlay(el,canvas,ctx,"locked"),Store.inspectState.value={kind:"focused",focusedDomElement:el,propContainer:inspectState.propContainer})},"pointerdown");window.addEventListener("pointerdown",pointerdown,{capture:!0});const keyDown=__name(e2=>{e2.key==="Escape"&&(Store.inspectState.value={kind:"inspect-off",propContainer:inspectState.propContainer},clearCanvas())},"keyDown");window.addEventListener("keydown",keyDown,{capture:!0});let cleanup=__name(()=>{},"cleanup");return inspectState.hoveredDomElement&&(cleanup=trackElementPosition(inspectState.hoveredDomElement,()=>{drawHoverOverlay(inspectState.hoveredDomElement,canvas,ctx,"inspecting")})),()=>{var _a2;cancelAnimationFrame(animationId),window.removeEventListener("pointerdown",pointerdown,{capture:!0}),window.removeEventListener("mousemove",mouseMove,{capture:!0}),window.removeEventListener("keydown",keyDown,{capture:!0}),(_a2=eventCatcher.parentNode)==null||_a2.removeChild(eventCatcher),cleanup()}}case"focused":{if(unsubscribeAll(),recursiveRaf(()=>{drawHoverOverlay(inspectState.focusedDomElement,canvas,ctx,"locked")}),!document.contains(inspectState.focusedDomElement)){setTimeout(()=>{clearCanvas()},500),Store.inspectState.value={kind:"inspect-off",propContainer:inspectState.propContainer};return}drawHoverOverlay(inspectState.focusedDomElement,canvas,ctx,"locked");const element=inspectState.focusedDomElement,{parentCompositeFiber}=getCompositeComponentFromElement(element);if(!parentCompositeFiber)return;const didRender=didFiberRender(parentCompositeFiber);renderPropsAndState(didRender,parentCompositeFiber);const keyDown=__name(e2=>{e2.key==="Escape"&&(clearCanvas(),drawHoverOverlay(e2.target??inspectState.focusedDomElement,canvas,ctx,"inspecting"),Store.inspectState.value={kind:"inspecting",hoveredDomElement:e2.target??inspectState.focusedDomElement,propContainer:inspectState.propContainer})},"keyDown");window.addEventListener("keydown",keyDown,{capture:!0});const onpointerdownCanvasLockIcon=__name(e2=>{if(!currentLockIconRect)return;const rect=canvas.getBoundingClientRect(),scaleX=canvas.width/rect.width,scaleY=canvas.height/rect.height,x2=(e2.clientX-rect.left)*scaleX,y2=(e2.clientY-rect.top)*scaleY,adjustedX=x2/OVERLAY_DPR,adjustedY=y2/OVERLAY_DPR;if(adjustedX>=currentLockIconRect.x&&adjustedX<=currentLockIconRect.x+currentLockIconRect.width&&adjustedY>=currentLockIconRect.y&&adjustedY<=currentLockIconRect.y+currentLockIconRect.height){inspectState.propContainer.innerHTML="",clearCanvas(),drawHoverOverlay(e2.target,canvas,ctx,"inspecting"),e2.stopPropagation(),Store.inspectState.value={kind:"inspecting",hoveredDomElement:e2.target,propContainer:inspectState.propContainer};return}},"onpointerdownCanvasLockIcon");window.addEventListener("pointerdown",onpointerdownCanvasLockIcon,{capture:!0});const cleanup=trackElementPosition(inspectState.focusedDomElement,()=>{drawHoverOverlay(inspectState.focusedDomElement,canvas,ctx,"locked")});return()=>{cleanup(),cancelAnimationFrame(animationId),window.removeEventListener("keydown",keyDown,{capture:!0}),window.removeEventListener("pointerdown",onpointerdownCanvasLockIcon,{capture:!0})}}}})();unSub&&(unsubscribeFns[Store.inspectState.value.kind]=unSub),previousState=Store.inspectState.value.kind},70);return Store.inspectState.subscribe(repaint),Store.lastReportTime.subscribe(repaint),()=>{}},"createInspectElementStateMachine"),trackElementPosition=__name((element,callback)=>{const handleAnyScroll=__name(()=>{callback(element)},"handleAnyScroll");return document.addEventListener("scroll",handleAnyScroll,{passive:!0,capture:!0}),()=>{document.removeEventListener("scroll",handleAnyScroll,{capture:!0})}},"trackElementPosition"),lastPlayTime=0,MIN_INTERVAL=32,BASE_VOLUME=.5,FREQ_MULTIPLIER=200,DEFAULT_VOLUME=.5,storedVolume=Math.max(0,Math.min(1,readLocalStorage("react-scan-volume")??DEFAULT_VOLUME)),config={firefox:{duration:.02,oscillatorType:"sine",startFreq:220,endFreq:110,attack:5e-4,volumeMultiplier:storedVolume},default:{duration:.001,oscillatorType:"sine",startFreq:440,endFreq:220,attack:5e-4,volumeMultiplier:storedVolume}},audioConfig=isFirefox?config.firefox:config.default,playGeigerClickSound=__name((audioContext,amplitude)=>{const now=performance.now();if(now-lastPlayTime<MIN_INTERVAL)return;lastPlayTime=now;const currentTime=audioContext.currentTime,{duration,oscillatorType,startFreq,endFreq,attack}=audioConfig,volume=Math.max(BASE_VOLUME,amplitude)*audioConfig.volumeMultiplier,oscillator=new OscillatorNode(audioContext,{type:oscillatorType,frequency:startFreq+amplitude*FREQ_MULTIPLIER}),gainNode=new GainNode(audioContext,{gain:0});oscillator.frequency.exponentialRampToValueAtTime(endFreq,currentTime+duration),gainNode.gain.linearRampToValueAtTime(volume,currentTime+attack),oscillator.connect(gainNode).connect(audioContext.destination),oscillator.start(currentTime),oscillator.stop(currentTime+duration)},"playGeigerClickSound"),ICONS=`
<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
  <symbol id="icon-eye-off" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49"/>
    <path d="M14.084 14.158a3 3 0 0 1-4.242-4.242"/>
    <path d="M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143"/>
    <path d="m2 2 20 20"/>
  </symbol>

  <symbol id="icon-eye" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0" />
    <circle cx="12" cy="12" r="3" />
  </symbol>


  <symbol id="icon-inspect" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z"/>
    <path d="M5 3a2 2 0 0 0-2 2"/>
    <path d="M19 3a2 2 0 0 1 2 2"/>
    <path d="M5 21a2 2 0 0 1-2-2"/>
    <path d="M9 3h1"/>
    <path d="M9 21h2"/>
    <path d="M14 3h1"/>
    <path d="M3 9v1"/>
    <path d="M21 9v2"/>
    <path d="M3 14v1"/>
  </symbol>

  <symbol id="icon-focus" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M12.034 12.681a.498.498 0 0 1 .647-.647l9 3.5a.5.5 0 0 1-.033.943l-3.444 1.068a1 1 0 0 0-.66.66l-1.067 3.443a.5.5 0 0 1-.943.033z"/>
    <path d="M21 11V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"/>
  </symbol>

  <symbol id="icon-next" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M6 9h6V5l7 7-7 7v-4H6V9z"/>
  </symbol>

  <symbol id="icon-previous" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M18 15h-6v4l-7-7 7-7v4h6v6z"/>
  </symbol>

  <symbol id="icon-volume-on" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/>
    <path d="M16 9a5 5 0 0 1 0 6"/>
    <path d="M19.364 18.364a9 9 0 0 0 0-12.728"/>
  </symbol>

  <symbol id="icon-volume-off" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M11 4.702a.705.705 0 0 0-1.203-.498L6.413 7.587A1.4 1.4 0 0 1 5.416 8H3a1 1 0 0 0-1 1v6a1 1 0 0 0 1 1h2.416a1.4 1.4 0 0 1 .997.413l3.383 3.384A.705.705 0 0 0 11 19.298z"/>
    <line x1="22" x2="16" y1="9" y2="15"/>
    <line x1="16" x2="22" y1="9" y2="15"/>
  </symbol>

  <symbol id="icon-scan-eye" viewBox="0 0 24 24">
    <path d="M3 7V5a2 2 0 0 1 2-2h2"/>
    <path d="M17 3h2a2 2 0 0 1 2 2v2"/>
    <path d="M21 17v2a2 2 0 0 1-2 2h-2"/>
    <path d="M7 21H5a2 2 0 0 1-2-2v-2"/>
    <circle cx="12" cy="12" r="1"/>
    <path d="M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0"/>
  </symbol>

  <symbol id="icon-close" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <line x1="18" y1="6" x2="6" y2="18"/>
    <line x1="6" y1="6" x2="18" y2="18"/>
  </symbol>

  <symbol id="icon-replay" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="M3 7V5a2 2 0 0 1 2-2h2"/>
    <path d="M17 3h2a2 2 0 0 1 2 2v2"/>
    <path d="M21 17v2a2 2 0 0 1-2 2h-2"/>
    <path d="M7 21H5a2 2 0 0 1-2-2v-2"/>
    <circle cx="12" cy="12" r="1"/>
    <path d="M18.944 12.33a1 1 0 0 0 0-.66 7.5 7.5 0 0 0-13.888 0 1 1 0 0 0 0 .66 7.5 7.5 0 0 0 13.888 0"/>
  </symbol>

  <symbol id="icon-chevrons-up-down" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="m7 15 5 5 5-5"/>
    <path d="m7 9 5-5 5 5"/>
  </symbol>

  <symbol id="icon-chevron-down" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
    <path d="m6 9 6 6 6-6"/>
  </symbol>
</svg>
`,initReactScanOverlay=__name(()=>{const container=document.getElementById("react-scan-root"),shadow=container==null?void 0:container.shadowRoot;if(!shadow)return null;const overlayElement=document.createElement("canvas");overlayElement.id="react-scan-overlay",overlayElement.style.position="fixed",overlayElement.style.top="0",overlayElement.style.left="0",overlayElement.style.width="100vw",overlayElement.style.height="100vh",overlayElement.style.pointerEvents="none",overlayElement.style.zIndex="2147483646",overlayElement.setAttribute("aria-hidden","true"),shadow.appendChild(overlayElement);const ctx=overlayElement.getContext("2d");if(!ctx)return null;let resizeScheduled=!1;const updateCanvasSize2=__name(()=>{const dpi=window.devicePixelRatio||1;overlayElement.width=dpi*window.innerWidth,overlayElement.height=dpi*window.innerHeight,overlayElement.style.width=`${window.innerWidth}px`,overlayElement.style.height=`${window.innerHeight}px`,ctx.resetTransform(),ctx.scale(dpi,dpi),resizeScheduled=!1},"updateCanvasSize2");return window.addEventListener("resize",()=>{recalcOutlines(),resizeScheduled||(resizeScheduled=!0,requestAnimationFrame(()=>{updateCanvasSize2()}))}),window.addEventListener("scroll",()=>{recalcOutlines()}),updateCanvasSize2(),ctx},"initReactScanOverlay"),SAFE_AREA=24,MIN_SIZE={width:360,height:36},LOCALSTORAGE_KEY="react-scan-widget-settings",signalRefContainer=d$1(null),defaultWidgetConfig={corner:"top-left",dimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:{x:SAFE_AREA,y:SAFE_AREA}},lastDimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:{x:SAFE_AREA,y:SAFE_AREA}}},getInitialWidgetConfig=__name((s2=!1)=>{if(typeof window>"u"&&s2)return defaultWidgetConfig;const stored=readLocalStorage(LOCALSTORAGE_KEY);if(!stored){const defaultConfig={corner:"top-left",dimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:{x:24,y:24}},lastDimensions:{isFullWidth:!1,isFullHeight:!1,width:360,height:240,position:{x:24,y:24}}};return saveLocalStorage(LOCALSTORAGE_KEY,{corner:defaultConfig.corner,dimensions:defaultConfig.dimensions,lastDimensions:defaultConfig.lastDimensions}),defaultConfig}return{corner:stored.corner,dimensions:{isFullWidth:!1,isFullHeight:!1,width:MIN_SIZE.width,height:MIN_SIZE.height,position:stored.dimensions.position},lastDimensions:stored.dimensions}},"getInitialWidgetConfig"),signalWidget=d$1(getInitialWidgetConfig()),updateDimensions=__name(()=>{if(typeof window>"u")return;const{dimensions}=signalWidget.value,{width,height,position}=dimensions;signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:width>=window.innerWidth-SAFE_AREA*2,isFullHeight:height>=window.innerHeight-SAFE_AREA*2,width,height,position}}},"updateDimensions"),Icon=A((props,ref)=>{const{size=15,name,fill="currentColor",stroke="currentColor",className,externalURL="",style}=props,width=Array.isArray(size)?size[0]:size,height=Array.isArray(size)?size[1]||size[0]:size,attributes={width:`${width}px`,height:`${height}px`,fill,stroke,className,style},path=`${externalURL}#${name}`;return u("svg",{ref,...attributes,children:u("use",{href:path})})}),useSubscribeFocusedFiber=__name(onUpdate=>{y$1(()=>{const subscribe=__name(()=>{if(Store.inspectState.value.kind!=="focused")return;const focusedElement=Store.inspectState.value.focusedDomElement,{parentCompositeFiber}=getCompositeComponentFromElement(focusedElement);parentCompositeFiber&&onUpdate(parentCompositeFiber)},"subscribe"),unSubReportTime=Store.lastReportTime.subscribe(subscribe),unSubState=Store.inspectState.subscribe(subscribe);return()=>{unSubReportTime(),unSubState()}},[])},"useSubscribeFocusedFiber"),Header=__name(()=>{const[componentName,setComponentName]=h$1(null),[componentRenders,setComponentRenders]=h$1(null),[componentTime,setComponentTime]=h$1(null);return useSubscribeFocusedFiber(fiber=>{const displayName=getDisplayName(fiber.type),reportData=Store.reportData.get(fiber);setComponentName(displayName??"Unknown"),setComponentRenders((reportData==null?void 0:reportData.count)??null),setComponentTime(reportData!=null&&reportData.time&&reportData.time>0?reportData==null?void 0:reportData.time:null)}),u("div",{class:"react-scan-header",children:[u("div",{style:{gap:"0.5rem",display:"flex",width:"50%",justifyContent:"start",alignItems:"center"},children:[u("span",{children:componentName}),componentRenders!==null&&u("span",{children:["• x",componentRenders," "]}),componentTime!==null&&u("span",{class:"react-scan-component-time",children:["• ",componentTime.toFixed(2),"ms"]})]}),u("div",{style:{width:"50%",display:"flex",justifyContent:"end",alignItems:"center",columnGap:"2px"},children:u("button",{title:"Close",style:{display:"flex",alignItems:"center",padding:"0.25rem",minWidth:"fit-content",borderRadius:"0.25rem",transition:"color 150ms linear"},onClick:__name(()=>{Store.inspectState.value.propContainer&&(Store.inspectState.value={kind:"inspect-off",propContainer:Store.inspectState.value.propContainer})},"onClick"),children:u(Icon,{name:"icon-close"})})})]})},"Header"),getWindowDimensions=(()=>{let cache2=null;return()=>{const currentWidth=window.innerWidth,currentHeight=window.innerHeight;if(cache2&&cache2.width===currentWidth&&cache2.height===currentHeight)return{maxWidth:cache2.maxWidth,maxHeight:cache2.maxHeight,rightEdge:cache2.rightEdge,bottomEdge:cache2.bottomEdge,isFullWidth:cache2.isFullWidth,isFullHeight:cache2.isFullHeight};const maxWidth=currentWidth-SAFE_AREA*2,maxHeight=currentHeight-SAFE_AREA*2;return cache2={width:currentWidth,height:currentHeight,maxWidth,maxHeight,rightEdge:__name(width=>currentWidth-width-SAFE_AREA,"rightEdge"),bottomEdge:__name(height=>currentHeight-height-SAFE_AREA,"bottomEdge"),isFullWidth:__name(width=>width>=maxWidth,"isFullWidth"),isFullHeight:__name(height=>height>=maxHeight,"isFullHeight")},{maxWidth:cache2.maxWidth,maxHeight:cache2.maxHeight,rightEdge:cache2.rightEdge,bottomEdge:cache2.bottomEdge,isFullWidth:cache2.isFullWidth,isFullHeight:cache2.isFullHeight}}})(),getOppositeCorner=__name((position,currentCorner,isFullScreen,isFullWidth,isFullHeight)=>{if(isFullScreen){if(position==="top-left")return"bottom-right";if(position==="top-right")return"bottom-left";if(position==="bottom-left")return"top-right";if(position==="bottom-right")return"top-left";const[vertical,horizontal]=currentCorner.split("-");if(position==="left")return`${vertical}-right`;if(position==="right")return`${vertical}-left`;if(position==="top")return`bottom-${horizontal}`;if(position==="bottom")return`top-${horizontal}`}if(isFullWidth){if(position==="left")return`${currentCorner.split("-")[0]}-right`;if(position==="right")return`${currentCorner.split("-")[0]}-left`}if(isFullHeight){if(position==="top")return`bottom-${currentCorner.split("-")[1]}`;if(position==="bottom")return`top-${currentCorner.split("-")[1]}`}return currentCorner},"getOppositeCorner"),calculatePosition=__name((corner,width,height)=>{const windowWidth=window.innerWidth,windowHeight=window.innerHeight,isMinimized=width===MIN_SIZE.width,effectiveWidth=isMinimized?width:Math.min(width,windowWidth-SAFE_AREA*2),effectiveHeight=isMinimized?height:Math.min(height,windowHeight-SAFE_AREA*2);let x2,y2;switch(corner){case"top-right":x2=windowWidth-effectiveWidth-SAFE_AREA,y2=SAFE_AREA;break;case"bottom-right":x2=windowWidth-effectiveWidth-SAFE_AREA,y2=windowHeight-effectiveHeight-SAFE_AREA;break;case"bottom-left":x2=SAFE_AREA,y2=windowHeight-effectiveHeight-SAFE_AREA;break;case"top-left":default:x2=SAFE_AREA,y2=SAFE_AREA;break}return isMinimized&&(x2=Math.max(SAFE_AREA,Math.min(x2,windowWidth-effectiveWidth-SAFE_AREA)),y2=Math.max(SAFE_AREA,Math.min(y2,windowHeight-effectiveHeight-SAFE_AREA))),{x:x2,y:y2}},"calculatePosition"),getPositionClasses=__name(position=>{switch(position){case"top":return"top-0 left-0 right-0 -translate-y-3/4";case"bottom":return"right-0 bottom-0 left-0 translate-y-3/4";case"left":return"top-0 bottom-0 left-0 -translate-x-3/4";case"right":return"top-0 right-0 bottom-0 translate-x-3/4";case"top-left":return"top-0 left-0 -translate-x-3/4 -translate-y-3/4";case"top-right":return"top-0 right-0 translate-x-3/4 -translate-y-3/4";case"bottom-left":return"bottom-0 left-0 -translate-x-3/4 translate-y-3/4";case"bottom-right":return"bottom-0 right-0 translate-x-3/4 translate-y-3/4";default:return""}},"getPositionClasses"),getInteractionClasses=__name((position,isLine)=>{const commonClasses=["transition-[transform,opacity]","duration-300","delay-500","group-hover:delay-0","group-active:delay-0"];return isLine?[...commonClasses,position==="left"||position==="right"?"w-6":"w-full",position==="left"||position==="right"?"h-full":"h-6",position==="left"||position==="right"?"cursor-ew-resize":"cursor-ns-resize"]:[...commonClasses,"w-6","h-6",position==="top-left"||position==="bottom-right"?"cursor-nwse-resize":"cursor-nesw-resize",`rounded-${position.split("-").join("")}`]},"getInteractionClasses"),positionMatchesCorner=__name((position,corner)=>{const[vertical,horizontal]=corner.split("-");return position!==vertical&&position!==horizontal},"positionMatchesCorner"),getHandleVisibility=__name((position,isLine,corner,isFullWidth,isFullHeight)=>isFullWidth&&isFullHeight?!0:!isFullWidth&&!isFullHeight?isLine?positionMatchesCorner(position,corner):position===getOppositeCorner(corner,corner,!0):isFullWidth?isLine?position!==corner.split("-")[0]:!position.startsWith(corner.split("-")[0]):isFullHeight?isLine?position!==corner.split("-")[1]:!position.endsWith(corner.split("-")[1]):!1,"getHandleVisibility"),calculateBoundedSize=__name((currentSize,delta,isWidth)=>{const min=isWidth?MIN_SIZE.width:MIN_SIZE.height*5,max=isWidth?getWindowDimensions().maxWidth:getWindowDimensions().maxHeight,newSize=currentSize+delta;return Math.min(Math.max(min,newSize),max)},"calculateBoundedSize"),calculateNewSizeAndPosition=__name((position,initialSize,initialPosition,deltaX,deltaY)=>{const maxWidth=window.innerWidth-SAFE_AREA*2,maxHeight=window.innerHeight-SAFE_AREA*2;let newWidth=initialSize.width,newHeight=initialSize.height,newX=initialPosition.x,newY=initialPosition.y;if(position.includes("right")){const availableWidth=window.innerWidth-initialPosition.x-SAFE_AREA,proposedWidth=Math.min(initialSize.width+deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth))}if(position.includes("left")){const availableWidth=initialPosition.x+initialSize.width-SAFE_AREA,proposedWidth=Math.min(initialSize.width-deltaX,availableWidth);newWidth=Math.min(maxWidth,Math.max(MIN_SIZE.width,proposedWidth)),newX=initialPosition.x-(newWidth-initialSize.width)}if(position.includes("bottom")){const availableHeight=window.innerHeight-initialPosition.y-SAFE_AREA,proposedHeight=Math.min(initialSize.height+deltaY,availableHeight);newHeight=Math.min(maxHeight,Math.max(MIN_SIZE.height*5,proposedHeight))}if(position.includes("top")){const availableHeight=initialPosition.y+initialSize.height-SAFE_AREA,proposedHeight=Math.min(initialSize.height-deltaY,availableHeight);newHeight=Math.min(maxHeight,Math.max(MIN_SIZE.height*5,proposedHeight)),newY=initialPosition.y-(newHeight-initialSize.height)}return newX=Math.max(SAFE_AREA,Math.min(newX,window.innerWidth-SAFE_AREA-newWidth)),newY=Math.max(SAFE_AREA,Math.min(newY,window.innerHeight-SAFE_AREA-newHeight)),{newSize:{width:newWidth,height:newHeight},newPosition:{x:newX,y:newY}}},"calculateNewSizeAndPosition"),getClosestCorner=__name(position=>{const{maxWidth,maxHeight}=getWindowDimensions(),distances={"top-left":Math.hypot(position.x,position.y),"top-right":Math.hypot(maxWidth-position.x,position.y),"bottom-left":Math.hypot(position.x,maxHeight-position.y),"bottom-right":Math.hypot(maxWidth-position.x,maxHeight-position.y)};return Object.entries(distances).reduce((closest,[corner,distance])=>distance<distances[closest]?corner:closest,"top-left")},"getClosestCorner"),getBestCorner=__name((mouseX,mouseY,initialMouseX,initialMouseY,threshold=100)=>{const deltaX=initialMouseX!==void 0?mouseX-initialMouseX:0,deltaY=initialMouseY!==void 0?mouseY-initialMouseY:0,windowCenterX=window.innerWidth/2,windowCenterY=window.innerHeight/2,movingRight=deltaX>threshold,movingLeft=deltaX<-threshold,movingDown=deltaY>threshold,movingUp=deltaY<-threshold;if(movingRight||movingLeft){const isBottom=mouseY>windowCenterY;return movingRight?isBottom?"bottom-right":"top-right":isBottom?"bottom-left":"top-left"}if(movingDown||movingUp){const isRight=mouseX>windowCenterX;return movingDown?isRight?"bottom-right":"bottom-left":isRight?"top-right":"top-left"}return mouseX>windowCenterX?mouseY>windowCenterY?"bottom-right":"top-right":mouseY>windowCenterY?"bottom-left":"top-left"},"getBestCorner"),ResizeHandle=__name(({position})=>{const isLine=!position.includes("-"),refContainer=A$1(null),refLine=A$1(null),refCorner=A$1(null),prevWidth=A$1(null),prevHeight=A$1(null),prevCorner=A$1(null);y$1(()=>{if(!refContainer.current)return;const classes=getInteractionClasses(position,isLine);toggleMultipleClasses(refContainer.current,classes);const updateVisibility=__name(isFocused=>{if(!refContainer.current)return;isFocused&&getHandleVisibility(position,isLine,signalWidget.value.corner,signalWidget.value.dimensions.isFullWidth,signalWidget.value.dimensions.isFullHeight)?refContainer.current.classList.remove("hidden","pointer-events-none","opacity-0"):refContainer.current.classList.add("hidden","pointer-events-none","opacity-0")},"updateVisibility"),unsubscribeSignalWidget=signalWidget.subscribe(state=>{refContainer.current&&(prevWidth.current!==null&&prevHeight.current!==null&&prevCorner.current!==null&&state.dimensions.width===prevWidth.current&&state.dimensions.height===prevHeight.current&&state.corner===prevCorner.current||(updateVisibility(Store.inspectState.value.kind==="focused"),prevWidth.current=state.dimensions.width,prevHeight.current=state.dimensions.height,prevCorner.current=state.corner))}),unsubscribeStoreInspectState=Store.inspectState.subscribe(state=>{refContainer.current&&updateVisibility(state.kind==="focused")});return()=>{unsubscribeSignalWidget(),unsubscribeStoreInspectState(),prevWidth.current=null,prevHeight.current=null,prevCorner.current=null}},[]);const handleResize=q$1(e2=>{e2.preventDefault(),e2.stopPropagation();const container=signalRefContainer.value;if(!container)return;const containerStyle=container.style,{dimensions}=signalWidget.value,initialX=e2.clientX,initialY=e2.clientY,initialWidth=dimensions.width,initialHeight=dimensions.height,initialPosition=dimensions.position;signalWidget.value={...signalWidget.value,dimensions:{...dimensions,isFullWidth:!1,isFullHeight:!1,width:initialWidth,height:initialHeight,position:initialPosition}};let rafId=null;const handleMouseMove=__name(e22=>{rafId||(containerStyle.transition="none",rafId=requestAnimationFrame(()=>{const{newSize,newPosition}=calculateNewSizeAndPosition(position,{width:initialWidth,height:initialHeight},initialPosition,e22.clientX-initialX,e22.clientY-initialY);containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`,containerStyle.width=`${newSize.width}px`,containerStyle.height=`${newSize.height}px`,signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:!1,isFullHeight:!1,width:newSize.width,height:newSize.height,position:newPosition}},rafId=null}))},"handleMouseMove"),handleMouseUp=__name(()=>{rafId&&cancelAnimationFrame(rafId);const{dimensions:dimensions2,corner}=signalWidget.value,{isFullWidth,isFullHeight}=getWindowDimensions(),isCurrentFullWidth=isFullWidth(dimensions2.width),isCurrentFullHeight=isFullHeight(dimensions2.height),isFullScreen=isCurrentFullWidth&&isCurrentFullHeight;let newCorner=corner;(isFullScreen||isCurrentFullWidth||isCurrentFullHeight)&&(newCorner=getClosestCorner(dimensions2.position));const newPosition=calculatePosition(newCorner,dimensions2.width,dimensions2.height),onTransitionEnd=__name(()=>{container.removeEventListener("transitionend",onTransitionEnd)},"onTransitionEnd");container.addEventListener("transitionend",onTransitionEnd),containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`,signalWidget.value={corner:newCorner,dimensions:{isFullWidth:isCurrentFullWidth,isFullHeight:isCurrentFullHeight,width:dimensions2.width,height:dimensions2.height,position:newPosition},lastDimensions:{isFullWidth:isCurrentFullWidth,isFullHeight:isCurrentFullHeight,width:dimensions2.width,height:dimensions2.height,position:newPosition}},saveLocalStorage(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions}),document.removeEventListener("mousemove",handleMouseMove),document.removeEventListener("mouseup",handleMouseUp)},"handleMouseUp");document.addEventListener("mousemove",handleMouseMove,{passive:!0}),document.addEventListener("mouseup",handleMouseUp)},[]),handleDoubleClick=q$1(e2=>{e2.preventDefault(),e2.stopPropagation();const container=signalRefContainer.value;if(!container)return;const containerStyle=container.style,{dimensions,corner}=signalWidget.value,{maxWidth,maxHeight,isFullWidth,isFullHeight}=getWindowDimensions(),isCurrentFullWidth=isFullWidth(dimensions.width),isCurrentFullHeight=isFullHeight(dimensions.height),isFullScreen=isCurrentFullWidth&&isCurrentFullHeight,isPartiallyMaximized=(isCurrentFullWidth||isCurrentFullHeight)&&!isFullScreen;let newWidth=dimensions.width,newHeight=dimensions.height;const newCorner=getOppositeCorner(position,corner,isFullScreen,isCurrentFullWidth,isCurrentFullHeight);isLine?position==="left"||position==="right"?(newWidth=isCurrentFullWidth?dimensions.width:maxWidth,isPartiallyMaximized&&(newWidth=isCurrentFullWidth?MIN_SIZE.width:maxWidth)):(newHeight=isCurrentFullHeight?dimensions.height:maxHeight,isPartiallyMaximized&&(newHeight=isCurrentFullHeight?MIN_SIZE.height*5:maxHeight)):(newWidth=maxWidth,newHeight=maxHeight),isFullScreen&&(isLine?position==="left"||position==="right"?newWidth=MIN_SIZE.width:newHeight=MIN_SIZE.height*5:(newWidth=MIN_SIZE.width,newHeight=MIN_SIZE.height*5));const newPosition=calculatePosition(newCorner,newWidth,newHeight),newDimensions={isFullWidth:isFullWidth(newWidth),isFullHeight:isFullHeight(newHeight),width:newWidth,height:newHeight,position:newPosition};requestAnimationFrame(()=>{signalWidget.value={corner:newCorner,dimensions:newDimensions,lastDimensions:dimensions},containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",containerStyle.width=`${newWidth}px`,containerStyle.height=`${newHeight}px`,containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`}),saveLocalStorage(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:newDimensions,lastDimensions:dimensions})},[]);return u("div",{ref:refContainer,onMouseDown:handleResize,onDblClick:handleDoubleClick,className:cn("flex items-center justify-center","resize-handle absolute","group overflow-hidden","transition-opacity select-none z-50",getPositionClasses(position)),children:isLine?u("span",{ref:refLine,className:cn("absolute","opacity-0 group-hover:opacity-100 group-active:opacity-100","transition-[transform, opacity] duration-300","delay-500 group-hover:delay-0 group-active:delay-0 group-active:opacity-0",{"translate-y-full group-hover:-translate-y-1/4":position==="top","-translate-x-full group-hover:translate-x-1/4":position==="right","-translate-y-full group-hover:translate-y-1/4":position==="bottom","translate-x-full group-hover:-translate-x-1/4":position==="left"}),children:u(Icon,{name:"icon-chevrons-up-down",className:cn("text-[#7b51c8]",{"rotate-90":position==="left"||position==="right"})})}):u("span",{ref:refCorner,className:cn("absolute inset-0","flex items-center justify-center","opacity-0 group-hover:opacity-100 group-active:opacity-100","transition-[transform,opacity] duration-300","delay-500 group-hover:delay-0 group-active:delay-0","origin-center","text-[#7b51c8]",{"top-0 left-0 rotate-[135deg] translate-x-full translate-y-full":position==="top-left","top-0 right-0 rotate-[225deg] -translate-x-full translate-y-full":position==="top-right","bottom-0 left-0 rotate-45 translate-x-full -translate-y-full":position==="bottom-left","bottom-0 right-0 -rotate-45 -translate-x-full -translate-y-full":position==="bottom-right"},"group-hover:translate-x-0 group-hover:translate-y-0","group-active:opacity-0"),children:u(Icon,{name:"icon-chevrons-up-down"})})})},"ResizeHandle"),FpsMeter=__name(()=>{const[fps2,setFps]=h$1(null);return y$1(()=>{const intervalId=setInterval(()=>{setFps(getFPS())},100);return()=>clearInterval(intervalId)},[]),u("span",{style:{width:"fit-content"},"data-text":String(fps2),className:cn("with-data-text","flex gap-1 items-center","ml-2 px-2","h-full","text-white text-xs font-mono whitespace-nowrap","bg-neutral-700","rounded-full"),children:u("span",{className:"text-xxs",children:"FPS"})})},"FpsMeter"),Toolbar=__name(({refPropContainer})=>{var _a2,_b2,_c,_d;const inspectState=Store.inspectState,isInspectFocused=inspectState.value.kind==="focused",isInspectActive=inspectState.value.kind==="inspecting",{inspectIcon,inspectColor}=T$1(()=>{let inspectIcon2=null,inspectColor2="#999";return isInspectActive?(inspectIcon2=u(Icon,{name:"icon-inspect"}),inspectColor2="rgba(142, 97, 227, 1)"):isInspectFocused?(inspectIcon2=u(Icon,{name:"icon-focus"}),inspectColor2="rgba(142, 97, 227, 1)"):(inspectIcon2=u(Icon,{name:"icon-inspect"}),inspectColor2="#999"),{inspectIcon:inspectIcon2,inspectColor:inspectColor2}},[isInspectActive,isInspectFocused]),onToggleInspect=q$1(()=>{const currentState=Store.inspectState.value;switch(currentState.kind){case"inspecting":Store.inspectState.value={kind:"inspect-off",propContainer:currentState.propContainer};break;case"focused":Store.inspectState.value={kind:"inspect-off",propContainer:currentState.propContainer};break;case"inspect-off":Store.inspectState.value={kind:"inspecting",hoveredDomElement:null,propContainer:refPropContainer.current};break}},[Store.inspectState.value]),findNextElement=q$1((currentElement,direction)=>{const allElements=Array.from(document.querySelectorAll("*")).filter(el=>el instanceof HTMLElement),currentIndex=allElements.indexOf(currentElement);if(currentIndex===-1)return null;const currentFiber=getNearestFiberFromElement(currentElement),increment=direction==="next"?1:-1;let index=currentIndex+increment;for(;index>=0&&index<allElements.length;){const fiber=getNearestFiberFromElement(allElements[index]);if(fiber&&fiber!==currentFiber)return allElements[index];index+=increment}return null},[]),onPreviousFocus=q$1(()=>{const currentState=Store.inspectState.value;if(currentState.kind!=="focused"||!currentState.focusedDomElement)return;const prevElement=findNextElement(currentState.focusedDomElement,"previous");prevElement&&(Store.inspectState.value={kind:"focused",focusedDomElement:prevElement,propContainer:currentState.propContainer})},[findNextElement]),onNextFocus=q$1(()=>{const currentState=Store.inspectState.value;if(currentState.kind!=="focused"||!currentState.focusedDomElement)return;const nextElement=findNextElement(currentState.focusedDomElement,"next");nextElement&&(Store.inspectState.value={kind:"focused",focusedDomElement:nextElement,propContainer:currentState.propContainer})},[findNextElement]),onToggleActive=q$1(()=>{ReactScanInternals.instrumentation&&(ReactScanInternals.instrumentation.isPaused.value=!ReactScanInternals.instrumentation.isPaused.value)},[ReactScanInternals.instrumentation]),onSoundToggle=q$1(()=>{const newSoundState=!ReactScanInternals.options.value.playSound;setOptions({playSound:newSoundState})},[]);return y$1(()=>{Store.inspectState.value.kind==="uninitialized"&&(Store.inspectState.value={kind:"inspect-off",propContainer:refPropContainer.current})},[]),u("div",{className:"flex max-h-9 min-h-9 flex-1 items-stretch overflow-hidden",children:[u("button",{title:"Inspect element",onClick:onToggleInspect,className:"flex items-center justify-center px-3",style:{color:inspectColor},children:inspectIcon}),u("button",{id:"react-scan-power",title:(_a2=ReactScanInternals.instrumentation)!=null&&_a2.isPaused.value?"Start":"Stop",onClick:onToggleActive,className:cn("flex items-center justify-center px-3",{"text-white":!((_b2=ReactScanInternals.instrumentation)!=null&&_b2.isPaused.value),"text-[#999]":(_c=ReactScanInternals.instrumentation)==null?void 0:_c.isPaused.value}),children:u(Icon,{name:`icon-${(_d=ReactScanInternals.instrumentation)!=null&&_d.isPaused.value?"eye-off":"eye"}`})}),u("button",{id:"react-scan-sound-toggle",onClick:onSoundToggle,title:ReactScanInternals.options.value.playSound?"Sound On":"Sound Off",className:cn("flex items-center justify-center px-3",{"text-white":ReactScanInternals.options.value.playSound,"text-[#999]":!ReactScanInternals.options.value.playSound}),children:u(Icon,{name:`icon-${ReactScanInternals.options.value.playSound?"volume-on":"volume-off"}`})}),isInspectFocused&&u("div",{className:cn("flex items-stretch justify-between","ml-auto","border-l-1 border-white/10 text-[#999]","overflow-hidden"),children:[u("button",{id:"react-scan-previous-focus",title:"Previous element",onClick:onPreviousFocus,className:"flex items-center justify-center px-3",children:u(Icon,{name:"icon-previous"})}),u("button",{id:"react-scan-next-focus",title:"Next element",onClick:onNextFocus,className:"flex items-center justify-center px-3",children:u(Icon,{name:"icon-next"})})]}),u("div",{className:cn("flex items-center justify-center whitespace-nowrap py-1.5 px-2 text-sm text-white",{"ml-auto":!isInspectFocused}),children:["react-scan",u(FpsMeter,{})]})]})},"Toolbar"),toolbar_default=Toolbar,Widget=__name(()=>{const refShouldExpand=A$1(!1),refContainer=A$1(null),refContent=A$1(null),refPropContainer=A$1(null),refFooter=A$1(null),refInitialMinimizedWidth=A$1(0),refInitialMinimizedHeight=A$1(0),updateWidgetPosition=q$1((shouldSave=!0)=>{if(!refContainer.current)return;const isInspectFocused=Store.inspectState.value.kind==="focused",{corner}=signalWidget.value;let newWidth,newHeight;if(isInspectFocused){const lastDims=signalWidget.value.lastDimensions;newWidth=calculateBoundedSize(lastDims.width,0,!0),newHeight=calculateBoundedSize(lastDims.height,0,!1)}else{const currentDims=signalWidget.value.dimensions;currentDims.width>refInitialMinimizedWidth.current&&(signalWidget.value={...signalWidget.value,lastDimensions:{isFullWidth:currentDims.isFullWidth,isFullHeight:currentDims.isFullHeight,width:currentDims.width,height:currentDims.height,position:currentDims.position}}),newWidth=refInitialMinimizedWidth.current,newHeight=refInitialMinimizedHeight.current}const newPosition=calculatePosition(corner,newWidth,newHeight);(newWidth<MIN_SIZE.width||newHeight<MIN_SIZE.height*5)&&(shouldSave=!1);const container=refContainer.current,containerStyle=container.style,onTransitionEnd=__name(()=>{containerStyle.transition="none",updateDimensions(),container.removeEventListener("transitionend",onTransitionEnd)},"onTransitionEnd");container.addEventListener("transitionend",onTransitionEnd),containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",requestAnimationFrame(()=>{containerStyle.width=`${newWidth}px`,containerStyle.height=`${newHeight}px`,containerStyle.transform=`translate3d(${newPosition.x}px, ${newPosition.y}px, 0)`});const newDimensions={isFullWidth:newWidth>=window.innerWidth-SAFE_AREA*2,isFullHeight:newHeight>=window.innerHeight-SAFE_AREA*2,width:newWidth,height:newHeight,position:newPosition};signalWidget.value={corner,dimensions:newDimensions,lastDimensions:isInspectFocused?signalWidget.value.lastDimensions:newWidth>refInitialMinimizedWidth.current?newDimensions:signalWidget.value.lastDimensions},shouldSave&&saveLocalStorage(LOCALSTORAGE_KEY,{corner:signalWidget.value.corner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions}),updateDimensions()},[]),handleMouseDown=q$1(e2=>{if(e2.preventDefault(),!refContainer.current||e2.target.closest("button"))return;const container=refContainer.current,containerStyle=container.style,{dimensions}=signalWidget.value,initialMouseX=e2.clientX,initialMouseY=e2.clientY,initialX=dimensions.position.x,initialY=dimensions.position.y;let currentX=initialX,currentY=initialY,rafId=null,hasMoved=!1,lastMouseX=initialMouseX,lastMouseY=initialMouseY;const handleMouseMove=__name(e22=>{rafId||(hasMoved=!0,lastMouseX=e22.clientX,lastMouseY=e22.clientY,rafId=requestAnimationFrame(()=>{const deltaX=lastMouseX-initialMouseX,deltaY=lastMouseY-initialMouseY;currentX=Number(initialX)+deltaX,currentY=Number(initialY)+deltaY,containerStyle.transition="none",containerStyle.transform=`translate3d(${currentX}px, ${currentY}px, 0)`,rafId=null}))},"handleMouseMove"),handleMouseUp=__name(()=>{if(!container||(rafId&&cancelAnimationFrame(rafId),document.removeEventListener("mousemove",handleMouseMove),document.removeEventListener("mouseup",handleMouseUp),!hasMoved))return;const newCorner=getBestCorner(lastMouseX,lastMouseY,initialMouseX,initialMouseY,Store.inspectState.value.kind==="focused"?80:40);if(newCorner===signalWidget.value.corner){containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)";const currentPosition=signalWidget.value.dimensions.position;requestAnimationFrame(()=>{containerStyle.transform=`translate3d(${currentPosition.x}px, ${currentPosition.y}px, 0)`});return}const snappedPosition=calculatePosition(newCorner,dimensions.width,dimensions.height);if(currentX===initialX&&currentY===initialY)return;const onTransitionEnd=__name(()=>{containerStyle.transition="none",updateDimensions(),container.removeEventListener("transitionend",onTransitionEnd)},"onTransitionEnd");container.addEventListener("transitionend",onTransitionEnd),containerStyle.transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",requestAnimationFrame(()=>{containerStyle.transform=`translate3d(${snappedPosition.x}px, ${snappedPosition.y}px, 0)`}),signalWidget.value={corner:newCorner,dimensions:{isFullWidth:dimensions.isFullWidth,isFullHeight:dimensions.isFullHeight,width:dimensions.width,height:dimensions.height,position:snappedPosition},lastDimensions:signalWidget.value.lastDimensions},saveLocalStorage(LOCALSTORAGE_KEY,{corner:newCorner,dimensions:signalWidget.value.dimensions,lastDimensions:signalWidget.value.lastDimensions})},"handleMouseUp");document.addEventListener("mousemove",handleMouseMove),document.addEventListener("mouseup",handleMouseUp)},[]);return y$1(()=>{if(!refContainer.current||!refFooter.current)return;refContainer.current.style.width="min-content",refInitialMinimizedHeight.current=refFooter.current.offsetHeight,refInitialMinimizedWidth.current=refContainer.current.offsetWidth,refContainer.current.style.maxWidth=`calc(100vw - ${SAFE_AREA*2}px)`,refContainer.current.style.maxHeight=`calc(100vh - ${SAFE_AREA*2}px)`,Store.inspectState.value.kind!=="focused"&&(signalWidget.value={...signalWidget.value,dimensions:{isFullWidth:!1,isFullHeight:!1,width:refInitialMinimizedWidth.current,height:refInitialMinimizedHeight.current,position:signalWidget.value.dimensions.position}}),signalRefContainer.value=refContainer.current;const unsubscribeSignalWidget=signalWidget.subscribe(widget=>{if(!refContainer.current)return;const{x:x2,y:y2}=widget.dimensions.position,{width,height}=widget.dimensions,container=refContainer.current;requestAnimationFrame(()=>{container.style.transform=`translate3d(${x2}px, ${y2}px, 0)`,container.style.width=`${width}px`,container.style.height=`${height}px`})}),unsubscribeStoreInspectState=Store.inspectState.subscribe(state=>{if(!(!refContent.current||!refPropContainer.current)){if(refShouldExpand.current=state.kind==="focused",state.kind==="focused"){const{parentCompositeFiber}=getCompositeComponentFromElement(state.focusedDomElement);if(!parentCompositeFiber){setTimeout(()=>{Store.inspectState.value={kind:"inspect-off",propContainer:refPropContainer.current}},16);return}}else toggleMultipleClasses(refContent.current,["opacity-0","duration-0","delay-0"]);updateWidgetPosition()}});let resizeTimeout;const handleWindowResize=debounce(()=>{resizeTimeout&&cancelAnimationFrame(resizeTimeout),resizeTimeout=requestAnimationFrame(()=>{refContainer.current&&updateWidgetPosition(!0)})},32);return window.addEventListener("resize",handleWindowResize),updateWidgetPosition(!1),()=>{window.removeEventListener("resize",handleWindowResize),unsubscribeStoreInspectState(),unsubscribeSignalWidget(),saveLocalStorage(LOCALSTORAGE_KEY,{...defaultWidgetConfig,corner:signalWidget.value.corner})}},[]),u("div",{id:"react-scan-toolbar",ref:refContainer,onMouseDown:handleMouseDown,className:cn("fixed inset-0 rounded-lg shadow-lg","flex flex-col","bg-black","font-mono text-[13px]","user-select-none","opacity-0","cursor-move","z-[124124124124]","animate-fade-in animation-duration-300 animation-delay-300","will-change-transform"),children:[u("div",{ref:refContent,className:cn("relative","flex-1","flex flex-col","rounded-t-lg","overflow-hidden","opacity-100","transition-opacity duration-150"),children:[u(Header,{}),u("div",{ref:refPropContainer,className:cn("react-scan-prop","flex-1","text-white","transition-opacity duration-150 delay-150","overflow-y-auto overflow-x-hidden")})]}),u("div",{ref:refFooter,className:cn("h-9","flex items-center justify-between","transition-colors duration-200","overflow-hidden","rounded-lg"),children:u(toolbar_default,{refPropContainer})}),u(ResizeHandle,{position:"top"}),u(ResizeHandle,{position:"bottom"}),u(ResizeHandle,{position:"left"}),u(ResizeHandle,{position:"right"}),u(ResizeHandle,{position:"top-left"}),u(ResizeHandle,{position:"top-right"}),u(ResizeHandle,{position:"bottom-left"}),u(ResizeHandle,{position:"bottom-right"})]})},"Widget"),createToolbar=__name(root=>{const container=document.createElement("div");root.appendChild(container),D$1(u(Widget,{}),container);const originalRemove=container.remove.bind(container);return container.remove=function(){container.hasChildNodes()&&(D$1(null,container),D$1(null,container)),originalRemove()},container},"createToolbar"),styles_default=`*, ::before, ::after {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

::backdrop {
  --tw-border-spacing-x: 0;
  --tw-border-spacing-y: 0;
  --tw-translate-x: 0;
  --tw-translate-y: 0;
  --tw-rotate: 0;
  --tw-skew-x: 0;
  --tw-skew-y: 0;
  --tw-scale-x: 1;
  --tw-scale-y: 1;
  --tw-pan-x:  ;
  --tw-pan-y:  ;
  --tw-pinch-zoom:  ;
  --tw-scroll-snap-strictness: proximity;
  --tw-gradient-from-position:  ;
  --tw-gradient-via-position:  ;
  --tw-gradient-to-position:  ;
  --tw-ordinal:  ;
  --tw-slashed-zero:  ;
  --tw-numeric-figure:  ;
  --tw-numeric-spacing:  ;
  --tw-numeric-fraction:  ;
  --tw-ring-inset:  ;
  --tw-ring-offset-width: 0px;
  --tw-ring-offset-color: #fff;
  --tw-ring-color: rgb(59 130 246 / 0.5);
  --tw-ring-offset-shadow: 0 0 #0000;
  --tw-ring-shadow: 0 0 #0000;
  --tw-shadow: 0 0 #0000;
  --tw-shadow-colored: 0 0 #0000;
  --tw-blur:  ;
  --tw-brightness:  ;
  --tw-contrast:  ;
  --tw-grayscale:  ;
  --tw-hue-rotate:  ;
  --tw-invert:  ;
  --tw-saturate:  ;
  --tw-sepia:  ;
  --tw-drop-shadow:  ;
  --tw-backdrop-blur:  ;
  --tw-backdrop-brightness:  ;
  --tw-backdrop-contrast:  ;
  --tw-backdrop-grayscale:  ;
  --tw-backdrop-hue-rotate:  ;
  --tw-backdrop-invert:  ;
  --tw-backdrop-opacity:  ;
  --tw-backdrop-saturate:  ;
  --tw-backdrop-sepia:  ;
  --tw-contain-size:  ;
  --tw-contain-layout:  ;
  --tw-contain-paint:  ;
  --tw-contain-style:  ;
}

/*
! tailwindcss v3.4.17 | MIT License | https://tailwindcss.com
*/

/*
1. Prevent padding and border from affecting element width. (https://github.com/mozdevs/cssremedy/issues/4)
2. Allow adding a border to an element by just adding a border-width. (https://github.com/tailwindcss/tailwindcss/pull/116)
*/

*,
::before,
::after {
  box-sizing: border-box;
  /* 1 */
  border-width: 0;
  /* 2 */
  border-style: solid;
  /* 2 */
  border-color: #e5e7eb;
  /* 2 */
}

::before,
::after {
  --tw-content: '';
}

/*
1. Use a consistent sensible line-height in all browsers.
2. Prevent adjustments of font size after orientation changes in iOS.
3. Use a more readable tab size.
4. Use the user's configured \`sans\` font-family by default.
5. Use the user's configured \`sans\` font-feature-settings by default.
6. Use the user's configured \`sans\` font-variation-settings by default.
7. Disable tap highlights on iOS
*/

html,
:host {
  line-height: 1.5;
  /* 1 */
  -webkit-text-size-adjust: 100%;
  /* 2 */
  -moz-tab-size: 4;
  /* 3 */
  -o-tab-size: 4;
     tab-size: 4;
  /* 3 */
  font-family: ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
  /* 4 */
  font-feature-settings: normal;
  /* 5 */
  font-variation-settings: normal;
  /* 6 */
  -webkit-tap-highlight-color: transparent;
  /* 7 */
}

/*
1. Remove the margin in all browsers.
2. Inherit line-height from \`html\` so users can set them as a class directly on the \`html\` element.
*/

body {
  margin: 0;
  /* 1 */
  line-height: inherit;
  /* 2 */
}

/*
1. Add the correct height in Firefox.
2. Correct the inheritance of border color in Firefox. (https://bugzilla.mozilla.org/show_bug.cgi?id=190655)
3. Ensure horizontal rules are visible by default.
*/

hr {
  height: 0;
  /* 1 */
  color: inherit;
  /* 2 */
  border-top-width: 1px;
  /* 3 */
}

/*
Add the correct text decoration in Chrome, Edge, and Safari.
*/

abbr:where([title]) {
  -webkit-text-decoration: underline dotted;
          text-decoration: underline dotted;
}

/*
Remove the default font size and weight for headings.
*/

h1,
h2,
h3,
h4,
h5,
h6 {
  font-size: inherit;
  font-weight: inherit;
}

/*
Reset links to optimize for opt-in styling instead of opt-out.
*/

a {
  color: inherit;
  text-decoration: inherit;
}

/*
Add the correct font weight in Edge and Safari.
*/

b,
strong {
  font-weight: bolder;
}

/*
1. Use the user's configured \`mono\` font-family by default.
2. Use the user's configured \`mono\` font-feature-settings by default.
3. Use the user's configured \`mono\` font-variation-settings by default.
4. Correct the odd \`em\` font sizing in all browsers.
*/

code,
kbd,
samp,
pre {
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
  /* 1 */
  font-feature-settings: normal;
  /* 2 */
  font-variation-settings: normal;
  /* 3 */
  font-size: 1em;
  /* 4 */
}

/*
Add the correct font size in all browsers.
*/

small {
  font-size: 80%;
}

/*
Prevent \`sub\` and \`sup\` elements from affecting the line height in all browsers.
*/

sub,
sup {
  font-size: 75%;
  line-height: 0;
  position: relative;
  vertical-align: baseline;
}

sub {
  bottom: -0.25em;
}

sup {
  top: -0.5em;
}

/*
1. Remove text indentation from table contents in Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=999088, https://bugs.webkit.org/show_bug.cgi?id=201297)
2. Correct table border color inheritance in all Chrome and Safari. (https://bugs.chromium.org/p/chromium/issues/detail?id=935729, https://bugs.webkit.org/show_bug.cgi?id=195016)
3. Remove gaps between table borders by default.
*/

table {
  text-indent: 0;
  /* 1 */
  border-color: inherit;
  /* 2 */
  border-collapse: collapse;
  /* 3 */
}

/*
1. Change the font styles in all browsers.
2. Remove the margin in Firefox and Safari.
3. Remove default padding in all browsers.
*/

button,
input,
optgroup,
select,
textarea {
  font-family: inherit;
  /* 1 */
  font-feature-settings: inherit;
  /* 1 */
  font-variation-settings: inherit;
  /* 1 */
  font-size: 100%;
  /* 1 */
  font-weight: inherit;
  /* 1 */
  line-height: inherit;
  /* 1 */
  letter-spacing: inherit;
  /* 1 */
  color: inherit;
  /* 1 */
  margin: 0;
  /* 2 */
  padding: 0;
  /* 3 */
}

/*
Remove the inheritance of text transform in Edge and Firefox.
*/

button,
select {
  text-transform: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Remove default button styles.
*/

button,
input:where([type='button']),
input:where([type='reset']),
input:where([type='submit']) {
  -webkit-appearance: button;
  /* 1 */
  background-color: transparent;
  /* 2 */
  background-image: none;
  /* 2 */
}

/*
Use the modern Firefox focus style for all focusable elements.
*/

:-moz-focusring {
  outline: auto;
}

/*
Remove the additional \`:invalid\` styles in Firefox. (https://github.com/mozilla/gecko-dev/blob/2f9eacd9d3d995c937b4251a5557d95d494c9be1/layout/style/res/forms.css#L728-L737)
*/

:-moz-ui-invalid {
  box-shadow: none;
}

/*
Add the correct vertical alignment in Chrome and Firefox.
*/

progress {
  vertical-align: baseline;
}

/*
Correct the cursor style of increment and decrement buttons in Safari.
*/

::-webkit-inner-spin-button,
::-webkit-outer-spin-button {
  height: auto;
}

/*
1. Correct the odd appearance in Chrome and Safari.
2. Correct the outline style in Safari.
*/

[type='search'] {
  -webkit-appearance: textfield;
  /* 1 */
  outline-offset: -2px;
  /* 2 */
}

/*
Remove the inner padding in Chrome and Safari on macOS.
*/

::-webkit-search-decoration {
  -webkit-appearance: none;
}

/*
1. Correct the inability to style clickable types in iOS and Safari.
2. Change font properties to \`inherit\` in Safari.
*/

::-webkit-file-upload-button {
  -webkit-appearance: button;
  /* 1 */
  font: inherit;
  /* 2 */
}

/*
Add the correct display in Chrome and Safari.
*/

summary {
  display: list-item;
}

/*
Removes the default spacing and border for appropriate elements.
*/

blockquote,
dl,
dd,
h1,
h2,
h3,
h4,
h5,
h6,
hr,
figure,
p,
pre {
  margin: 0;
}

fieldset {
  margin: 0;
  padding: 0;
}

legend {
  padding: 0;
}

ol,
ul,
menu {
  list-style: none;
  margin: 0;
  padding: 0;
}

/*
Reset default styling for dialogs.
*/

dialog {
  padding: 0;
}

/*
Prevent resizing textareas horizontally by default.
*/

textarea {
  resize: vertical;
}

/*
1. Reset the default placeholder opacity in Firefox. (https://github.com/tailwindlabs/tailwindcss/issues/3300)
2. Set the default placeholder color to the user's configured gray 400 color.
*/

input::-moz-placeholder, textarea::-moz-placeholder {
  opacity: 1;
  /* 1 */
  color: #9ca3af;
  /* 2 */
}

input::placeholder,
textarea::placeholder {
  opacity: 1;
  /* 1 */
  color: #9ca3af;
  /* 2 */
}

/*
Set the default cursor for buttons.
*/

button,
[role="button"] {
  cursor: pointer;
}

/*
Make sure disabled buttons don't get the pointer cursor.
*/

:disabled {
  cursor: default;
}

/*
1. Make replaced elements \`display: block\` by default. (https://github.com/mozdevs/cssremedy/issues/14)
2. Add \`vertical-align: middle\` to align replaced elements more sensibly by default. (https://github.com/jensimmons/cssremedy/issues/14#issuecomment-634934210)
   This can trigger a poorly considered lint error in some tools but is included by design.
*/

img,
svg,
video,
canvas,
audio,
iframe,
embed,
object {
  display: block;
  /* 1 */
  vertical-align: middle;
  /* 2 */
}

/*
Constrain images and videos to the parent width and preserve their intrinsic aspect ratio. (https://github.com/mozdevs/cssremedy/issues/14)
*/

img,
video {
  max-width: 100%;
  height: auto;
}

/* Make elements with the HTML hidden attribute stay hidden by default */

[hidden]:where(:not([hidden="until-found"])) {
  display: none;
}

.\\!container {
  width: 100% !important;
}

.container {
  width: 100%;
}

@media (min-width: 640px) {
  .\\!container {
    max-width: 640px !important;
  }

  .container {
    max-width: 640px;
  }
}

@media (min-width: 768px) {
  .\\!container {
    max-width: 768px !important;
  }

  .container {
    max-width: 768px;
  }
}

@media (min-width: 1024px) {
  .\\!container {
    max-width: 1024px !important;
  }

  .container {
    max-width: 1024px;
  }
}

@media (min-width: 1280px) {
  .\\!container {
    max-width: 1280px !important;
  }

  .container {
    max-width: 1280px;
  }
}

@media (min-width: 1536px) {
  .\\!container {
    max-width: 1536px !important;
  }

  .container {
    max-width: 1536px;
  }
}

.pointer-events-none {
  pointer-events: none;
}

.visible {
  visibility: visible;
}

.static {
  position: static;
}

.fixed {
  position: fixed;
}

.absolute {
  position: absolute;
}

.relative {
  position: relative;
}

.inset-0 {
  inset: 0px;
}

.bottom-0 {
  bottom: 0px;
}

.left-0 {
  left: 0px;
}

.right-0 {
  right: 0px;
}

.top-0 {
  top: 0px;
}

.z-50 {
  z-index: 50;
}

.z-\\[124124124124\\] {
  z-index: 124124124124;
}

.m-\\[2px\\] {
  margin: 2px;
}

.ml-2 {
  margin-left: 0.5rem;
}

.ml-auto {
  margin-left: auto;
}

.block {
  display: block;
}

.inline {
  display: inline;
}

.flex {
  display: flex;
}

.table {
  display: table;
}

.hidden {
  display: none;
}

.h-10 {
  height: 2.5rem;
}

.h-12 {
  height: 3rem;
}

.h-6 {
  height: 1.5rem;
}

.h-8 {
  height: 2rem;
}

.h-9 {
  height: 2.25rem;
}

.h-full {
  height: 100%;
}

.max-h-9 {
  max-height: 2.25rem;
}

.min-h-9 {
  min-height: 2.25rem;
}

.w-6 {
  width: 1.5rem;
}

.w-fit {
  width: -moz-fit-content;
  width: fit-content;
}

.w-full {
  width: 100%;
}

.flex-1 {
  flex: 1 1 0%;
}

.grow {
  flex-grow: 1;
}

.origin-center {
  transform-origin: center;
}

.-translate-x-3\\/4 {
  --tw-translate-x: -75%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.-translate-x-full {
  --tw-translate-x: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.-translate-y-3\\/4 {
  --tw-translate-y: -75%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.-translate-y-full {
  --tw-translate-y: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-x-3\\/4 {
  --tw-translate-x: 75%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-x-full {
  --tw-translate-x: 100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-y-3\\/4 {
  --tw-translate-y: 75%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.translate-y-full {
  --tw-translate-y: 100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.-rotate-45 {
  --tw-rotate: -45deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.rotate-45 {
  --tw-rotate: 45deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.rotate-90 {
  --tw-rotate: 90deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.rotate-\\[135deg\\] {
  --tw-rotate: 135deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.rotate-\\[225deg\\] {
  --tw-rotate: 225deg;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.transform {
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

@keyframes fadeIn {
  0% {
    opacity: 0;
  }

  100% {
    opacity: 1;
  }
}

.animate-fade-in {
  animation: fadeIn ease-in forwards;
}

.cursor-ew-resize {
  cursor: ew-resize;
}

.cursor-move {
  cursor: move;
}

.cursor-nesw-resize {
  cursor: nesw-resize;
}

.cursor-ns-resize {
  cursor: ns-resize;
}

.cursor-nwse-resize {
  cursor: nwse-resize;
}

.select-none {
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
}

.resize {
  resize: both;
}

.flex-col {
  flex-direction: column;
}

.items-center {
  align-items: center;
}

.items-stretch {
  align-items: stretch;
}

.justify-center {
  justify-content: center;
}

.justify-between {
  justify-content: space-between;
}

.gap-1 {
  gap: 0.25rem;
}

.space-y-1\\.5 > :not([hidden]) ~ :not([hidden]) {
  --tw-space-y-reverse: 0;
  margin-top: calc(0.375rem * calc(1 - var(--tw-space-y-reverse)));
  margin-bottom: calc(0.375rem * var(--tw-space-y-reverse));
}

.overflow-hidden {
  overflow: hidden;
}

.overflow-y-auto {
  overflow-y: auto;
}

.overflow-x-hidden {
  overflow-x: hidden;
}

.truncate {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.whitespace-nowrap {
  white-space: nowrap;
}

.rounded-full {
  border-radius: 9999px;
}

.rounded-lg {
  border-radius: 0.5rem;
}

.rounded-t-lg {
  border-top-left-radius: 0.5rem;
  border-top-right-radius: 0.5rem;
}

.border {
  border-width: 1px;
}

.border-4 {
  border-width: 4px;
}

.border-l-1 {
  border-left-width: 1px;
}

.border-white\\/10 {
  border-color: rgb(255 255 255 / 0.1);
}

.bg-black {
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
}

.bg-neutral-700 {
  --tw-bg-opacity: 1;
  background-color: rgb(64 64 64 / var(--tw-bg-opacity, 1));
}

.p-6 {
  padding: 1.5rem;
}

.px-2 {
  padding-left: 0.5rem;
  padding-right: 0.5rem;
}

.px-3 {
  padding-left: 0.75rem;
  padding-right: 0.75rem;
}

.px-4 {
  padding-left: 1rem;
  padding-right: 1rem;
}

.py-1\\.5 {
  padding-top: 0.375rem;
  padding-bottom: 0.375rem;
}

.font-mono {
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
}

.text-\\[13px\\] {
  font-size: 13px;
}

.text-sm {
  font-size: 0.875rem;
  line-height: 1.25rem;
}

.text-xs {
  font-size: 0.75rem;
  line-height: 1rem;
}

.text-xxs {
  font-size: 0.5rem;
}

.font-bold {
  font-weight: 700;
}

.lowercase {
  text-transform: lowercase;
}

.text-\\[\\#7b51c8\\] {
  --tw-text-opacity: 1;
  color: rgb(123 81 200 / var(--tw-text-opacity, 1));
}

.text-\\[\\#999\\] {
  --tw-text-opacity: 1;
  color: rgb(153 153 153 / var(--tw-text-opacity, 1));
}

.text-white {
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
}

.opacity-0 {
  opacity: 0;
}

.opacity-100 {
  opacity: 1;
}

.\\!shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1) !important;
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color) !important;
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow) !important;
}

.shadow {
  --tw-shadow: 0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 1px 3px 0 var(--tw-shadow-color), 0 1px 2px -1px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.shadow-lg {
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.outline {
  outline-style: solid;
}

.blur {
  --tw-blur: blur(8px);
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.\\!filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow) !important;
}

.filter {
  filter: var(--tw-blur) var(--tw-brightness) var(--tw-contrast) var(--tw-grayscale) var(--tw-hue-rotate) var(--tw-invert) var(--tw-saturate) var(--tw-sepia) var(--tw-drop-shadow);
}

.transition {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-backdrop-filter;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-\\[transform\\2c opacity\\] {
  transition-property: transform,opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-colors {
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.transition-opacity {
  transition-property: opacity;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.delay-0 {
  transition-delay: 0s;
}

.delay-150 {
  transition-delay: 150ms;
}

.delay-500 {
  transition-delay: 500ms;
}

.duration-0 {
  transition-duration: 0s;
}

.duration-150 {
  transition-duration: 150ms;
}

.duration-200 {
  transition-duration: 200ms;
}

.duration-300 {
  transition-duration: 300ms;
}

.ease-out {
  transition-timing-function: cubic-bezier(0, 0, 0.2, 1);
}

.will-change-transform {
  will-change: transform;
}

.animation-duration-300 {
  animation-duration: 300ms;
}

.animation-delay-300 {
  animation-delay: 300ms;
}

* {
  outline: none !important;
  text-rendering: optimizeLegibility;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  backface-visibility: hidden;
  /* WebKit (Chrome, Safari, Edge) specific scrollbar styles */
  &::-webkit-scrollbar {
    width: 6px;
    height: 6px;
  }
  &::-webkit-scrollbar-track {
    border-radius: 10px;
    background: transparent;
  }
  &::-webkit-scrollbar-thumb {
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.3);
  }
  &::-webkit-scrollbar-thumb:hover {
    background: rgba(255, 255, 255, .4);
  }
}

@-moz-document url-prefix() {
  * {
    scrollbar-width: thin;
    scrollbar-color: rgba(255, 255, 255, 0.4) transparent;
    scrollbar-width: 6px;
  }
}

button:hover {
  background-image: none;
}

button {
  outline: 2px solid transparent;
  outline-offset: 2px;
  border-style: none;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
  transition-timing-function: linear;
  cursor: pointer;
}

/*
  Using CSS content with data attributes is more performant than:
  1. React re-renders with JSX text content
  2. Direct DOM manipulation methods:
     - element.textContent (creates/updates text nodes, triggers repaint)
     - element.innerText (triggers reflow by computing styles & layout)
     - element.innerHTML (heavy parsing, triggers reflow, security risks)
  3. Multiple data attributes with complex CSS concatenation

  This approach:
  - Avoids React reconciliation
  - Uses browser's native CSS engine (optimized content updates)
  - Minimizes main thread work
  - Reduces DOM operations
  - Avoids forced reflows (layout recalculation)
  - Only triggers necessary repaints
  - Keeps pseudo-element updates in render layer
*/

.with-data-text {
  overflow: hidden;
  &::before {
    content: attr(data-text);
  }
  &::before {
    display: block;
  }
  &::before {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
}

#react-scan-toolbar {
  position: fixed;
  left: 0px;
  top: 0px;
  display: flex;
  flex-direction: column;
  border-radius: 0.5rem;
  --tw-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
  --tw-shadow-colored: 0 10px 15px -3px var(--tw-shadow-color), 0 4px 6px -4px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
  font-family: Menlo, Consolas, Monaco, Liberation Mono, Lucida Console, monospace;
  font-size: 13px;
  --tw-text-opacity: 1;
  color: rgb(255 255 255 / var(--tw-text-opacity, 1));
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  -webkit-user-select: none;
     -moz-user-select: none;
          user-select: none;
  cursor: move;
  opacity: 0;
  z-index: 2147483678;
}

@keyframes fadeIn {
  0% {
    opacity: 0;
  }

  100% {
    opacity: 1;
  }
}

#react-scan-toolbar {
  animation: fadeIn ease-in forwards;
  animation-duration: 300ms;
  animation-delay: 300ms;
  --tw-shadow: 0 4px 12px rgba(0,0,0,0.2);
  --tw-shadow-colored: 0 4px 12px var(--tw-shadow-color);
  box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

/* HEADER */

.react-scan-header {
  display: flex;
  align-items: center;
  -moz-column-gap: 0.5rem;
       column-gap: 0.5rem;
  padding-left: 0.75rem;
  padding-right: 0.5rem;
  min-height: 2.25rem;
  border-top-left-radius: 0.5rem;
  border-top-right-radius: 0.5rem;
  border-bottom-width: 1px;
  border-color: rgb(255 255 255 / 0.1);
  overflow: hidden;
  white-space: nowrap;
}

.react-scan-replay-button,
.react-scan-close-button {
  display: flex;
  align-items: center;
  padding: 0.25rem;
  min-width: -moz-fit-content;
  min-width: fit-content;
  border-radius: 0.25rem;
  transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
  transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
  transition-duration: 150ms;
}

.react-scan-replay-button {
  position: relative;
  overflow: hidden;
  background-color: rgb(168 85 247 / 0.5) !important;
  &:hover {
    background-color: rgb(168 85 247 / 0.25);
  }
  &.disabled {
    opacity: 0.5;
  }
  &.disabled {
    pointer-events: none;
  }
  &:before {
    content: '';
  }
  &:before {
    position: absolute;
  }
  &:before {
    inset: 0px;
  }
  &:before {
    --tw-translate-x: -100%;
    transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  }
  &:before {
    animation: shimmer 2s infinite;
    background: linear-gradient(to right,
      transparent,
      rgba(142, 97, 227, 0.3),
      transparent);
  }
}

.react-scan-close-button {
  background-color: rgb(255 255 255 / 0.1);
  &:hover {
    background-color: rgb(255 255 255 / 0.15);
  }
}

@keyframes shimmer {
  100% {
    transform: translateX(100%);
  }
}

.react-scan-inspector {
  font-size: 13px;
  color: #fff;
  width: 100%;
}

.react-scan-section {
  display: flex;
  flex-direction: column;
  padding-top: 0.5rem;
  padding-bottom: 0.5rem;
  padding-left: 1rem;
  padding-right: 1rem;
  --tw-bg-opacity: 1;
  background-color: rgb(0 0 0 / var(--tw-bg-opacity, 1));
  --tw-text-opacity: 1;
  color: rgb(136 136 136 / var(--tw-text-opacity, 1));
}

.react-scan-section::before {
  --tw-text-opacity: 1;
  color: rgb(107 114 128 / var(--tw-text-opacity, 1));
  --tw-content: attr(data-section);
  content: var(--tw-content);
}

.react-scan-section {
  > div {
    margin-left: 0.5rem;
  }
  > div {
    min-height: 1.5rem;
  }
}

.react-scan-property {
  position: relative;
  display: flex;
  flex-direction: column;
  padding-top: 0.25rem;
  padding-left: 1.5rem;
  border-left-width: 1px;
  border-color: transparent;
  overflow: hidden;
}

.react-scan-key {
  color: #fff;
}

.react-scan-warning {
  padding-right: 4px;
}

.react-scan-string {
  color: #9ecbff;
}

.react-scan-number {
  color: #79c7ff;
}

.react-scan-boolean {
  color: #56b6c2;
}

.react-scan-input {
  background: #000;
  border: none;
  color: #fff;
}

.react-scan-object-key {
  color: #fff;
}

.react-scan-array {
  color: #fff;
}

.react-scan-expandable {
  display: flex;
  align-items: flex-start;
}

.react-scan-arrow {
  position: absolute;
  top: 0.5rem;
  left: 1.5rem;
  cursor: pointer;
  height: 1.5rem;
  width: 1.5rem;
  --tw-translate-x: -100%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
  z-index: 10;
  &:before {
    content: '▶';
  }
  &:before {
    position: absolute;
  }
  &:before {
    inset: 0px;
  }
  &:before {
    display: flex;
  }
  &:before {
    align-items: center;
  }
  &:before {
    justify-content: center;
  }
  &:before {
    --tw-text-opacity: 1;
    color: rgb(136 136 136 / var(--tw-text-opacity, 1));
  }
  &:before {
    font-size: 8px;
  }
  &:before {
    transform-origin: center;
  }
  &:before {
    transition-property: transform;
    transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    transition-duration: 150ms;
  }
  &:before {
    transition-duration: 150ms;
  }
}

.react-scan-expanded > .react-scan-arrow:before {
  transform: rotate(90deg);
}

.react-scan-property-content {
  display: flex;
  flex: 1 1 0%;
  flex-direction: column;
  padding-top: 0.25rem;
  max-width: 100%;
  overflow: hidden;
}

.react-scan-hidden {
  display: none;
}

.react-scan-array-container {
  overflow-y: auto;
  margin-left: 1.25rem;
  margin-top: 8px;
  border-left: 1px solid rgba(255, 255, 255, 0.1);
  padding-left: 8px;
}

.react-scan-nested-object {
  /* @apply ml-5; */
  border-left: 1px solid rgba(255, 255, 255, 0.1);
}

.react-scan-preview-line {
  position: relative;
  display: flex;
  min-height: 1.5rem;
  align-items: center;
}

.react-scan-flash-overlay {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: rgba(142, 97, 227, 1);
  pointer-events: none;
  opacity: 0;
  z-index: 999999;
  mix-blend-mode: multiply;
  transition: opacity 150ms ease-in;
  border-radius: 4px;
}

.react-scan-flash-active {
  opacity: 0.4;
  transition: opacity 300ms ease-in-out;
}

#react-scan-toolbar button:hover {
  background: rgba(255, 255, 255, 0.1);
}

#react-scan-toolbar button:active {
  background: rgba(255, 255, 255, 0.15);
}

#react-scan-toolbar button:focus-visible {
  outline: 2px solid #0070f3;
  outline-offset: -2px;
}

.nav-button {
  opacity: var(--nav-opacity, 1);
}

.react-scan-toolbar {
  border: 1px solid blue;
}

.group:hover .group-hover\\:-translate-x-1\\/4 {
  --tw-translate-x: -25%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.group:hover .group-hover\\:-translate-y-1\\/4 {
  --tw-translate-y: -25%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.group:hover .group-hover\\:translate-x-0 {
  --tw-translate-x: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.group:hover .group-hover\\:translate-x-1\\/4 {
  --tw-translate-x: 25%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.group:hover .group-hover\\:translate-y-0 {
  --tw-translate-y: 0px;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.group:hover .group-hover\\:translate-y-1\\/4 {
  --tw-translate-y: 25%;
  transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.group:hover .group-hover\\:opacity-100 {
  opacity: 1;
}

.group:hover .group-hover\\:delay-0 {
  transition-delay: 0s;
}

.group:active .group-active\\:opacity-0 {
  opacity: 0;
}

.group:active .group-active\\:opacity-100 {
  opacity: 1;
}

.group:active .group-active\\:delay-0 {
  transition-delay: 0s;
}
`,toolbarContainer=null,shadowRoot=null,Store={wasDetailsOpen:d$1(!0),isInIframe:d$1(typeof window<"u"&&window.self!==window.top),inspectState:d$1({kind:"uninitialized"}),monitor:d$1(null),fiberRoots:new WeakSet,reportData:new WeakMap,legacyReportData:new Map,lastReportTime:d$1(0)},ReactScanInternals={instrumentation:null,componentAllowList:null,options:d$1({enabled:!0,includeChildren:!0,playSound:!1,log:!1,showToolbar:!0,renderCountThreshold:0,report:void 0,alwaysShowLabels:!1,animationSpeed:"fast",dangerouslyForceRunInProduction:!1,smoothlyAnimateOutlines:!0,trackUnnecessaryRenders:!1}),onRender:null,scheduledOutlines:new Map,activeOutlines:new Map,Store},validateOptions=__name(options=>{const errors=[],validOptions={};for(const key in options){const value=options[key];switch(key){case"enabled":case"includeChildren":case"playSound":case"log":case"showToolbar":case"report":case"alwaysShowLabels":case"dangerouslyForceRunInProduction":typeof value!="boolean"?errors.push(`- ${key} must be a boolean. Got "${value}"`):validOptions[key]=value;break;case"renderCountThreshold":case"resetCountTimeout":typeof value!="number"||value<0?errors.push(`- ${key} must be a non-negative number. Got "${value}"`):validOptions[key]=value;break;case"animationSpeed":["slow","fast","off"].includes(value)?validOptions[key]=value:errors.push(`- Invalid animation speed "${value}". Using default "fast"`);break;case"onCommitStart":case"onCommitFinish":case"onRender":case"onPaintStart":case"onPaintFinish":typeof value!="function"?errors.push(`- ${key} must be a function. Got "${value}"`):validOptions[key]=value;break;case"trackUnnecessaryRenders":{validOptions.trackUnnecessaryRenders=typeof value=="boolean"?value:!1;break}case"smoothlyAnimateOutlines":{validOptions.smoothlyAnimateOutlines=typeof value=="boolean"?value:!1;break}default:errors.push(`- Unknown option "${key}"`)}}return errors.length>0&&console.warn(`[React Scan] Invalid options:
${errors.join(`
`)}`),validOptions},"validateOptions"),getReport=__name(type=>{if(type){for(const reportData of Array.from(Store.legacyReportData.values()))if(reportData.type===type)return reportData;return null}return Store.legacyReportData},"getReport"),setOptions=__name(userOptions=>{const validOptions=validateOptions(userOptions);if(Object.keys(validOptions).length===0)return;"playSound"in validOptions&&validOptions.playSound&&(validOptions.enabled=!0);const newOptions={...ReactScanInternals.options.value,...validOptions},{instrumentation}=ReactScanInternals;instrumentation&&"enabled"in validOptions&&(instrumentation.isPaused.value=validOptions.enabled===!1),ReactScanInternals.options.value=newOptions,saveLocalStorage("react-scan-options",newOptions),"showToolbar"in validOptions&&(toolbarContainer&&!newOptions.showToolbar&&toolbarContainer.remove(),newOptions.showToolbar&&toolbarContainer&&shadowRoot&&(toolbarContainer=createToolbar(shadowRoot)))},"setOptions"),getOptions=__name(()=>ReactScanInternals.options,"getOptions"),reportRender=__name((fiber,renders)=>{const reportFiber=fiber,{selfTime}=getTimings(fiber.type),displayName=getDisplayName(fiber.type);Store.lastReportTime.value=Date.now();const currentFiberData=Store.reportData.get(reportFiber)??{count:0,time:0,renders:[],displayName,type:null};if(currentFiberData.count=Number(currentFiberData.count||0)+Number(renders.length),currentFiberData.time=Number(currentFiberData.time||0)+Number(selfTime||0),currentFiberData.renders=renders,Store.reportData.set(reportFiber,currentFiberData),displayName&&ReactScanInternals.options.value.report){const existingLegacyData=Store.legacyReportData.get(displayName)??{count:0,time:0,renders:[],displayName:null,type:getType(fiber.type)||fiber.type};existingLegacyData.count=existingLegacyData.time=Number(existingLegacyData.time||0)+Number(selfTime||0),existingLegacyData.renders=renders,Store.legacyReportData.set(displayName,existingLegacyData)}},"reportRender"),isValidFiber=__name(fiber=>{if(ignoredProps.has(fiber.memoizedProps))return!1;const allowList=ReactScanInternals.componentAllowList,shouldAllow=(allowList==null?void 0:allowList.has(fiber.type))??(allowList==null?void 0:allowList.has(fiber.elementType));return!(shouldAllow&&!traverseFiber(fiber,node=>{const options=(allowList==null?void 0:allowList.get(node.type))??(allowList==null?void 0:allowList.get(node.elementType));return options==null?void 0:options.includeChildren},!0)&&!shouldAllow)},"isValidFiber"),flushInterval,startFlushOutlineInterval=__name(ctx=>{clearInterval(flushInterval),setInterval(()=>{requestAnimationFrame(()=>{flushOutlines(ctx)})},30)},"startFlushOutlineInterval"),updateScheduledOutlines=__name((fiber,renders)=>{var _a2;for(let i2=0,len=renders.length;i2<len;i2++){const render2=renders[i2],domFiber=getNearestHostFiber(fiber);if(!(!domFiber||!domFiber.stateNode))if(ReactScanInternals.scheduledOutlines.has(fiber)){const existingOutline=ReactScanInternals.scheduledOutlines.get(fiber);aggregateRender(render2,existingOutline.aggregatedRender)}else ReactScanInternals.scheduledOutlines.set(fiber,{domNode:domFiber.stateNode,aggregatedRender:{computedCurrent:null,name:((_a2=renders.find(render3=>render3.componentName))==null?void 0:_a2.componentName)??"N/A",aggregatedCount:1,changes:aggregateChanges(render2.changes),didCommit:render2.didCommit,forget:render2.forget,fps:render2.fps,phase:new Set([render2.phase]),time:render2.time,unnecessary:render2.unnecessary,frame:0,computedKey:null},alpha:null,groupedAggregatedRender:null,target:null,current:null,totalFrames:null,estimatedTextWidth:null})}},"updateScheduledOutlines"),isProduction=null,rdtHook,getIsProduction=__name(()=>{if(isProduction!==null)return isProduction;rdtHook??(rdtHook=getRDTHook());for(const renderer of rdtHook.renderers.values())detectReactBuildType(renderer)==="production"&&(isProduction=!0);return isProduction},"getIsProduction"),start=__name(()=>{if(typeof window>"u"||getIsProduction()&&!ReactScanInternals.options.value.dangerouslyForceRunInProduction)return;const rdtHook2=getRDTHook();for(const renderer of rdtHook2.renderers.values())detectReactBuildType(renderer)==="production"&&(isProduction=!0);const localStorageOptions=readLocalStorage("react-scan-options");if(localStorageOptions){const{enabled,playSound}=localStorageOptions,validLocalOptions=validateOptions({enabled,playSound});Object.keys(validLocalOptions).length>0&&(ReactScanInternals.options.value={...ReactScanInternals.options.value,...validLocalOptions})}const audioContext=typeof window<"u"?new(window.AudioContext||window.webkitAudioContext):null;let ctx=null;const instrumentation=createInstrumentation("devtools",{onActive(){if(document.querySelector("react-scan-root"))return;const container=document.createElement("div");container.id="react-scan-root",shadowRoot=container.attachShadow({mode:"open"});const fragment=document.createDocumentFragment(),cssStyles=document.createElement("style");cssStyles.textContent=styles_default;const iconSprite=new DOMParser().parseFromString(ICONS,"image/svg+xml").documentElement;shadowRoot.appendChild(iconSprite);const root=document.createElement("div");if(root.id="react-scan-toolbar-root",root.className="absolute z-2147483647",fragment.appendChild(cssStyles),fragment.appendChild(root),shadowRoot.appendChild(fragment),document.documentElement.appendChild(container),ctx=initReactScanOverlay(),!ctx||(startFlushOutlineInterval(ctx),createInspectElementStateMachine(shadowRoot),globalThis.__REACT_SCAN__={ReactScanInternals},ReactScanInternals.options.value.showToolbar&&(toolbarContainer=createToolbar(shadowRoot)),document.querySelector("react-scan-overlay")))return;const overlayElement=document.createElement("react-scan-overlay");document.documentElement.appendChild(overlayElement),logIntro()},onCommitStart(){var _a2,_b2;(_b2=(_a2=ReactScanInternals.options.value).onCommitStart)==null||_b2.call(_a2)},onError(error){console.error("[React Scan] Error instrumenting:",error)},isValidFiber,onRender(fiber,renders){var _a2,_b2,_c;if(!((_a2=ReactScanInternals.instrumentation)!=null&&_a2.isPaused.value&&(Store.inspectState.value.kind==="inspect-off"||Store.inspectState.value.kind==="uninitialized")||!ctx||document.visibilityState!=="visible")){updateFiberRenderData(fiber,renders),ReactScanInternals.options.value.log&&log(renders),isCompositeFiber(fiber)&&ReactScanInternals.options.value.showToolbar!==!1&&Store.inspectState.value.kind==="focused"&&reportRender(fiber,renders),ReactScanInternals.options.value.log,(_c=(_b2=ReactScanInternals.options.value).onRender)==null||_c.call(_b2,fiber,renders),updateScheduledOutlines(fiber,renders);for(let i2=0,len=renders.length;i2<len;i2++){const render2=renders[i2];if(ReactScanInternals.options.value.playSound&&audioContext){const amplitude=Math.min(1,((render2.time??0)-10)/20);playGeigerClickSound(audioContext,amplitude)}}}},onCommitFinish(){var _a2,_b2;(_b2=(_a2=ReactScanInternals.options.value).onCommitFinish)==null||_b2.call(_a2)},trackChanges:!0});ReactScanInternals.instrumentation=instrumentation,Store.monitor.value||setTimeout(()=>{isInstrumentationActive()||console.error("[React Scan] Failed to load. Must import React Scan before React runs.")},5e3)},"start"),withScan=__name((component,options={})=>{setOptions(options);const isInIframe=Store.isInIframe.value,componentAllowList=ReactScanInternals.componentAllowList;return isInIframe||options.enabled===!1&&options.showToolbar!==!0||(componentAllowList||(ReactScanInternals.componentAllowList=new WeakMap),componentAllowList&&componentAllowList.set(component,{...options}),start()),component},"withScan"),scan=__name((options={})=>{setOptions(options),!(Store.isInIframe.value||options.enabled===!1&&options.showToolbar!==!0)&&start()},"scan"),useScan=__name((options={})=>{setOptions(options),start()},"useScan"),onRender=__name((type,_onRender)=>{const prevOnRender=ReactScanInternals.onRender;ReactScanInternals.onRender=(fiber,renders)=>{prevOnRender==null||prevOnRender(fiber,renders),getType(fiber.type)===type&&_onRender(fiber,renders)}},"onRender"),ignoredProps=new WeakSet,ignoreScan=__name(node=>{typeof node=="object"&&node&&ignoredProps.add(node)},"ignoreScan");const reactScan=Object.freeze(Object.defineProperty({__proto__:null,ReactScanInternals,Store,getIsProduction,getOptions,getReport,ignoreScan,ignoredProps,isValidFiber,onRender,reportRender,scan,setOptions,start,useScan,withScan},Symbol.toStringTag,{value:"Module"}));new BroadcastChannel("react-scan");const isIframe=window!==window.top,isPopup=window.opener!==null,canLoadReactScan=!isIframe&&!isPopup;window.isReactScanExtension=!0,window.reactScan=setOptions,globalThis._reactScan=reactScan,canLoadReactScan&&scan()})();
